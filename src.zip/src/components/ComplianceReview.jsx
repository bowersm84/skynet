import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'
import { uploadDocument, getDocumentUrl } from '../lib/s3'
import { buildTravelerHTML, fetchCOAllocationsForTraveler } from '../lib/traveler'
import { FEATURES } from '../config'
import { releaseCOAllocationsIfWODead } from '../lib/customerOrders'
import { evaluateJobShortfall } from '../lib/shortfall'
import { promoteToPartDocument } from '../lib/documents'
import { isReadOnlyRole } from '../lib/roles'
import { batchRequiresChemicals } from '../lib/routing'
import PrintPackageModal from './PrintPackageModal'
import DocsDeferredBadge from './DocsDeferredBadge'
import DeferredDocsWidget from './DeferredDocsWidget'
import AddJobDocumentModal from './AddJobDocumentModal'
import { 
  ChevronDown, 
  ChevronRight, 
  Upload, 
  Check, 
  Eye, 
  AlertCircle, 
  CheckCircle, 
  Clock,
  X,
  FileText,
  Loader2,
  Plus,
  RefreshCw,
  Undo2,
  Beaker,
  ArrowUp,
  ArrowDown,
  Printer,
  ClipboardCheck,
  Pause,
  Flag,
  Package,
  AlertTriangle,
  ExternalLink
} from 'lucide-react'


export default function ComplianceReview({ jobs, onUpdate, profile, onNavigateToWO }) {
  const canWrite = !isReadOnlyRole(profile?.role)
  const [expandedJob, setExpandedJob] = useState(null)
  const [jobDetails, setJobDetails] = useState({})
  const [uploading, setUploading] = useState(null)
  const [approving, setApproving] = useState(null)
  const [replacing, setReplacing] = useState(null)
  const [recalling, setRecalling] = useState(null)
  const [viewingDoc, setViewingDoc] = useState(null)
  const [showRecentlyApproved, setShowRecentlyApproved] = useState(false)
  const [approvingRouting, setApprovingRouting] = useState(null)
  const [routingReviewed, setRoutingReviewed] = useState({})
  const [addingStepForJob, setAddingStepForJob] = useState(null)
  const [newStepName, setNewStepName] = useState('')
  const [newStepType, setNewStepType] = useState('internal')
  const [newStepStation, setNewStepStation] = useState('')
  const [printPackageJob, setPrintPackageJob] = useState(null)
  const [postMfgData, setPostMfgData] = useState({})
  // Shape: { [jobId]: { good_qty: string, bad_qty: string, notes: string } }

  // Per-job defer-documents state for pre-mfg approvals.
  // Shape: { [jobId]: { defer: boolean, reason: string } }
  const [deferData, setDeferData] = useState({})

  // When a job's pre-mfg required docs become fully satisfied, drop any stale
  // deferData entry so a checked-and-typed defer state can't survive an upload
  // and quietly come back if a doc later gets deleted. Watches jobDetails
  // because that's the upstream source of the doc-completeness check.
  useEffect(() => {
    setDeferData(prev => {
      const ids = Object.keys(prev)
      if (ids.length === 0) return prev
      let next = prev
      for (const jobId of ids) {
        const details = jobDetails[jobId]
        if (!details) continue
        const stageReqs = (details.requirements || []).filter(r =>
          r.required_at === 'compliance_review' || !r.required_at
        )
        const docs = details.jobDocs || []
        const hasMissing = stageReqs.some(r =>
          r.is_required && !docs.some(d => d.document_type_id === r.document_type_id && d.status === 'approved')
        )
        const entry = prev[jobId]
        if (!hasMissing && (entry?.defer || entry?.reason)) {
          if (next === prev) next = { ...prev }
          next[jobId] = { defer: false, reason: '' }
        }
      }
      return next
    })
  }, [jobDetails])

  // Additional Documents modal target: { jobId, partId } or null. Drives
  // the AddJobDocumentModal which carries its own "save to part" checkbox.
  const [additionalDocFor, setAdditionalDocFor] = useState(null)


  // Per-batch compliance state
  const [pendingBatches, setPendingBatches] = useState([])
  const [expandedBatch, setExpandedBatch] = useState(null)
  const [batchReviewData, setBatchReviewData] = useState({})
  // Shape: { [sendId]: { good_qty: string, bad_qty: string, notes: string } }
  const [approvingBatch, setApprovingBatch] = useState(null)
  const [batchDetails, setBatchDetails] = useState({})
  // Shape: { [sendId]: { requirements: [], jobDocs: [] } }
  const [recentlyApprovedBatches, setRecentlyApprovedBatches] = useState([])
  const [showRecentBatches, setShowRecentBatches] = useState(false)
  const [allJobSendsMap, setAllJobSendsMap] = useState({})
  // Shape: { [jobId]: [sends sorted by sent_at] }

  const fetchBatchDetails = async (send) => {
    const jobId = send.job_id
    const partId = send.job?.component?.id
    if (!partId) return

    let { data: requirements } = await supabase
      .from('part_document_requirements')
      .select('*, document_type:document_types(*)')
      .eq('part_id', partId)

    const { data: jobDocs } = await supabase
      .from('job_documents')
      .select('*, document_type:document_types(*)')
      .eq('job_id', jobId)
      .order('created_at', { ascending: true })

    setBatchDetails(prev => ({
      ...prev,
      [send.id]: { requirements: requirements || [], jobDocs: jobDocs || [] }
    }))

    // Pre-fill good_qty with verified_count so Roger sees an actual default value,
    // not just a placeholder. Only set if Roger hasn't already typed something.
    setBatchReviewData(prev => {
      const existing = prev[send.id] || {}
      if (existing.good_qty != null && existing.good_qty !== '') return prev
      const defaultGood = send.verified_count != null
        ? String(send.verified_count)
        : (send.quantity != null ? String(send.quantity) : '')
      return {
        ...prev,
        [send.id]: { ...existing, good_qty: defaultGood }
      }
    })
  }

  const fetchPendingBatches = async () => {
    const { data, error } = await supabase
      .from('finishing_sends')
      .select(`
        *,
        job:jobs(
          id, job_number, quantity, production_lot_number, status,
          work_order_assembly_id, is_standalone_finishing, source_description,
          has_open_shortfall,
          work_order:work_orders(id, wo_number, customer, priority, due_date, order_type, has_open_shortfall),
          component:parts!component_id(id, part_number, description, customer, part_type),
          assigned_machine:machines!assigned_machine_id(name),
          routing_steps:job_routing_steps(step_name, status, step_order)
        ),
        sent_by_profile:profiles!sent_by(full_name),
        finishing_operator:profiles!finishing_operator_id(full_name)
      `)
      .eq('compliance_status', 'pending_compliance')
      .order('finishing_completed_at', { ascending: true })

    if (!error) {
      setPendingBatches(data || [])

      // Fetch all sends for jobs with pending batches (for accurate batch labeling)
      const jobIds = [...new Set((data || []).map(s => s.job_id))]
      if (jobIds.length > 0) {
        const { data: allSends } = await supabase
          .from('finishing_sends')
          .select('id, job_id, quantity, sent_at, is_partial_send')
          .in('job_id', jobIds)
          .order('sent_at', { ascending: true })

        const map = {}
        allSends?.forEach(s => {
          if (!map[s.job_id]) map[s.job_id] = []
          map[s.job_id].push(s)
        })
        setAllJobSendsMap(map)
      }
    }
  }

  const fetchRecentlyApprovedBatches = async () => {
    const fiveDaysAgo = new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString()
    const { data } = await supabase
      .from('finishing_sends')
      .select(`
        *,
        job:jobs(
          id, job_number, quantity, is_standalone_finishing, source_description,
          has_open_shortfall,
          work_order:work_orders(id, wo_number, customer, has_open_shortfall),
          component:parts!component_id(part_number, description, customer),
          assigned_machine:machines!assigned_machine_id(name)
        )
      `)
      .eq('compliance_status', 'approved')
      .gte('compliance_approved_at', fiveDaysAgo)
      .order('compliance_approved_at', { ascending: false })
      .limit(50)
    setRecentlyApprovedBatches(data || [])
  }

  useEffect(() => {
    fetchPendingBatches()
    fetchRecentlyApprovedBatches()

    const sub = supabase
      .channel('compliance-finishing-sends')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'finishing_sends'
      }, () => { fetchPendingBatches(); fetchRecentlyApprovedBatches() })
      .subscribe()

    return () => {
      supabase.removeChannel(sub)
    }
  }, [])

  const getBatchLabel = (send) => {
    const jobSends = allJobSendsMap[send.job_id] || []
    const isPartial = send.is_partial_send === true
    // If map not loaded yet, return null — will re-render once loaded
    if (jobSends.length === 0) return null
    if (jobSends.length === 1 && !isPartial) return null
    const idx = jobSends.findIndex(s => s.id === send.id)
    if (idx === -1) return null
    return String.fromCharCode(65 + idx) // A, B, C...
  }

  // Shared UI helper for the outcome selector used in all compliance cards.
  // `variant` switches the available outcomes: pre-mfg (accept/hold/flag) vs
  // post-mfg (accept/rework/reject). Parent supplies value + note plus setters
  // so the helper stays state-agnostic.
  const renderOutcomeSelector = ({ variant = 'post-mfg', outcome, onOutcomeChange, noteValue, onNoteChange, disabled }) => {
    const preMfgOptions = [
      { value: 'accepted', label: 'Accept', icon: CheckCircle, activeClass: 'bg-green-600 border-green-500 text-white', inactiveClass: 'border-gray-700 text-gray-400 hover:border-green-600 hover:text-green-400' },
      { value: 'hold',     label: 'Hold',   icon: Pause,       activeClass: 'bg-slate-600 border-slate-500 text-white', inactiveClass: 'border-gray-700 text-gray-400 hover:border-slate-500 hover:text-slate-300' },
      { value: 'flag',     label: 'Flag',   icon: Flag,        activeClass: 'bg-amber-600 border-amber-500 text-white', inactiveClass: 'border-gray-700 text-gray-400 hover:border-amber-600 hover:text-amber-400' },
    ]
    const preMfgHeldOptions = [
      { value: 'accepted', label: 'Accept', icon: CheckCircle, activeClass: 'bg-green-600 border-green-500 text-white', inactiveClass: 'border-gray-700 text-gray-400 hover:border-green-600 hover:text-green-400' },
      { value: 'flag',     label: 'Flag',   icon: Flag,        activeClass: 'bg-amber-600 border-amber-500 text-white', inactiveClass: 'border-gray-700 text-gray-400 hover:border-amber-600 hover:text-amber-400' },
    ]
    const postMfgOptions = [
      { value: 'accepted', label: 'Accept', icon: CheckCircle, activeClass: 'bg-green-600 border-green-500 text-white', inactiveClass: 'border-gray-700 text-gray-400 hover:border-green-600 hover:text-green-400' },
      { value: 'rework',   label: 'Rework', icon: AlertCircle, activeClass: 'bg-amber-600 border-amber-500 text-white', inactiveClass: 'border-gray-700 text-gray-400 hover:border-amber-600 hover:text-amber-400' },
      { value: 'rejected', label: 'Reject', icon: X,           activeClass: 'bg-red-600 border-red-500 text-white',     inactiveClass: 'border-gray-700 text-gray-400 hover:border-red-600 hover:text-red-400' },
    ]
    const options = variant === 'pre-mfg' ? preMfgOptions
      : variant === 'pre-mfg-held' ? preMfgHeldOptions
      : postMfgOptions

    return (
      <div className="p-3 bg-gray-800/50 rounded-lg border border-gray-700 space-y-3">
        <h4 className="text-gray-300 font-medium text-sm">Compliance Outcome</h4>
        <div className={options.length === 2 ? 'grid grid-cols-2 gap-2' : 'grid grid-cols-3 gap-2'}>
          {options.map(opt => {
            const Icon = opt.icon
            const isSelected = outcome === opt.value
            return (
              <button
                key={opt.value}
                type="button"
                onClick={() => onOutcomeChange(opt.value)}
                disabled={disabled}
                className={`flex items-center justify-center gap-2 px-3 py-2 rounded border-2 text-sm font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${isSelected ? opt.activeClass : opt.inactiveClass}`}
              >
                <Icon size={16} />
                {opt.label}
              </button>
            )
          })}
        </div>
        {outcome === 'rework' && (
          <div>
            <label className="block text-amber-400 text-xs mb-1">
              Rework Instructions <span className="text-red-400">*</span>
            </label>
            <textarea
              value={noteValue ?? ''}
              onChange={(e) => onNoteChange(e.target.value)}
              placeholder="Describe what needs rework before assembly can proceed..."
              rows={3}
              className="w-full bg-gray-800 border border-amber-700 rounded px-3 py-2 text-white placeholder-gray-500 text-sm focus:border-amber-500 focus:outline-none"
            />
          </div>
        )}
        {outcome === 'rejected' && (
          <div>
            <label className="block text-red-400 text-xs mb-1">
              Rejection Reason <span className="text-red-400">*</span>
            </label>
            <textarea
              value={noteValue ?? ''}
              onChange={(e) => onNoteChange(e.target.value)}
              placeholder="Reason for rejection — will be visible to April in WO Lookup..."
              rows={3}
              className="w-full bg-gray-800 border border-red-700 rounded px-3 py-2 text-white placeholder-gray-500 text-sm focus:border-red-500 focus:outline-none"
            />
          </div>
        )}
        {outcome === 'hold' && (
          <div>
            <label className="block text-slate-300 text-xs mb-1">
              Hold Reason <span className="text-red-400">*</span>
            </label>
            <textarea
              value={noteValue ?? ''}
              onChange={(e) => onNoteChange(e.target.value)}
              placeholder="Why is this on hold? What are you working on? April will see this in WO Lookup..."
              rows={3}
              className="w-full bg-gray-800 border border-slate-600 rounded px-3 py-2 text-white placeholder-gray-500 text-sm focus:border-slate-400 focus:outline-none"
            />
          </div>
        )}
        {outcome === 'flag' && (
          <div>
            <label className="block text-amber-400 text-xs mb-1">
              Flag Note <span className="text-red-400">*</span>
            </label>
            <textarea
              value={noteValue ?? ''}
              onChange={(e) => onNoteChange(e.target.value)}
              placeholder="What needs attention later? Who should handle it?..."
              rows={3}
              className="w-full bg-gray-800 border border-amber-700 rounded px-3 py-2 text-white placeholder-gray-500 text-sm focus:border-amber-500 focus:outline-none"
            />
          </div>
        )}
      </div>
    )
  }

  const handleViewTraveler = async (jobId) => {
    if (!jobId) return
    try {
      const { data: fullJob, error: jobError } = await supabase
        .from('jobs')
        .select(`
          id, job_number, quantity, status,
          production_lot_number, good_pieces, actual_end,
          work_order:work_orders ( id, wo_number, customer, po_number, due_date, order_type, order_quantity, stock_quantity ),
          component:parts!component_id ( id, part_number, description, drawing_revision, requires_passivation, material_type:material_types ( name ) ),
          assigned_machine:machines!assigned_machine_id ( name ),
          assigned_user:profiles!assigned_user_id ( full_name )
        `)
        .eq('id', jobId)
        .single()
      if (jobError) throw jobError

      const { data: steps, error: stepsError } = await supabase
        .from('job_routing_steps')
        .select(`*, completed_by_profile:profiles!completed_by(full_name)`)
        .eq('job_id', jobId)
        .neq('status', 'removed')
        .order('step_order')
      if (stepsError) throw stepsError

      const { data: finishingBatches, error: fsError } = await supabase
        .from('finishing_sends')
        .select(`
          id, finishing_lot_number, chemical_lot_number, chemical_lot_number_2,
          material_lot_number, quantity, verified_count, compliance_good_qty, compliance_bad_qty,
          finishing_completed_at, compliance_approved_at,
          finishing_operator:profiles!finishing_operator_id(full_name)
        `)
        .eq('job_id', jobId)
        .not('finishing_completed_at', 'is', null)
        .neq('compliance_status', 'rejected')
        .order('finishing_completed_at', { ascending: false })
      if (fsError) throw fsError

      const { data: outboundSends, error: osError } = await supabase
        .from('outbound_sends')
        .select(`
          id, operation_type, vendor_name, vendor_lot_number,
          quantity, quantity_returned, sent_at, returned_at,
          job_routing_step_id, finishing_send_id,
          finishing_send:finishing_sends!finishing_send_id(id, compliance_approved_at)
        `)
        .eq('job_id', jobId)
        .order('sent_at', { ascending: true })
      if (osError) throw osError

      const woIdForAllocs = fullJob.work_order?.id || fullJob.work_order_id
      if (!woIdForAllocs) {
        console.warn('Traveler: no work_order id available for CO allocation lookup', { jobId: fullJob.id })
      }
      const coAllocations = woIdForAllocs ? await fetchCOAllocationsForTraveler(supabase, woIdForAllocs) : []

      const html = buildTravelerHTML({
        job: fullJob,
        steps: steps || [],
        finishingBatches: finishingBatches || [],
        outboundSends: outboundSends || [],
        coAllocations,
      })
      const win = window.open('', '_blank')
      if (!win) {
        alert('Pop-up blocked. Allow pop-ups for this site to view the traveler.')
        return
      }
      win.document.open()
      win.document.write(html)
      win.document.close()
    } catch (err) {
      console.error('Failed to open traveler:', err)
      alert('Failed to open traveler: ' + err.message)
    }
  }

  const handleApproveBatch = async (send, outcome) => {
    setApprovingBatch(send.id)
    const now = new Date().toISOString()
    const reviewData = batchReviewData[send.id] || {}

    // Validation
    if (!outcome) {
      alert('Select an outcome (Accept, Rework, or Reject) before submitting.')
      setApprovingBatch(null)
      return
    }
    const outcomeNote = reviewData.notes?.trim() || null
    if (outcome === 'rework' && !outcomeNote) {
      alert('Rework Instructions are required.')
      setApprovingBatch(null)
      return
    }
    if (outcome === 'rejected' && !outcomeNote) {
      alert('Rejection Reason is required.')
      setApprovingBatch(null)
      return
    }

    // Reject doesn't require qty (the rejection reason captures the action).
    // Accept and Rework both require explicit qty acknowledgment.
    if (outcome === 'accepted' || outcome === 'rework') {
      const goodStr = (reviewData.good_qty ?? '').toString().trim()
      const badStr = (reviewData.bad_qty ?? '').toString().trim()
      const goodNum = goodStr === '' ? null : parseInt(goodStr)
      const badNum = badStr === '' ? null : parseInt(badStr)

      if (goodNum == null && badNum == null) {
        alert('Enter a Good Quantity (and Bad Quantity if any) before accepting or sending to rework.')
        setApprovingBatch(null)
        return
      }
      if (outcome === 'rework' && (badNum == null || badNum < 1)) {
        alert('Enter the Bad Quantity (the number of parts being reworked) before sending to rework.')
        setApprovingBatch(null)
        return
      }
      if (goodNum != null && (Number.isNaN(goodNum) || goodNum < 0)) {
        alert('Good Quantity must be a non-negative number.')
        setApprovingBatch(null)
        return
      }
      if (badNum != null && (Number.isNaN(badNum) || badNum < 0)) {
        alert('Bad Quantity must be a non-negative number.')
        setApprovingBatch(null)
        return
      }

      const baseQty = send.verified_count ?? send.quantity ?? 0
      const totalEntered = (goodNum ?? 0) + (badNum ?? 0)
      if (totalEntered > baseQty) {
        if (!window.confirm(
          `Good (${goodNum ?? 0}) + Bad (${badNum ?? 0}) = ${totalEntered}, which is more than the verified count (${baseQty}). Continue anyway?`
        )) {
          setApprovingBatch(null)
          return
        }
      }
    }

    try {
      const isReject = outcome === 'rejected'

      // Auto-derive good_qty from bad_qty when good is unspecified, so reviewers
      // who only enter "5 bad" don't end up with a NULL good count.
      const enteredGood = reviewData.good_qty !== '' && reviewData.good_qty != null
        ? parseInt(reviewData.good_qty) : null
      const enteredBad = reviewData.bad_qty !== '' && reviewData.bad_qty != null
        ? parseInt(reviewData.bad_qty) : null
      const baseQty = send.verified_count ?? send.quantity
      const derivedGood = enteredGood != null
        ? enteredGood
        : (enteredBad != null ? Math.max(0, baseQty - enteredBad) : null)

      // 1. Update the finishing_send
      const sendUpdate = {
        compliance_status: isReject ? 'rejected' : 'approved',
        compliance_outcome: outcome,
        compliance_approved_by: profile.id,
        compliance_approved_at: now,
        compliance_notes: outcomeNote,
        compliance_good_qty: derivedGood,
        compliance_bad_qty: enteredBad,
        updated_at: now,
      }
      const { error: sendError } = await supabase
        .from('finishing_sends')
        .update(sendUpdate)
        .eq('id', send.id)
      if (sendError) throw sendError

      // Short-circuit rejected: do not check in parts, do not advance job
      if (isReject) {
        await fetchPendingBatches()
        await fetchRecentlyApprovedBatches()
        onUpdate()
        return
      }

      // 1b. Create assembly_component_checkins record if job belongs to an assembly
      const woaId = send.job?.work_order_assembly_id
      if (woaId) {
        const checkinQty = derivedGood ?? send.quantity
        const { error: checkinError } = await supabase
          .from('assembly_component_checkins')
          .insert({
            work_order_assembly_id: woaId,
            job_id: send.job_id,
            quantity_received: checkinQty,
            checked_in_by: profile.id,
            checked_in_at: now,
            condition_notes: outcomeNote,
          })
        if (checkinError) console.error('Check-in insert failed (non-fatal):', checkinError)
      }

      // 2. Advance job if applicable (same logic for accepted and rework)
      const jobId = send.job_id
      const { data: parentJob } = await supabase
        .from('jobs')
        .select('status, quantity, good_pieces, component:parts!component_id(part_type)')
        .eq('id', jobId)
        .single()

      const { data: allSends } = await supabase
        .from('finishing_sends')
        .select('id, quantity, status, compliance_status')
        .eq('job_id', jobId)

      // Only count sends that were NOT rejected toward total
      const totalSentQty = allSends
        ?.filter(s => s.compliance_status !== 'rejected')
        .reduce((sum, s) => sum + (s.quantity || 0), 0) || 0
      const jobQty = parentJob?.quantity || send.job?.quantity || 0
      // Effective target = the operator's confirmed good count from
      // kiosk Complete (jobs.good_pieces). When the operator overrides
      // below target (the short-job case), the job will never naturally
      // reach jobQty through finishing — any makeup pieces ride on a
      // re-queue job, not back through this one. Fall back to jobQty
      // for in-flight multi-batch jobs where good_pieces is still NULL.
      const effectiveTarget = (parentJob?.good_pieces != null && parentJob.good_pieces > 0)
        ? parentJob.good_pieces
        : jobQty
      const allQtySent = totalSentQty >= effectiveTarget
      const canAdvance = allQtySent && ['in_progress', 'manufacturing_complete'].includes(parentJob?.status)

      if (canAdvance) {
        const { data: externalSteps } = await supabase
          .from('job_routing_steps')
          .select('id, step_name, status')
          .eq('job_id', jobId)
          .eq('step_type', 'external')
          .in('status', ['pending', 'in_progress'])

        let nextStatus
        if (externalSteps && externalSteps.length > 0) {
          nextStatus = 'ready_for_outsourcing'
        } else {
          const partType = parentJob?.component?.part_type
          nextStatus = (partType === 'finished_good' || !FEATURES.ASSEMBLY_MODULE)
            ? 'pending_tco'
            : 'ready_for_assembly'
        }

        // Propagate rework outcome up to the job so WO Lookup can flag it
        const jobUpdate = { status: nextStatus, updated_at: now }
        if (outcome === 'rework') {
          jobUpdate.compliance_outcome = 'rework'
        }

        const { error: jobError } = await supabase
          .from('jobs')
          .update(jobUpdate)
          .eq('id', jobId)
        if (jobError) throw jobError
      }

      await fetchPendingBatches()
      await fetchRecentlyApprovedBatches()
      onUpdate()
    } catch (err) {
      console.error('Batch approval error:', err)
      alert('Failed to submit batch: ' + err.message)
    } finally {
      setApprovingBatch(null)
    }
  }

  const handleApproveRoutingRemoval = async (stepId, jobId) => {
    setApprovingRouting(stepId)
    try {
      const { error } = await supabase
        .from('job_routing_steps')
        .update({
          status: 'removed',
          removal_approved_by: profile.id,
          removal_approved_at: new Date().toISOString()
        })
        .eq('id', stepId)
      if (error) throw error
      const freshDetails = await fetchJobDetails(jobId)
      setJobDetails(prev => ({ ...prev, [jobId]: freshDetails }))
    } catch (err) {
      console.error('Error approving routing removal:', err)
      alert('Failed to approve routing change')
    }
    setApprovingRouting(null)
  }

  const handleRejectRoutingRemoval = async (stepId, jobId) => {
    setApprovingRouting(stepId)
    try {
      const { error } = await supabase
        .from('job_routing_steps')
        .update({
          status: 'pending',
          removal_reason: null,
          removal_requested_by: null,
          removal_requested_at: null
        })
        .eq('id', stepId)
      if (error) throw error
      const freshDetails = await fetchJobDetails(jobId)
      setJobDetails(prev => ({ ...prev, [jobId]: freshDetails }))
    } catch (err) {
      console.error('Error rejecting routing removal:', err)
      alert('Failed to reject routing change')
    }
    setApprovingRouting(null)
  }

  const handleRestoreRoutingStep = async (stepId, jobId) => {
    setApprovingRouting(stepId)
    try {
      const { error } = await supabase
        .from('job_routing_steps')
        .update({
          status: 'pending',
          removal_reason: null,
          removal_requested_by: null,
          removal_requested_at: null,
          removal_approved_by: null,
          removal_approved_at: null
        })
        .eq('id', stepId)
      if (error) throw error
      const freshDetails = await fetchJobDetails(jobId)
      setJobDetails(prev => ({ ...prev, [jobId]: freshDetails }))
    } catch (err) {
      console.error('Error restoring routing step:', err)
      alert('Failed to restore routing step')
    }
    setApprovingRouting(null)
  }

  const handleDirectRemoveStep = async (stepId, jobId) => {
    setApprovingRouting(stepId)
    try {
      const { error } = await supabase
        .from('job_routing_steps')
        .update({
          status: 'removed',
          removal_approved_by: profile.id,
          removal_approved_at: new Date().toISOString()
        })
        .eq('id', stepId)
      if (error) throw error
      const freshDetails = await fetchJobDetails(jobId)
      setJobDetails(prev => ({ ...prev, [jobId]: freshDetails }))
    } catch (err) {
      console.error('Error removing routing step:', err)
      alert('Failed to remove routing step')
    }
    setApprovingRouting(null)
  }

  const handleAddStepToJob = async (jobId) => {
    if (!newStepName.trim()) return
    setApprovingRouting('adding')
    try {
      const steps = jobDetails[jobId]?.routingSteps || []
      const maxOrder = steps.length > 0 ? Math.max(...steps.map(s => s.step_order)) : 0

      const { error } = await supabase
        .from('job_routing_steps')
        .insert({
          job_id: jobId,
          step_name: newStepName.trim(),
          step_type: newStepType,
          station: newStepStation.trim() || null,
          step_order: maxOrder + 1,
          status: 'pending',
          is_added_step: true,
          added_by: profile.id,
          added_at: new Date().toISOString()
        })
      if (error) throw error

      // Renumber all steps for this job
      const { data: updatedSteps } = await supabase
        .from('job_routing_steps')
        .select('id')
        .eq('job_id', jobId)
        .order('step_order')

      if (updatedSteps) {
        await Promise.all(updatedSteps.map((s, i) =>
          supabase.from('job_routing_steps').update({ step_order: i + 1 }).eq('id', s.id)
        ))
      }

      setAddingStepForJob(null)
      setNewStepName('')
      setNewStepType('internal')
      setNewStepStation('')
      const freshDetails = await fetchJobDetails(jobId)
      setJobDetails(prev => ({ ...prev, [jobId]: freshDetails }))
    } catch (err) {
      console.error('Error adding routing step:', err)
      alert('Failed to add routing step')
    }
    setApprovingRouting(null)
  }

  const handleReorderStep = async (stepId, direction, jobId) => {
    const steps = jobDetails[jobId]?.routingSteps || []
    const idx = steps.findIndex(s => s.id === stepId)
    const targetIdx = direction === 'up' ? idx - 1 : idx + 1
    if (targetIdx < 0 || targetIdx >= steps.length) return

    setApprovingRouting(stepId)
    try {
      const currentStep = steps[idx]
      const targetStep = steps[targetIdx]

      const { error: err1 } = await supabase
        .from('job_routing_steps')
        .update({ step_order: targetStep.step_order })
        .eq('id', currentStep.id)
      if (err1) throw err1

      const { error: err2 } = await supabase
        .from('job_routing_steps')
        .update({ step_order: currentStep.step_order })
        .eq('id', targetStep.id)
      if (err2) throw err2

      const freshDetails = await fetchJobDetails(jobId)
      setJobDetails(prev => ({ ...prev, [jobId]: freshDetails }))
    } catch (err) {
      console.error('Error reordering routing step:', err)
      alert('Failed to reorder routing step')
    }
    setApprovingRouting(null)
  }

  const handleResetRoutingToDefault = async (jobId) => {
    if (!confirm('Reset routing to master data defaults? This will discard all changes made by Customer Service.')) return

    const job = jobs.find(j => j.id === jobId)
    if (!job?.component?.id) return

    setApprovingRouting('resetting')
    try {
      // Delete all existing job_routing_steps for this job
      const { error: deleteError } = await supabase
        .from('job_routing_steps')
        .delete()
        .eq('job_id', jobId)
      if (deleteError) throw deleteError

      // Fetch master routing from part_routing_steps
      const { data: partRouting } = await supabase
        .from('part_routing_steps')
        .select('*')
        .eq('part_id', job.component.id)
        .eq('is_active', true)
        .order('step_order')

      // Insert fresh copies
      if (partRouting?.length > 0) {
        const jobSteps = partRouting.map(step => ({
          job_id: jobId,
          step_order: step.step_order,
          step_name: step.step_name,
          step_type: step.step_type,
          station: step.default_station,
          status: 'pending'
        }))
        const { error: insertError } = await supabase
          .from('job_routing_steps')
          .insert(jobSteps)
        if (insertError) throw insertError
      }

      // Uncheck routing reviewed
      setRoutingReviewed(prev => ({ ...prev, [jobId]: false }))

      const freshDetails = await fetchJobDetails(jobId)
      setJobDetails(prev => ({ ...prev, [jobId]: freshDetails }))
    } catch (err) {
      console.error('Error resetting routing:', err)
      alert('Failed to reset routing to defaults')
    }
    setApprovingRouting(null)
  }

  // Check if user has compliance permissions
  const isComplianceUser = profile?.role === 'compliance' || profile?.role === 'admin' || profile?.can_approve_compliance === true

  // Filter jobs by category
  // S9 workflow flip: pre-mfg compliance is gated on machine assignment.
  // Unscheduled pending_compliance jobs are invisible to Roger until April
  // (scheduler) puts them on a machine — that way Roger always reviews docs
  // against a known target machine.
  const pendingMachiningJobs = jobs.filter(job =>
    job.status === 'pending_compliance' && job.compliance_outcome !== 'hold' && job.assigned_machine_id
  )
  const heldMachiningJobs = jobs.filter(job =>
    job.status === 'pending_compliance' && job.compliance_outcome === 'hold' && job.assigned_machine_id
  )
  const pendingPostMfgJobs = jobs.filter(job => job.status === 'pending_post_manufacturing')
  const approvedUnassignedJobs = jobs.filter(job => job.status === 'ready' && !job.assigned_machine_id)
  
  // Recently approved: jobs that moved past pending_compliance in last 5 days
  // Using updated_at as proxy for approval date
  const fiveDaysAgo = new Date()
  fiveDaysAgo.setDate(fiveDaysAgo.getDate() - 5)
  const recentlyApprovedJobs = jobs.filter(job => {
    if (job.status === 'pending_compliance' || job.status === 'pending_post_manufacturing') return false
    if (job.status === 'cancelled') return false
    const updatedAt = new Date(job.updated_at)
    return updatedAt >= fiveDaysAgo
  })

  // Fetch job details from database
  const fetchJobDetails = async (jobId) => {
    const job = jobs.find(j => j.id === jobId)
    
    if (!job?.component?.id) {
      return {
        requirements: [],
        partDocs: [],
        jobDocs: [],
        routingSteps: [],
        noComponent: true
      }
    }

    let { data: requirements } = await supabase
      .from('part_document_requirements')
      .select('*, document_type:document_types(*)')
      .eq('part_id', job.component.id)

    // A3: Filter out finishing/passivation doc requirements if component doesn't require finishing
    if (!job.component?.requires_passivation && requirements) {
      requirements = requirements.filter(r => {
        const code = (r.document_type?.code || '').toLowerCase()
        const name = (r.document_type?.name || '').toLowerCase()
        return !code.includes('passivation') && !name.includes('passivation') &&
               !code.includes('finishing') && !name.includes('finishing')
      })
    }

    const { data: partDocs } = await supabase
      .from('part_documents')
      .select('*, document_type:document_types(*)')
      .eq('part_id', job.component.id)
      .eq('is_current', true)

    const { data: jobDocs } = await supabase
      .from('job_documents')
      .select('*, document_type:document_types(*)')
      .eq('job_id', jobId)
      .order('created_at', { ascending: true })

    const { data: routingSteps } = await supabase
      .from('job_routing_steps')
      .select('*')
      .eq('job_id', jobId)
      .order('step_order')

    const { data: latestSend } = await supabase
      .from('finishing_sends')
      .select('production_lot_number, finishing_lot_number, material_lot_number, chemical_lot_number, chemical_lot_number_2, incoming_count, verified_count, count_discrepancy')
      .eq('job_id', jobId)
      .eq('status', 'finishing_complete')
      .order('finishing_completed_at', { ascending: false })
      .limit(1)
      .maybeSingle()

    return {
      requirements: requirements || [],
      partDocs: partDocs || [],
      jobDocs: jobDocs || [],
      routingSteps: routingSteps || [],
      latestSend: latestSend || null
    }
  }

  const loadJobDetails = async (jobId, forceRefresh = false) => {
    if (!forceRefresh && jobDetails[jobId]) return

    const details = await fetchJobDetails(jobId)
    setJobDetails(prev => ({
      ...prev,
      [jobId]: details
    }))
  }

  const toggleJob = async (jobId) => {
    if (expandedJob === jobId) {
      setExpandedJob(null)
    } else {
      setExpandedJob(jobId)
      await loadJobDetails(jobId)
    }
  }

  const handleAdditionalUpload = async (jobId, file) => {
    // Additional Documents are ad-hoc with no document_type_id, so there is
    // no part-level slot to promote into. The opt-in checkbox does not appear
    // in this surface; this handler stays job-only by design.
    const uploadKey = jobId + '-additional'
    setUploading(uploadKey)
    try {
      const s3Path = `jobs/${jobId}`
      const { filePath, fileSize, mimeType } = await uploadDocument(file, s3Path)

      const { error: dbError } = await supabase
        .from('job_documents')
        .insert({
          job_id: jobId,
          document_type_id: null,
          file_name: file.name,
          file_url: filePath,
          file_size: fileSize,
          mime_type: mimeType,
          uploaded_by: profile.id,
          status: 'approved'
        })

      if (dbError) throw dbError

      const freshDetails = await fetchJobDetails(jobId)
      setJobDetails(prev => ({ ...prev, [jobId]: freshDetails }))
      await fetchPendingBatches()
      await fetchRecentlyApprovedBatches()
    } catch (err) {
      console.error('Additional upload error:', err)
      alert('Failed to upload document: ' + err.message)
    }
    setUploading(null)
  }

  const handleDeleteDocument = async (doc, contextJobId, contextSend) => {
    if (!doc?.id) return
    if (!window.confirm(`Delete "${doc.file_name}"? This cannot be undone.`)) return

    setUploading('delete-' + doc.id)
    try {
      const { error } = await supabase
        .from('job_documents')
        .delete()
        .eq('id', doc.id)
      if (error) throw error

      // Refresh whichever context the doc lives in
      if (contextSend) {
        await fetchBatchDetails(contextSend)
      }
      if (contextJobId) {
        const fresh = await fetchJobDetails(contextJobId)
        setJobDetails(prev => ({ ...prev, [contextJobId]: fresh }))
      }
      // Also refresh the broader job-doc lists
      await fetchPendingBatches()
      await fetchRecentlyApprovedBatches()
    } catch (err) {
      console.error('Delete failed:', err)
      alert('Failed to delete document: ' + err.message)
    } finally {
      setUploading(null)
    }
  }

  const handleFileUpload = async (jobId, documentTypeId, documentTypeCode, file, opts = {}) => {
    const { saveToPart = false, partId = null } = opts
    const uploadKey = jobId + '-' + documentTypeId
    setUploading(uploadKey)

    try {
      const s3Path = `jobs/${jobId}`
      const { filePath, fileSize, mimeType } = await uploadDocument(file, s3Path)

      const { error: dbError } = await supabase
        .from('job_documents')
        .insert({
          job_id: jobId,
          document_type_id: documentTypeId,
          file_name: file.name,
          file_url: filePath,
          file_size: fileSize,
          mime_type: mimeType,
          uploaded_by: profile.id,
          status: 'pending'
        })

      if (dbError) throw dbError

      // Pre-mfg opt-in promotion to part_documents. partId presence is the
      // contract — only pre-mfg call sites pass it.
      if (saveToPart && partId && documentTypeId) {
        const { error: promoteErr } = await promoteToPartDocument(supabase, {
          partId,
          documentTypeId,
          fileName: file.name,
          fileUrl: filePath,
          fileSize,
          mimeType,
          uploadedBy: profile.id,
          revisionNotes: null,
        })
        if (promoteErr) {
          console.error('Part-level promotion failed:', promoteErr)
          alert('Document uploaded to job, but failed to save to part: ' + promoteErr.message)
        }
      }

      const freshDetails = await fetchJobDetails(jobId)
      setJobDetails(prev => ({ ...prev, [jobId]: freshDetails }))

    } catch (err) {
      console.error('Upload error:', err)
      alert('Failed to upload document: ' + err.message)
    }

    setUploading(null)
  }

  const handleReplaceDocument = async (docId, jobId, documentTypeId, file, opts = {}) => {
    const { saveToPart = false, partId = null } = opts
    setReplacing(docId)

    try {
      const s3Path = `jobs/${jobId}`
      const { filePath, fileSize, mimeType } = await uploadDocument(file, s3Path)

      const { error: dbError } = await supabase
        .from('job_documents')
        .update({
          file_name: file.name,
          file_url: filePath,
          file_size: fileSize,
          mime_type: mimeType,
          uploaded_by: profile.id,
          status: 'pending',
          approved_by: null,
          approved_at: null,
          updated_at: new Date().toISOString()
        })
        .eq('id', docId)

      if (dbError) throw dbError

      // Pre-mfg opt-in promotion: a Replace creates a new part-level revision
      // (matches AddJobDocumentModal's behavior — versioning, not in-place edit).
      if (saveToPart && partId && documentTypeId) {
        const { error: promoteErr } = await promoteToPartDocument(supabase, {
          partId,
          documentTypeId,
          fileName: file.name,
          fileUrl: filePath,
          fileSize,
          mimeType,
          uploadedBy: profile.id,
          revisionNotes: null,
        })
        if (promoteErr) {
          console.error('Part-level promotion failed:', promoteErr)
          alert('Document replaced on job, but failed to save to part: ' + promoteErr.message)
        }
      }

      const freshDetails = await fetchJobDetails(jobId)
      setJobDetails(prev => ({ ...prev, [jobId]: freshDetails }))

    } catch (err) {
      console.error('Replace error:', err)
      alert('Failed to replace document: ' + err.message)
    }

    setReplacing(null)
  }

  const handleViewDocument = async (filePath) => {
    if (!filePath) return
    
    setViewingDoc(filePath)
    try {
      const signedUrl = await getDocumentUrl(filePath)
      window.open(signedUrl, '_blank')
    } catch (err) {
      console.error('Error getting document URL:', err)
      alert('Failed to open document: ' + err.message)
    }
    setViewingDoc(null)
  }

  const handleApproveDocument = async (docId, jobId) => {
    setApproving(docId)
    
    try {
      const { error } = await supabase
        .from('job_documents')
        .update({
          status: 'approved',
          approved_by: profile.id,
          approved_at: new Date().toISOString()
        })
        .eq('id', docId)

      if (error) throw error

      const freshDetails = await fetchJobDetails(jobId)
      setJobDetails(prev => ({ ...prev, [jobId]: freshDetails }))
      
    } catch (err) {
      console.error('Approve error:', err)
      alert('Failed to approve document')
    }
    
    setApproving(null)
  }

  const handleApproveJob = async (jobId, currentStatus, outcome, deferInfo = null) => {
    setApproving(jobId)
    const pmData = postMfgData[jobId] || {}

    // Validation
    if (!outcome) {
      alert('Select an outcome (Accept, Rework, or Reject) before submitting.')
      setApproving(null)
      return
    }
    const outcomeNote = pmData.notes?.trim() || null
    if (outcome === 'rework' && !outcomeNote) {
      alert('Rework Instructions are required.')
      setApproving(null)
      return
    }
    if (outcome === 'rejected' && !outcomeNote) {
      alert('Rejection Reason is required.')
      setApproving(null)
      return
    }
    if (outcome === 'hold' && !outcomeNote) {
      alert('Hold Reason is required.')
      setApproving(null)
      return
    }
    if (outcome === 'flag' && !outcomeNote) {
      alert('Flag Note is required.')
      setApproving(null)
      return
    }

    try {
      const now = new Date().toISOString()

      // Hold path: job does NOT advance. Just record outcome + reason.
      if (outcome === 'hold') {
        const { error } = await supabase
          .from('jobs')
          .update({
            compliance_outcome: 'hold',
            compliance_notes: outcomeNote,
            updated_at: now,
          })
          .eq('id', jobId)
        if (error) throw error
        onUpdate()
        return
      }

      // Reject path: cancel the job, record outcome + reason
      if (outcome === 'rejected') {
        const { error } = await supabase
          .from('jobs')
          .update({
            status: 'cancelled',
            compliance_outcome: 'rejected',
            compliance_notes: outcomeNote,
            updated_at: now,
          })
          .eq('id', jobId)
        if (error) throw error
        const workOrderId = jobs.find(j => j.id === jobId)?.work_order_id
        const { error: releaseErr } = await releaseCOAllocationsIfWODead(supabase, {
          workOrderId,
          profileId: profile?.id,
        })
        if (releaseErr) console.error('Failed to release CO allocations after compliance reject:', releaseErr)
        // Cancelled jobs never generate shortfalls — no evaluation here.
        onUpdate()
        return
      }

      // Accept / Rework path: determine next status (same logic either way)
      let nextStatus = 'ready'
      if (currentStatus === 'pending_compliance') {
        const job = jobs.find(j => j.id === jobId)
        if (job?.assigned_machine_id) {
          nextStatus = 'assigned'
        }
      } else if (currentStatus === 'pending_post_manufacturing') {
        const { data: externalSteps } = await supabase
          .from('job_routing_steps')
          .select('id, step_name, status')
          .eq('job_id', jobId)
          .eq('step_type', 'external')
          .in('status', ['pending', 'in_progress'])

        if (externalSteps && externalSteps.length > 0) {
          nextStatus = 'ready_for_outsourcing'
        } else {
          const job = jobs.find(j => j.id === jobId)
          const partType = job?.component?.part_type
          nextStatus = (partType === 'finished_good' || !FEATURES.ASSEMBLY_MODULE)
            ? 'pending_tco'
            : 'ready_for_assembly'
        }
      }

      const updatePayload = {
        status: nextStatus,
        compliance_outcome: outcome,
        updated_at: now,
      }
      if (outcome === 'rework' || outcome === 'flag') {
        updatePayload.compliance_notes = outcomeNote
      } else if (outcome === 'accepted') {
        updatePayload.compliance_notes = null
      }
      if (currentStatus === 'pending_post_manufacturing') {
        if (pmData.good_qty !== undefined && pmData.good_qty !== '')
          updatePayload.post_mfg_good_qty = parseInt(pmData.good_qty)
        if (pmData.bad_qty !== undefined && pmData.bad_qty !== '')
          updatePayload.post_mfg_bad_qty = parseInt(pmData.bad_qty)
        if (outcomeNote) updatePayload.post_mfg_notes = outcomeNote
        updatePayload.post_mfg_reviewed_by = profile.id
        updatePayload.post_mfg_reviewed_at = now
      }

      // Pre-mfg defer-with-note path: stamp the deferred fields and record an
      // audit_logs entry. Defense-in-depth — UI also blocks empty reason.
      const isDeferring = currentStatus === 'pending_compliance'
        && deferInfo?.defer === true
      if (isDeferring) {
        const reason = (deferInfo.reason || '').trim()
        if (!reason) {
          alert('A note is required when deferring documents.')
          setApproving(null)
          return
        }
        updatePayload.documents_deferred = true
        updatePayload.documents_deferred_reason = reason
        updatePayload.documents_deferred_by = profile.id
        updatePayload.documents_deferred_at = now
      }

      const { error } = await supabase
        .from('jobs')
        .update(updatePayload)
        .eq('id', jobId)
      if (error) throw error

      if (isDeferring) {
        await supabase.from('audit_logs').insert({
          event_type: 'compliance_documents_deferred',
          job_id: jobId,
          operator_id: profile?.id ?? null,
          details: {
            reason: deferInfo.reason.trim(),
            missing_doc_types: deferInfo.missingDocTypes || [],
          },
        })
      }

      // Post-mfg accept writes post_mfg_good_qty; evaluate this job's
      // shortfall against that value. Idempotent; no-ops when produced
      // >= target. Fires for any post-mfg accept regardless of nextStatus
      // because compliance verification can land a job below target even
      // when it routes onward (e.g. ready_for_outsourcing).
      if (currentStatus === 'pending_post_manufacturing' && jobId) {
        evaluateJobShortfall(jobId).catch(err =>
          console.error('evaluateJobShortfall failed (non-blocking):', err)
        )
      }
      onUpdate()
    } catch (err) {
      console.error('Approve job error:', err)
      alert('Failed to submit job review')
    } finally {
      setApproving(null)
    }
  }

  const handleApproveAndPrint = async (job, outcome, deferInfo = null) => {
    setApproving(job.id)
    const pmData = postMfgData[job.id] || {}

    if (!outcome) {
      alert('Select an outcome (Accept, Rework, or Reject) before submitting.')
      setApproving(null)
      return
    }
    const outcomeNote = pmData.notes?.trim() || null
    if (outcome === 'rework' && !outcomeNote) {
      alert('Rework Instructions are required.')
      setApproving(null)
      return
    }
    if (outcome === 'rejected' && !outcomeNote) {
      alert('Rejection Reason is required.')
      setApproving(null)
      return
    }
    if (outcome === 'hold' && !outcomeNote) {
      alert('Hold Reason is required.')
      setApproving(null)
      return
    }
    if (outcome === 'flag' && !outcomeNote) {
      alert('Flag Note is required.')
      setApproving(null)
      return
    }

    try {
      const now = new Date().toISOString()

      // Hold path: no status change, no print, just record.
      if (outcome === 'hold') {
        const { error } = await supabase
          .from('jobs')
          .update({
            compliance_outcome: 'hold',
            compliance_notes: outcomeNote,
            updated_at: now,
          })
          .eq('id', job.id)
        if (error) throw error
        onUpdate()
        return
      }

      if (outcome === 'rejected') {
        const { error } = await supabase
          .from('jobs')
          .update({
            status: 'cancelled',
            compliance_outcome: 'rejected',
            compliance_notes: outcomeNote,
            updated_at: now,
          })
          .eq('id', job.id)
        if (error) throw error
        const { error: releaseErr } = await releaseCOAllocationsIfWODead(supabase, {
          workOrderId: job.work_order_id,
          profileId: profile?.id,
        })
        if (releaseErr) console.error('Failed to release CO allocations after compliance reject:', releaseErr)
        // Cancelled jobs never generate shortfalls — no evaluation here.
        onUpdate()
        return
        // No print for rejected jobs.
      }

      let nextStatus = 'ready'
      if (job.status === 'pending_compliance') {
        if (job.assigned_machine_id) nextStatus = 'assigned'
      } else if (job.status === 'pending_post_manufacturing') {
        const { data: externalSteps } = await supabase
          .from('job_routing_steps')
          .select('id, step_name, status')
          .eq('job_id', job.id)
          .eq('step_type', 'external')
          .in('status', ['pending', 'in_progress'])

        if (externalSteps && externalSteps.length > 0) {
          nextStatus = 'ready_for_outsourcing'
        } else {
          const partType = job.component?.part_type
          nextStatus = (partType === 'finished_good' || !FEATURES.ASSEMBLY_MODULE)
            ? 'pending_tco'
            : 'ready_for_assembly'
        }
      }

      const updatePayload = {
        status: nextStatus,
        compliance_outcome: outcome,
        updated_at: now,
      }
      if (outcome === 'rework' || outcome === 'flag') {
        updatePayload.compliance_notes = outcomeNote
      } else if (outcome === 'accepted') {
        updatePayload.compliance_notes = null
      }
      if (job.status === 'pending_post_manufacturing') {
        if (pmData.good_qty !== undefined && pmData.good_qty !== '')
          updatePayload.post_mfg_good_qty = parseInt(pmData.good_qty)
        if (pmData.bad_qty !== undefined && pmData.bad_qty !== '')
          updatePayload.post_mfg_bad_qty = parseInt(pmData.bad_qty)
        if (outcomeNote) updatePayload.post_mfg_notes = outcomeNote
        updatePayload.post_mfg_reviewed_by = profile.id
        updatePayload.post_mfg_reviewed_at = now
      }

      // Pre-mfg defer-with-note: same treatment as handleApproveJob.
      const isDeferring = job.status === 'pending_compliance'
        && deferInfo?.defer === true
      if (isDeferring) {
        const reason = (deferInfo.reason || '').trim()
        if (!reason) {
          alert('A note is required when deferring documents.')
          setApproving(null)
          return
        }
        updatePayload.documents_deferred = true
        updatePayload.documents_deferred_reason = reason
        updatePayload.documents_deferred_by = profile.id
        updatePayload.documents_deferred_at = now
      }

      const { error } = await supabase
        .from('jobs')
        .update(updatePayload)
        .eq('id', job.id)
      if (error) throw error

      if (isDeferring) {
        await supabase.from('audit_logs').insert({
          event_type: 'compliance_documents_deferred',
          job_id: job.id,
          operator_id: profile?.id ?? null,
          details: {
            reason: deferInfo.reason.trim(),
            missing_doc_types: deferInfo.missingDocTypes || [],
          },
        })
      }

      // Post-mfg accept writes post_mfg_good_qty — evaluate this job's
      // shortfall against that. Idempotent; no-ops when produced >= target.
      if (job.status === 'pending_post_manufacturing' && job.id) {
        evaluateJobShortfall(job.id).catch(err =>
          console.error('evaluateJobShortfall failed (non-blocking):', err)
        )
      }

      onUpdate()
      setPrintPackageJob(job)
    } catch (err) {
      console.error('Approve job error:', err)
      alert('Failed to submit job review')
    } finally {
      setApproving(null)
    }
  }

  const handleRecallJob = async (jobId) => {
    if (!confirm('Recall this job to Pending Compliance? All document approvals will be preserved.')) return
    
    setRecalling(jobId)
    
    try {
      const { error } = await supabase
        .from('jobs')
        .update({ 
          status: 'pending_compliance',
          updated_at: new Date().toISOString()
        })
        .eq('id', jobId)

      if (error) throw error
      onUpdate()
      
    } catch (err) {
      console.error('Recall job error:', err)
      alert('Failed to recall job: ' + err.message)
    }
    
    setRecalling(null)
  }

  // Get ALL documents for a given type
  const getDocumentsForType = (jobId, docTypeId) => {
    const details = jobDetails[jobId]
    if (!details) return []
    return details.jobDocs.filter(d => d.document_type_id === docTypeId)
  }

  // Check if requirement has at least one approved document
  const hasApprovedDocument = (jobId, docTypeId) => {
    const docs = getDocumentsForType(jobId, docTypeId)
    return docs.some(d => d.status === 'approved')
  }

  const canApproveJob = (jobId, requiredStage) => {
    const details = jobDetails[jobId]
    if (!details) return false
    if (details.noComponent) return true
    
    const stageReqs = details.requirements.filter(r => 
      r.required_at === requiredStage || (!r.required_at && requiredStage === 'compliance_review')
    )
    
    if (stageReqs.length === 0) return true

    for (const req of stageReqs) {
      if (!req.is_required) continue
      if (!hasApprovedDocument(jobId, req.document_type_id)) return false
    }
    
    return true
  }

  const getPriorityColor = (priority) => {
    if (priority === 'critical') return 'bg-red-500'
    if (priority === 'high') return 'bg-yellow-500'
    if (priority === 'normal') return 'bg-green-500'
    return 'bg-gray-500'
  }

  const getPriorityBorder = (priority) => {
    if (priority === 'critical') return 'border-red-700'
    if (priority === 'high') return 'border-yellow-700'
    if (priority === 'normal') return 'border-green-700'
    return 'border-gray-700'
  }

  const getDocBgClass = (status) => {
    if (status === 'approved') return 'bg-green-900/20 border-green-800'
    if (status === 'pending') return 'bg-yellow-900/20 border-yellow-800'
    return 'bg-gray-700 border-gray-600'
  }

  const getStageLabel = (stage) => {
    if (stage === 'manufacturing_complete') return 'After Manufacturing'
    if (stage === 'tco') return 'Before TCO'
    return 'Compliance Review'
  }

  const getStatusBadge = (status) => {
    const statusConfig = {
      'ready': { label: 'Ready', color: 'bg-green-600' },
      'assigned': { label: 'Assigned', color: 'bg-blue-600' },
      'in_progress': { label: 'In Progress', color: 'bg-blue-500' },
      'manufacturing_complete': { label: 'Mfg Complete', color: 'bg-purple-600' },
      'pending_post_manufacturing': { label: 'Post-Mfg Review', color: 'bg-purple-500' },
      'ready_for_assembly': { label: 'Ready for Assembly', color: 'bg-green-500' },
      'ready_for_outsourcing': { label: 'Ready for Outsourcing', color: 'bg-orange-500' },
      'at_external_vendor': { label: 'At External Vendor', color: 'bg-blue-500' },
      'complete': { label: 'Complete', color: 'bg-gray-600' }
    }
    const config = statusConfig[status] || { label: status, color: 'bg-gray-600' }
    return (
      <span className={`text-xs px-2 py-0.5 rounded ${config.color} text-white`}>
        {config.label}
      </span>
    )
  }

  const formatDate = (dateStr) => {
    if (!dateStr) return '-'
    return new Date(dateStr).toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: 'numeric'
    })
  }

  const ViewButton = ({ filePath }) => {
    if (!filePath) return null
    const isLoading = viewingDoc === filePath

    return (
      <button
        onClick={() => handleViewDocument(filePath)}
        disabled={isLoading}
        className="flex items-center gap-1 px-2 py-1 text-xs bg-gray-600 hover:bg-gray-500 text-white rounded disabled:opacity-50"
      >
        {isLoading ? <Loader2 size={12} className="animate-spin" /> : <Eye size={12} />}
        View
      </button>
    )
  }

  const DeleteButton = ({ doc, contextJobId, contextSend, disabled }) => {
    if (!isComplianceUser) return null
    const isDeleting = uploading === 'delete-' + doc.id
    return (
      <button
        onClick={(e) => {
          e.stopPropagation()
          handleDeleteDocument(doc, contextJobId, contextSend)
        }}
        disabled={disabled || isDeleting}
        title="Delete document"
        className="flex items-center gap-1 px-2 py-1 text-xs bg-red-900/40 hover:bg-red-900/70 text-red-400 rounded transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {isDeleting ? <Loader2 size={12} className="animate-spin" /> : <X size={12} />}
        Delete
      </button>
    )
  }

  // Render a pending review section (shared for machining and post-mfg)
  const renderPendingSection = (sectionJobs, title, borderColor, requiredStage, showPhaseLabel = false, isHeldSection = false) => {
    if (sectionJobs.length === 0) return null

    return (
      <div className={`bg-gray-900 rounded-lg border ${borderColor} p-4`}>
        <div className="flex items-center justify-between mb-4">
          <h3 className={`font-semibold flex items-center gap-2 ${isHeldSection ? 'text-slate-400' : 'text-purple-400'}`}>
            {isHeldSection ? <Pause size={18} /> : <Clock size={18} />}
            {title} ({sectionJobs.length})
          </h3>
        </div>
        
        <div className="space-y-2">
          {sectionJobs.map(job => {
            const isExpanded = expandedJob === job.id
            const details = jobDetails[job.id]
            const jobCanApprove = details ? canApproveJob(job.id, requiredStage) : false
            const borderClass = getPriorityBorder(job.priority)
            const dotClass = getPriorityColor(job.priority)

            const stageReqs = details?.requirements?.filter(r => 
              r.required_at === requiredStage || (!r.required_at && requiredStage === 'compliance_review')
            ) || []
            const futureReqs = details?.requirements?.filter(r => 
              r.required_at !== requiredStage && (r.required_at || requiredStage !== 'compliance_review')
            ) || []

            return (
              <div key={job.id} className="bg-gray-800 rounded-lg overflow-hidden">
                <div 
                  className={"flex items-center justify-between p-3 cursor-pointer hover:bg-gray-750 border-l-4 " + borderClass}
                  onClick={() => toggleJob(job.id)}
                >
                  <div className="flex items-center gap-4">
                    {isExpanded ? (
                      <ChevronDown size={18} className="text-purple-400" />
                    ) : (
                      <ChevronRight size={18} className="text-gray-500" />
                    )}
                    <div className={"w-3 h-3 rounded-full " + dotClass}></div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-white font-mono">{job.component?.part_number || job.job_number}</span>
                        <span className="text-gray-500">•</span>
                        <span className="text-gray-400">{job.work_order?.wo_number}</span>
                        {job.work_order?.order_type === 'make_to_stock' && (
                          <span className="text-xs px-2 py-0.5 bg-green-900/50 text-green-400 rounded">Stock</span>
                        )}
                        {job.has_open_shortfall && (
                          <span
                            className="inline-flex items-center gap-1 text-xs px-1.5 py-0.5 rounded bg-red-950/60 text-red-300 border border-red-700"
                            title="This job has an unresolved shortfall — Scheduler review needed"
                          >
                            <AlertTriangle size={10} /> Shortfall
                          </span>
                        )}
                        <DocsDeferredBadge job={job} />
                      </div>
                      <div className="text-sm text-gray-500">
                        <span className="text-skynet-accent font-mono">{job.job_number}</span>
                        <span className="mx-2">•</span>
                        <span>Qty: {job.quantity}</span>
                        {job.assigned_machine && (
                          <>
                            <span className="mx-2">•</span>
                            <span className="text-skynet-accent font-mono">
                              {job.assigned_machine.code || job.assigned_machine.name}
                            </span>
                          </>
                        )}
                        {job.work_order?.customer && (
                          <span className="mx-2">• {job.work_order.customer}</span>
                        )}
                      </div>
                      {isHeldSection && job.compliance_notes && (
                        <div className="mt-1 text-xs text-slate-400 italic flex items-center gap-1">
                          <Pause size={12} />
                          <span className="truncate">{job.compliance_notes}</span>
                        </div>
                      )}
                    </div>
                  </div>

                </div>

                {isExpanded && (() => {
                  const allSteps = details?.routingSteps || []
                  const hasRouting = allSteps.length > 0
                  const hasPendingRemovals = allSteps.some(s => s.status === 'removal_pending')
                  const isRoutingChecked = !!routingReviewed[job.id]
                  const canEditRouting = isComplianceUser && job.status === 'pending_compliance'

                  return (
                  <div className="border-t border-gray-700 p-4">
                    {/* On-Hold banner — shown at the top of the expanded card when
                        a previous compliance review placed this job on hold. */}
                    {job.compliance_outcome === 'hold' && (
                      <div className="mb-4 p-3 bg-slate-800/60 border border-slate-600 rounded flex items-start gap-2">
                        <Pause size={18} className="text-slate-300 mt-0.5 flex-shrink-0" />
                        <div className="min-w-0">
                          <div className="text-slate-200 text-sm font-semibold">Currently on Hold</div>
                          {job.compliance_notes && (
                            <div className="text-slate-400 text-xs mt-1 whitespace-pre-wrap">{job.compliance_notes}</div>
                          )}
                        </div>
                      </div>
                    )}
                    {/* Full Routing Display — only for pre-mfg compliance review */}
                    {requiredStage === 'compliance_review' && hasRouting && (
                      <div className="mb-4 pb-4 border-b border-gray-700">
                        <h4 className="text-gray-400 text-sm font-medium mb-2 flex items-center gap-2">
                          Routing
                          {hasPendingRemovals && (
                            <span className="text-xs px-1.5 py-0.5 bg-amber-900/50 text-amber-400 rounded">Action Required</span>
                          )}
                          {canEditRouting && (
                            <button
                              onClick={() => handleResetRoutingToDefault(job.id)}
                              disabled={approvingRouting === 'resetting'}
                              className="flex items-center gap-1 ml-auto text-xs text-gray-500 hover:text-orange-400 disabled:opacity-50"
                            >
                              {approvingRouting === 'resetting' ? (
                                <Loader2 size={12} className="animate-spin" />
                              ) : (
                                <Undo2 size={12} />
                              )}
                              Reset to Default
                            </button>
                          )}
                        </h4>
                        <div className="space-y-1">
                          {allSteps.map((step, stepIndex) => {
                            const isRemovalPending = step.status === 'removal_pending'
                            const isRemoved = step.status === 'removed'
                            const isAdded = step.is_added_step

                            return (
                              <div key={step.id}>
                                <div className={`flex items-center gap-2 text-sm py-1 px-2 rounded ${
                                  isRemovalPending ? 'bg-amber-900/10 border border-amber-800/50' :
                                  isRemoved ? 'bg-gray-800/50' : ''
                                }`}>
                                  <span className="text-gray-600 w-6 text-right">{step.step_order}.</span>
                                  <span className={
                                    isRemovalPending ? 'text-red-400 line-through' :
                                    isRemoved ? 'text-gray-600 line-through' :
                                    'text-gray-300'
                                  }>{step.step_name}</span>
                                  {step.station && (
                                    <span className="text-gray-600">({step.station})</span>
                                  )}
                                  {step.step_type === 'external' && (
                                    <span className="text-xs px-1 bg-orange-900/30 text-orange-400 rounded">External</span>
                                  )}
                                  {isAdded && (
                                    <span className="text-xs px-1 bg-green-900/30 text-green-400 rounded">Added</span>
                                  )}
                                  {isRemoved && (
                                    <>
                                      <span className="text-xs px-1 bg-gray-700 text-gray-500 rounded">Removed</span>
                                      {isComplianceUser && job.status === 'pending_compliance' && (
                                        <button
                                          onClick={() => handleRestoreRoutingStep(step.id, job.id)}
                                          disabled={approvingRouting === step.id}
                                          className="flex items-center gap-1 px-1.5 py-0.5 text-xs text-gray-400 hover:text-white border border-gray-600 hover:border-gray-500 rounded disabled:opacity-50"
                                        >
                                          {approvingRouting === step.id ? (
                                            <Loader2 size={10} className="animate-spin" />
                                          ) : (
                                            <Undo2 size={10} />
                                          )}
                                          Restore
                                        </button>
                                      )}
                                    </>
                                  )}
                                  {canEditRouting && !isRemoved && !isRemovalPending && (
                                    <div className="flex items-center gap-1 ml-auto">
                                      {stepIndex > 0 && (
                                        <button
                                          onClick={() => handleReorderStep(step.id, 'up', job.id)}
                                          disabled={approvingRouting === step.id}
                                          className="p-0.5 text-gray-500 hover:text-white rounded disabled:opacity-50"
                                          title="Move up"
                                        >
                                          <ArrowUp size={12} />
                                        </button>
                                      )}
                                      {stepIndex < allSteps.length - 1 && (
                                        <button
                                          onClick={() => handleReorderStep(step.id, 'down', job.id)}
                                          disabled={approvingRouting === step.id}
                                          className="p-0.5 text-gray-500 hover:text-white rounded disabled:opacity-50"
                                          title="Move down"
                                        >
                                          <ArrowDown size={12} />
                                        </button>
                                      )}
                                      <button
                                        onClick={() => handleDirectRemoveStep(step.id, job.id)}
                                        disabled={approvingRouting === step.id}
                                        className="p-0.5 text-gray-500 hover:text-red-400 rounded disabled:opacity-50 ml-1"
                                        title="Remove step"
                                      >
                                        <X size={12} />
                                      </button>
                                    </div>
                                  )}
                                  {isRemovalPending && isComplianceUser && (
                                    <div className="flex items-center gap-1 ml-auto">
                                      {canEditRouting && (
                                        <>
                                          {stepIndex > 0 && (
                                            <button
                                              onClick={() => handleReorderStep(step.id, 'up', job.id)}
                                              disabled={approvingRouting === step.id}
                                              className="p-0.5 text-gray-500 hover:text-white rounded disabled:opacity-50"
                                              title="Move up"
                                            >
                                              <ArrowUp size={12} />
                                            </button>
                                          )}
                                          {stepIndex < allSteps.length - 1 && (
                                            <button
                                              onClick={() => handleReorderStep(step.id, 'down', job.id)}
                                              disabled={approvingRouting === step.id}
                                              className="p-0.5 text-gray-500 hover:text-white rounded disabled:opacity-50"
                                              title="Move down"
                                            >
                                              <ArrowDown size={12} />
                                            </button>
                                          )}
                                          <button
                                            onClick={() => handleDirectRemoveStep(step.id, job.id)}
                                            disabled={approvingRouting === step.id}
                                            className="p-0.5 text-gray-500 hover:text-red-400 rounded disabled:opacity-50 ml-1"
                                            title="Remove step"
                                          >
                                            <X size={12} />
                                          </button>
                                          <span className="w-px h-4 bg-gray-600 mx-1" />
                                        </>
                                      )}
                                      <button
                                        onClick={() => handleRejectRoutingRemoval(step.id, job.id)}
                                        disabled={approvingRouting === step.id}
                                        className="flex items-center gap-1 px-2 py-0.5 text-xs bg-gray-600 hover:bg-gray-500 text-white rounded disabled:opacity-50"
                                      >
                                        <X size={10} />
                                        Reject
                                      </button>
                                      <button
                                        onClick={() => handleApproveRoutingRemoval(step.id, job.id)}
                                        disabled={approvingRouting === step.id}
                                        className="flex items-center gap-1 px-2 py-0.5 text-xs bg-green-600 hover:bg-green-500 text-white rounded disabled:opacity-50"
                                      >
                                        {approvingRouting === step.id ? (
                                          <Loader2 size={10} className="animate-spin" />
                                        ) : (
                                          <Check size={10} />
                                        )}
                                        Approve
                                      </button>
                                    </div>
                                  )}
                                </div>
                                {isRemovalPending && (
                                  <div className="text-xs text-amber-400/80 ml-8 mb-1">
                                    Removal requested &mdash; {step.removal_reason}
                                  </div>
                                )}
                              </div>
                            )
                          })}
                        </div>
                        {/* Add Step */}
                        {canEditRouting && (
                          <div className="mt-2">
                            {addingStepForJob === job.id ? (
                              <div className="flex items-center gap-2 text-sm py-1.5 px-2 bg-gray-800 rounded border border-gray-600">
                                <input
                                  type="text"
                                  placeholder="Step name"
                                  value={newStepName}
                                  onChange={(e) => setNewStepName(e.target.value)}
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter') handleAddStepToJob(job.id)
                                    if (e.key === 'Escape') { setAddingStepForJob(null); setNewStepName(''); setNewStepType('internal'); setNewStepStation('') }
                                  }}
                                  className="bg-gray-700 text-white text-xs px-2 py-1 rounded border border-gray-600 w-40"
                                  autoFocus
                                />
                                <select
                                  value={newStepType}
                                  onChange={(e) => setNewStepType(e.target.value)}
                                  className="bg-gray-700 text-white text-xs px-2 py-1 rounded border border-gray-600"
                                >
                                  <option value="internal">Internal</option>
                                  <option value="external">External</option>
                                </select>
                                <input
                                  type="text"
                                  placeholder="Station (optional)"
                                  value={newStepStation}
                                  onChange={(e) => setNewStepStation(e.target.value)}
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter') handleAddStepToJob(job.id)
                                    if (e.key === 'Escape') { setAddingStepForJob(null); setNewStepName(''); setNewStepType('internal'); setNewStepStation('') }
                                  }}
                                  className="bg-gray-700 text-white text-xs px-2 py-1 rounded border border-gray-600 w-32"
                                />
                                <button
                                  onClick={() => handleAddStepToJob(job.id)}
                                  disabled={!newStepName.trim() || approvingRouting === 'adding'}
                                  className="flex items-center gap-1 px-2 py-1 text-xs bg-green-600 hover:bg-green-500 text-white rounded disabled:opacity-50"
                                >
                                  {approvingRouting === 'adding' ? (
                                    <Loader2 size={10} className="animate-spin" />
                                  ) : (
                                    <Plus size={10} />
                                  )}
                                  Add
                                </button>
                                <button
                                  onClick={() => { setAddingStepForJob(null); setNewStepName(''); setNewStepType('internal'); setNewStepStation('') }}
                                  className="px-2 py-1 text-xs text-gray-400 hover:text-white"
                                >
                                  Cancel
                                </button>
                              </div>
                            ) : (
                              <button
                                onClick={() => setAddingStepForJob(job.id)}
                                className="flex items-center gap-1 text-xs text-gray-500 hover:text-green-400 px-2 py-1"
                              >
                                <Plus size={12} />
                                Add Step
                              </button>
                            )}
                          </div>
                        )}
                        {/* Routing reviewed checkbox */}
                        {isComplianceUser && (
                          <label className="flex items-center gap-2 mt-3 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={isRoutingChecked}
                              onChange={(e) => setRoutingReviewed(prev => ({ ...prev, [job.id]: e.target.checked }))}
                              className="w-4 h-4 rounded border-gray-600 bg-gray-700 text-green-500 focus:ring-green-500 focus:ring-offset-0"
                            />
                            <span className="text-sm text-gray-400">Routing reviewed and approved</span>
                          </label>
                        )}
                      </div>
                    )}

                    <h4 className="text-gray-400 text-sm font-medium mb-3">Required Documents</h4>

                    {!details && (
                      <div className="text-gray-500 text-sm flex items-center gap-2">
                        <Loader2 size={16} className="animate-spin" />
                        Loading documents...
                      </div>
                    )}

                    {details && details.noComponent && (
                      <div className="text-yellow-500 text-sm bg-yellow-900/20 p-3 rounded">
                        This job has no component linked.
                      </div>
                    )}

                    {details && !details.noComponent && stageReqs.length === 0 && (
                      <div className="text-green-500 text-sm bg-green-900/20 p-3 rounded">
                        No documents required at this stage.
                      </div>
                    )}

                    {details && !details.noComponent && stageReqs.length > 0 && (
                      <div className="space-y-4">
                        {stageReqs.map(req => {
                          const docsForType = getDocumentsForType(job.id, req.document_type_id)
                          const hasAnyDocs = docsForType.length > 0
                          const uploadKey = job.id + '-' + req.document_type_id
                          const isUploading = uploading === uploadKey

                          return (
                            <div key={req.id} className="space-y-2">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                  <span className="text-white text-sm font-medium">{req.document_type.name}</span>
                                  {req.is_required && <span className="text-xs text-red-400">Required</span>}
                                  {hasApprovedDocument(job.id, req.document_type_id) && (
                                    <CheckCircle size={14} className="text-green-500" />
                                  )}
                                </div>

                                <label className="flex items-center gap-1 px-2 py-1 text-xs bg-blue-600 hover:bg-blue-500 text-white rounded cursor-pointer">
                                  {isUploading ? (
                                    <Loader2 size={12} className="animate-spin" />
                                  ) : hasAnyDocs ? (
                                    <Plus size={12} />
                                  ) : (
                                    <Upload size={12} />
                                  )}
                                  {isUploading ? 'Uploading...' : hasAnyDocs ? 'Add More' : 'Upload'}
                                  <input
                                    type="file"
                                    className="hidden"
                                    onChange={(e) => {
                                      const selectedFile = e.target.files[0]
                                      if (selectedFile) {
                                        // Required-slot uploads at pre-mfg auto-promote unconditionally:
                                        // these slots are part-level by nature (Drawing, Production Log Blank).
                                        // Post-mfg slots (Production Log Filled, Passivation Card, etc.) stay job-only.
                                        const promote = requiredStage === 'compliance_review' && !!job.component_id
                                        handleFileUpload(job.id, req.document_type_id, req.document_type.code, selectedFile, {
                                          saveToPart: promote,
                                          partId: promote ? job.component_id : null,
                                        })
                                      }
                                      e.target.value = ''
                                    }}
                                    disabled={isUploading}
                                  />
                                </label>
                              </div>

                              {!hasAnyDocs && (
                                <div className="flex items-center gap-2 p-3 rounded border border-gray-600 bg-gray-700">
                                  <AlertCircle size={16} className="text-gray-500" />
                                  <span className="text-gray-400 text-sm">No document uploaded</span>
                                </div>
                              )}

                              {docsForType.map((doc, index) => {
                                const isDocApproved = doc.status === 'approved'
                                const bgClass = getDocBgClass(doc.status)
                                const isReplacing = replacing === doc.id

                                return (
                                  <div key={doc.id} className={"flex items-center justify-between p-3 rounded border " + bgClass}>
                                    <div className="flex items-center gap-3">
                                      {isDocApproved && <CheckCircle size={18} className="text-green-500" />}
                                      {doc.status === 'pending' && <Clock size={18} className="text-yellow-500" />}

                                      <div>
                                        <div className="text-xs text-gray-500">{doc.file_name}</div>
                                        {docsForType.length > 1 && (
                                          <div className="text-xs text-gray-600">Document {index + 1}</div>
                                        )}
                                      </div>
                                    </div>

                                    <div className="flex items-center gap-2">
                                      <ViewButton filePath={doc.file_url} />
                                      <DeleteButton doc={doc} contextJobId={job.id} />

                                      {isComplianceUser && (
                                        <label className="flex items-center gap-1 px-2 py-1 text-xs bg-orange-600 hover:bg-orange-500 text-white rounded cursor-pointer">
                                          {isReplacing ? (
                                            <Loader2 size={12} className="animate-spin" />
                                          ) : (
                                            <RefreshCw size={12} />
                                          )}
                                          {isReplacing ? '...' : 'Replace'}
                                          <input
                                            type="file"
                                            className="hidden"
                                            onChange={(e) => {
                                              const selectedFile = e.target.files[0]
                                              if (selectedFile) {
                                                // Same auto-promote rule as Upload: pre-mfg only.
                                                const promote = requiredStage === 'compliance_review' && !!job.component_id
                                                handleReplaceDocument(doc.id, job.id, req.document_type_id, selectedFile, {
                                                  saveToPart: promote,
                                                  partId: promote ? job.component_id : null,
                                                })
                                              }
                                              e.target.value = ''
                                            }}
                                            disabled={isReplacing}
                                          />
                                        </label>
                                      )}

                                      {doc.status === 'pending' && canWrite && (
                                        <button
                                          onClick={() => handleApproveDocument(doc.id, job.id)}
                                          disabled={approving === doc.id}
                                          className="flex items-center gap-1 px-2 py-1 text-xs bg-green-600 hover:bg-green-500 text-white rounded"
                                        >
                                          {approving === doc.id ? (
                                            <Loader2 size={12} className="animate-spin" />
                                          ) : (
                                            <Check size={12} />
                                          )}
                                          {approving === doc.id ? '...' : 'Approve'}
                                        </button>
                                      )}
                                    </div>
                                  </div>
                                )
                              })}
                            </div>
                          )
                        })}
                      </div>
                    )}

                    {/* Additional Documents — uses AddJobDocumentModal so the
                        operator gets a typed picker + opt-in "save to part"
                        checkbox. Inline file input was the prior pattern but
                        gave no way to express promotion intent. */}
                    {isComplianceUser && (
                      <div className="mt-4">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="text-gray-400 text-sm font-medium">Additional Documents</h4>
                          <button
                            onClick={() => setAdditionalDocFor({ jobId: job.id, partId: job.component_id || null })}
                            className="flex items-center gap-1 px-2 py-1 text-xs bg-gray-700 hover:bg-gray-600 text-gray-200 rounded transition-colors"
                          >
                            <Upload size={12} />
                            Upload Document
                          </button>
                        </div>
                        {(details?.jobDocs || [])
                          .filter(d => {
                            // Show docs that aren't already slotted as a
                            // Required Document at this stage. Legacy docs
                            // with null document_type_id pass through; docs
                            // whose type matches a stageReqs entry are
                            // rendered above in Required Documents and must
                            // be excluded here to avoid duplication.
                            if (!d.document_type_id) return true
                            return !stageReqs.some(r => r.document_type_id === d.document_type_id)
                          })
                          .map(doc => (
                            <div key={doc.id} className="flex items-center justify-between p-3 rounded border border-gray-700 bg-gray-800 mb-2">
                              <div className="flex items-center gap-3">
                                <FileText size={16} className="text-gray-400" />
                                <span className="text-xs text-gray-400">{doc.file_name}</span>
                              </div>
                              <div className="flex items-center gap-1.5">
                                <ViewButton filePath={doc.file_url} />
                                <DeleteButton doc={doc} contextJobId={job.id} />
                              </div>
                            </div>
                          ))
                        }
                      </div>
                    )}

                    {/* Show finishing info if applicable */}
                    {job.finishing_end && (
                      <div className="mt-2 text-xs text-cyan-400 flex items-center gap-1">
                        <Beaker size={12} />
                        Finished: {new Date(job.finishing_end).toLocaleString()}
                      </div>
                    )}

                    {/* Future Documents Section */}
                    {details && !details.noComponent && futureReqs.length > 0 && (
                      <div className="mt-6">
                        <h4 className="text-gray-500 text-sm font-medium mb-3 flex items-center gap-2">
                          <FileText size={16} />
                          Documents Required Later
                        </h4>
                        <div className="space-y-2">
                          {futureReqs.map(req => {
                            const docsForType = getDocumentsForType(job.id, req.document_type_id)
                            const hasDoc = docsForType.length > 0

                            return (
                              <div key={req.id} className="flex items-center justify-between p-3 rounded border border-gray-700 bg-gray-800/50">
                                <div className="flex items-center gap-3">
                                  <FileText size={18} className="text-gray-600" />
                                  <div>
                                    <div className="flex items-center gap-2">
                                      <span className="text-gray-400 text-sm">{req.document_type.name}</span>
                                      <span className="text-xs px-2 py-0.5 bg-gray-700 text-gray-400 rounded">
                                        {getStageLabel(req.required_at)}
                                      </span>
                                    </div>
                                    {hasDoc && <div className="text-xs text-green-500">Already uploaded ({docsForType.length})</div>}
                                  </div>
                                </div>
                                {hasDoc && <ViewButton filePath={docsForType[0].file_url} />}
                              </div>
                            )
                          })}
                        </div>
                      </div>
                    )}

                    {/* Footer — outcome selector + submit actions. Hidden for read-only roles. */}
                    {canWrite && (
                    <div className="mt-4 pt-4 border-t border-gray-700">
                      <div className="space-y-2 mb-3">
                        {jobCanApprove ? (
                          <span className="text-green-400 text-sm flex items-center gap-1">
                            <CheckCircle size={14} />
                            All required documents approved
                          </span>
                        ) : (
                          <span className="text-yellow-400 text-sm flex items-center gap-1">
                            <AlertCircle size={14} />
                            Missing or pending documents
                          </span>
                        )}
                        {hasRouting && !isRoutingChecked && (
                          <span className="text-yellow-400 text-sm flex items-center gap-1">
                            <AlertCircle size={14} />
                            Routing review required
                          </span>
                        )}
                        {hasPendingRemovals && (
                          <span className="text-amber-400 text-sm flex items-center gap-1">
                            <AlertCircle size={14} />
                            Unresolved routing removal requests
                          </span>
                        )}
                      </div>

                      {/* Outcome selector */}
                      <div className="mb-4">
                        {renderOutcomeSelector({
                          variant: isHeldSection ? 'pre-mfg-held' : 'pre-mfg',
                          outcome: postMfgData[job.id]?.outcome,
                          onOutcomeChange: (v) => setPostMfgData(prev => ({
                            ...prev,
                            [job.id]: { ...prev[job.id], outcome: v }
                          })),
                          noteValue: postMfgData[job.id]?.notes,
                          onNoteChange: (v) => setPostMfgData(prev => ({
                            ...prev,
                            [job.id]: { ...prev[job.id], notes: v }
                          })),
                          disabled: approving === job.id,
                        })}
                      </div>

                      {(() => {
                        const outcome = postMfgData[job.id]?.outcome
                        const outcomeNote = (postMfgData[job.id]?.notes || '').trim()
                        // Pre-mfg outcomes: accepted, hold, flag
                        // Hold bypasses doc guard; accepted and flag require it.
                        const needsDocGuard = outcome === 'accepted' || outcome === 'flag'
                        const outcomeValid = outcome === 'accepted'
                          || (outcome === 'hold' && outcomeNote.length > 0)
                          || (outcome === 'flag' && outcomeNote.length > 0)
                        // Defer-with-note (pre-mfg only): when required docs are
                        // missing but the job must move forward, compliance can
                        // approve with a recorded reason. Auto-clears when all
                        // required docs are later uploaded (AddJobDocumentModal).
                        // Gated on !jobCanApprove (docs-only) — routing review
                        // is a separate gate handled below.
                        const isPreMfg = requiredStage === 'compliance_review'
                        const hasMissingDocs = !jobCanApprove
                        const defer = isPreMfg && hasMissingDocs && !!deferData[job.id]?.defer
                        const deferReason = (deferData[job.id]?.reason || '').trim()
                        const deferActive = defer && needsDocGuard
                        // Split routing/doc gates so a deferred-doc submit
                        // still blocks on routing-not-reviewed or pending removals.
                        const routingOk = (!hasRouting || isRoutingChecked) && !hasPendingRemovals
                        const docsOk = jobCanApprove || (deferActive && deferReason.length > 0)
                        const submitEnabled = outcomeValid
                          && (!needsDocGuard || (routingOk && docsOk))
                          && approving !== job.id
                        const missingDocTypes = isPreMfg
                          ? stageReqs.filter(r => r.is_required && !hasApprovedDocument(job.id, r.document_type_id)).map(r => r.document_type_id)
                          : []
                        const deferInfo = deferActive
                          ? { defer: true, reason: deferReason, missingDocTypes }
                          : null
                        const printAllowed = outcome === 'accepted' || outcome === 'flag'
                        const submitLabel = outcome === 'hold' ? 'Place on Hold'
                          : outcome === 'flag' ? 'Submit with Flag'
                          : deferActive ? 'Submit (Docs Deferred)'
                          : 'Submit Acceptance'
                        const submitColor = outcome === 'hold' ? 'bg-slate-600 hover:bg-slate-500'
                          : outcome === 'flag' ? 'bg-amber-600 hover:bg-amber-500'
                          : deferActive ? 'bg-yellow-600 hover:bg-yellow-500'
                          : 'bg-green-600 hover:bg-green-500'

                        return (
                          <>
                            {/* Defer-documents control: only meaningful pre-mfg
                                with missing required docs and an accept/flag outcome.
                                Hidden once every required pre-mfg doc is approved —
                                routing-not-yet-reviewed is a separate gate. */}
                            {isPreMfg && needsDocGuard && hasMissingDocs && (
                              <div className="mb-4 border border-yellow-700/50 bg-yellow-900/10 rounded p-3">
                                <label className="flex items-start gap-2 cursor-pointer">
                                  <input
                                    type="checkbox"
                                    checked={defer}
                                    onChange={e => setDeferData(prev => ({
                                      ...prev,
                                      [job.id]: { ...prev[job.id], defer: e.target.checked },
                                    }))}
                                    className="mt-1"
                                    disabled={approving === job.id}
                                  />
                                  <div>
                                    <div className="text-sm text-yellow-300">
                                      Defer documents — approve without all required documents
                                    </div>
                                    <div className="text-xs text-gray-500">
                                      Use only when the job must move forward and remaining
                                      documents will be uploaded later. A note explaining why
                                      is required.
                                    </div>
                                  </div>
                                </label>
                                {defer && (
                                  <textarea
                                    value={deferData[job.id]?.reason || ''}
                                    onChange={e => setDeferData(prev => ({
                                      ...prev,
                                      [job.id]: { ...prev[job.id], reason: e.target.value },
                                    }))}
                                    placeholder="Why are documents being deferred?"
                                    rows={2}
                                    className="w-full mt-2 px-3 py-2 bg-gray-800 border border-yellow-700 rounded text-white text-sm"
                                    disabled={approving === job.id}
                                  />
                                )}
                              </div>
                            )}
                            <div className="flex justify-end gap-2">
                              <button
                                onClick={() => handleApproveJob(job.id, job.status, outcome, deferInfo)}
                                disabled={!submitEnabled}
                                className={`flex items-center gap-2 px-4 py-2 ${submitColor} text-white rounded transition-colors disabled:opacity-50 disabled:cursor-not-allowed`}
                              >
                                {approving === job.id ? <Loader2 size={16} className="animate-spin" /> : <CheckCircle size={16} />}
                                {approving === job.id ? 'Submitting...' : submitLabel}
                              </button>
                              {printAllowed && (
                                <button
                                  onClick={() => handleApproveAndPrint(job, outcome, deferInfo)}
                                  disabled={!submitEnabled}
                                  className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                                >
                                  {approving === job.id ? (
                                    <Loader2 size={16} className="animate-spin" />
                                  ) : (
                                    <><CheckCircle size={16} /><Printer size={16} /></>
                                  )}
                                  {approving === job.id ? 'Submitting...' : `${submitLabel} & Print`}
                                </button>
                              )}
                            </div>
                          </>
                        )
                      })()}
                    </div>
                    )}
                  </div>
                  )
                })()}
              </div>
            )
          })}
        </div>
      </div>
    )
  }

  // If no compliance-related jobs at all, don't render anything
  const hasAnyContent = pendingMachiningJobs.length > 0 ||
                        heldMachiningJobs.length > 0 ||
                        pendingPostMfgJobs.length > 0 ||
                        pendingBatches.length > 0 ||
                        approvedUnassignedJobs.length > 0 ||
                        recentlyApprovedJobs.length > 0

  if (!hasAnyContent) return null

  return (
    <div className="space-y-4">
      {/* Deferred-documents widget — self-hides when count = 0 */}
      <DeferredDocsWidget refreshKey={jobs} onNavigateToWO={onNavigateToWO} />

      {/* Pending Review - Machining */}
      {renderPendingSection(
        pendingMachiningJobs,
        'Pending Review - Pre-Manufacturing',
        'border-purple-800',
        'compliance_review'
      )}

      {/* On Hold - Machining (pre-mfg jobs marked compliance_outcome='hold') */}
      {heldMachiningJobs.length > 0 && renderPendingSection(
        heldMachiningJobs,
        'On Hold - Pre-Manufacturing',
        'border-slate-500',
        'compliance_review',
        false,
        true  // isHeldSection
      )}

      {/* Pending Review - Post-Manufacturing (merged batches + legacy jobs) */}
      {(() => {
        const mergedPostMfg = [
          ...pendingBatches.map(s => ({ type: 'batch', data: s, sortDate: s.finishing_completed_at })),
          ...pendingPostMfgJobs.map(j => ({ type: 'job', data: j, sortDate: j.updated_at }))
        ].sort((a, b) => new Date(a.sortDate) - new Date(b.sortDate))

        if (mergedPostMfg.length === 0) return null

        return (
          <div className="bg-gray-900 rounded-lg border border-indigo-800 p-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-purple-400 font-semibold flex items-center gap-2">
                <Clock size={18} />
                Pending Review - Post-Manufacturing ({mergedPostMfg.length})
              </h3>
            </div>

            <div className="space-y-2">
              {mergedPostMfg.map(item => {
                if (item.type === 'batch') {
                  const send = item.data
                  const isExpanded = expandedBatch === send.id
                  const reviewData = batchReviewData[send.id] || {}
                  const batchLabel = getBatchLabel(send)
                  const isApproving = approvingBatch === send.id

                  return (
                    <div key={`batch-${send.id}`} className="bg-gray-800 rounded-lg overflow-hidden">
                      {/* Batch collapsed header */}
                      <div
                        className="flex items-center justify-between p-3 cursor-pointer
                                   hover:bg-gray-750 border-l-4 border-cyan-600"
                        onClick={() => {
                          setExpandedBatch(isExpanded ? null : send.id)
                          if (!isExpanded) fetchBatchDetails(send)
                        }}
                      >
                        <div className="flex items-center gap-3">
                          {isExpanded
                            ? <ChevronDown size={18} className="text-cyan-400" />
                            : <ChevronRight size={18} className="text-gray-500" />
                          }
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-white font-mono">{send.job?.component?.part_number || send.job?.job_number}</span>
                              {send.job?.is_standalone_finishing && (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-cyan-900/30 text-cyan-300 border border-cyan-700 rounded text-xs">
                                  <Package size={10} />
                                  Standalone
                                </span>
                              )}
                              {batchLabel && (
                                <span className="text-xs px-1.5 py-0.5 bg-cyan-900/50 text-cyan-400
                                                 border border-cyan-700 rounded font-mono">
                                  Batch {batchLabel}
                                </span>
                              )}
                              <span className="text-gray-500">&middot;</span>
                              <span className="text-gray-400">{send.job?.work_order?.wo_number || (send.job?.is_standalone_finishing ? 'Standalone' : '—')}</span>
                            </div>
                            <div className="text-sm text-gray-500">
                              <span className="text-skynet-accent font-mono">{send.job?.job_number}</span>
                              <span className="mx-2">&middot;</span>
                              <span>Qty: {send.quantity}</span>
                              {(send.job?.work_order?.customer || send.job?.component?.customer) && (
                                <span className="mx-2">&middot; {send.job?.work_order?.customer || send.job?.component?.customer}</span>
                              )}
                            </div>
                            {send.job?.is_standalone_finishing && (
                              <div className="text-xs text-gray-500 mt-1">
                                Source: {send.job?.assigned_machine?.name
                                  || (send.job?.source_description ? `Received (${send.job.source_description})` : 'Received')}
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-gray-500">
                            Finished {send.finishing_completed_at ? new Date(send.finishing_completed_at).toLocaleString('en-US', {
                              month: 'short', day: 'numeric', year: 'numeric',
                              hour: 'numeric', minute: '2-digit', hour12: true
                            }) : '—'}
                          </span>
                        </div>
                      </div>

                      {/* Batch expanded detail */}
                      {isExpanded && (
                        <div className="border-t border-gray-700 p-4 space-y-4">

                          {/* Batch details */}
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <p className="text-gray-500 text-xs">Production Lot #</p>
                              <p className="text-white font-mono">
                                {send.job?.production_lot_number || '—'}
                              </p>
                            </div>
                            <div>
                              <p className="text-gray-500 text-xs">Finishing Lot #</p>
                              <p className="text-cyan-400 font-mono">
                                {send.finishing_lot_number || '—'}
                              </p>
                            </div>
                            <div>
                              <p className="text-gray-500 text-xs">Material Lot #</p>
                              <p className="text-white">{send.material_lot_number || '—'}</p>
                            </div>
                            {batchRequiresChemicals(send.job?.routing_steps) && (
                              <>
                                <div>
                                  <p className="text-gray-500 text-xs">Citric Acid Lot #</p>
                                  <p className="text-white">{send.chemical_lot_number || '—'}</p>
                                </div>
                                <div>
                                  <p className="text-gray-500 text-xs">Alkaline Mix Lot #</p>
                                  <p className="text-white">{send.chemical_lot_number_2 || '—'}</p>
                                </div>
                              </>
                            )}
                            <div>
                              <p className="text-gray-500 text-xs">Machine Count</p>
                              <p className="text-white">{send.quantity ?? '—'}</p>
                            </div>
                            <div>
                              <p className="text-gray-500 text-xs">Verified Count</p>
                              <p className="text-white">{send.verified_count ?? '—'}</p>
                            </div>
                            {(() => {
                              if (send.verified_count == null || send.quantity == null) return null
                              const delta = send.verified_count - send.quantity
                              if (delta === 0) return null
                              return (
                                <div className="col-span-2">
                                  <p className="text-xs text-yellow-400 flex items-center gap-1">
                                    <AlertCircle size={12} />
                                    Count discrepancy: {delta > 0 ? '+' : ''}{delta} pcs
                                  </p>
                                </div>
                              )
                            })()}
                          </div>

                          {/* Quantity Check */}
                          <div className="p-3 bg-gray-800/50 rounded-lg border border-indigo-800/30 space-y-3">
                            <h4 className="text-indigo-400 font-medium text-sm">Quantity Check</h4>
                            <div className="grid grid-cols-2 gap-3">
                              <div>
                                <label className="block text-gray-400 text-xs mb-1">Good Quantity</label>
                                <input
                                  type="number"
                                  min="0"
                                  value={reviewData.good_qty ?? ''}
                                  onChange={(e) => setBatchReviewData(prev => ({
                                    ...prev,
                                    [send.id]: { ...prev[send.id], good_qty: e.target.value }
                                  }))}
                                  className="w-full bg-gray-800 border border-gray-700 rounded px-3 py-2
                                             text-white text-sm focus:border-indigo-500 focus:outline-none"
                                />
                              </div>
                              <div>
                                <label className="block text-gray-400 text-xs mb-1">Bad Quantity</label>
                                <input
                                  type="number"
                                  min="0"
                                  value={reviewData.bad_qty ?? ''}
                                  onChange={(e) => setBatchReviewData(prev => ({
                                    ...prev,
                                    [send.id]: { ...prev[send.id], bad_qty: e.target.value }
                                  }))}
                                  placeholder="0"
                                  className="w-full bg-gray-800 border border-gray-700 rounded px-3 py-2
                                             text-white text-sm focus:border-indigo-500 focus:outline-none"
                                />
                              </div>
                            </div>
                            <p className="text-[11px] text-gray-500 leading-snug mb-2">
                              Bad Quantity = the parts actually rejected or reworked — not the whole batch
                              unless all of them are affected. This count feeds the Production dashboard quality metrics.
                            </p>
                            <div>
                              <label className="block text-gray-400 text-xs mb-1">
                                {batchReviewData[send.id]?.outcome === 'rework'
                                  ? 'Rework Instructions *'
                                  : batchReviewData[send.id]?.outcome === 'rejected'
                                  ? 'Rejection Reason *'
                                  : 'Review Notes (Optional)'}
                              </label>
                              <textarea
                                value={reviewData.notes ?? ''}
                                onChange={(e) => setBatchReviewData(prev => ({
                                  ...prev,
                                  [send.id]: { ...prev[send.id], notes: e.target.value }
                                }))}
                                placeholder="Any observations or notes for this batch..."
                                rows={2}
                                className="w-full bg-gray-800 border border-gray-700 rounded px-3 py-2
                                           text-white placeholder-gray-500 text-sm
                                           focus:border-indigo-500 focus:outline-none"
                              />
                            </div>
                          </div>

                          {/* Documents section — two groups */}
                          {batchDetails[send.id] && (() => {
                            const allReqs = batchDetails[send.id].requirements
                            const postMfgReqs = allReqs.filter(r => r.required_at === 'manufacturing_complete')
                            const preMfgReqs = allReqs.filter(r => r.required_at === 'compliance_review' || !r.required_at)
                            const allJobDocs = batchDetails[send.id].jobDocs

                            return (
                              <div>
                                {/* Group 1 — Required Documents (post-mfg stage, interactive) */}
                                <h4 className="text-gray-400 text-sm font-medium mb-3">Required Documents</h4>

                                {postMfgReqs.length === 0 ? (
                                  <div className="text-green-500 text-sm bg-green-900/20 p-3 rounded">
                                    No documents required at this stage.
                                  </div>
                                ) : (
                                  <div className="space-y-4">
                                    {postMfgReqs.map(req => {
                                      const docsForType = allJobDocs.filter(d => d.document_type_id === req.document_type_id)
                                      const hasAnyDocs = docsForType.length > 0
                                      const hasApproved = docsForType.some(d => d.status === 'approved')
                                      const uploadKey = send.job_id + '-' + req.document_type_id
                                      const isUploading = uploading === uploadKey

                                      return (
                                        <div key={req.id} className="space-y-2">
                                          <div className="flex items-center justify-between">
                                            <div className="flex items-center gap-2">
                                              <span className="text-white text-sm font-medium">{req.document_type?.name}</span>
                                              {req.is_required && <span className="text-xs text-red-400">Required</span>}
                                              {hasApproved && <CheckCircle size={14} className="text-green-500" />}
                                            </div>
                                            <label className="flex items-center gap-1 px-2 py-1 text-xs bg-blue-600 hover:bg-blue-500 text-white rounded cursor-pointer">
                                              {isUploading ? (
                                                <Loader2 size={12} className="animate-spin" />
                                              ) : hasAnyDocs ? (
                                                <Plus size={12} />
                                              ) : (
                                                <Upload size={12} />
                                              )}
                                              {isUploading ? 'Uploading...' : hasAnyDocs ? 'Add More' : 'Upload'}
                                              <input type="file" className="hidden"
                                                onChange={(e) => {
                                                  const file = e.target.files?.[0]
                                                  if (file) {
                                                    handleFileUpload(send.job_id, req.document_type_id, req.document_type?.code, file)
                                                      .then(() => fetchBatchDetails(send))
                                                  }
                                                  e.target.value = ''
                                                }}
                                                disabled={isUploading}
                                              />
                                            </label>
                                          </div>

                                          {!hasAnyDocs && (
                                            <div className="flex items-center gap-2 p-3 rounded border border-gray-600 bg-gray-700">
                                              <AlertCircle size={16} className="text-gray-500" />
                                              <span className="text-gray-400 text-sm">No document uploaded</span>
                                            </div>
                                          )}

                                          {docsForType.map((doc, index) => {
                                            const isDocApproved = doc.status === 'approved'
                                            const bgClass = getDocBgClass(doc.status)
                                            const isReplacing = replacing === doc.id

                                            return (
                                              <div key={doc.id} className={"flex items-center justify-between p-3 rounded border " + bgClass}>
                                                <div className="flex items-center gap-3">
                                                  {isDocApproved && <CheckCircle size={18} className="text-green-500" />}
                                                  {doc.status === 'pending' && <Clock size={18} className="text-yellow-500" />}
                                                  <div>
                                                    <div className="text-xs text-gray-500">{doc.file_name}</div>
                                                    {docsForType.length > 1 && (
                                                      <div className="text-xs text-gray-600">Document {index + 1}</div>
                                                    )}
                                                  </div>
                                                </div>
                                                <div className="flex items-center gap-2">
                                                  <ViewButton filePath={doc.file_url} />
                                                  <DeleteButton doc={doc} contextSend={send} />
                                                  {isComplianceUser && (
                                                    <label className="flex items-center gap-1 px-2 py-1 text-xs bg-orange-600 hover:bg-orange-500 text-white rounded cursor-pointer">
                                                      {isReplacing ? (
                                                        <Loader2 size={12} className="animate-spin" />
                                                      ) : (
                                                        <RefreshCw size={12} />
                                                      )}
                                                      {isReplacing ? '...' : 'Replace'}
                                                      <input type="file" className="hidden"
                                                        onChange={(e) => {
                                                          const file = e.target.files?.[0]
                                                          if (file) {
                                                            handleReplaceDocument(doc.id, send.job_id, req.document_type_id, file)
                                                              .then(() => fetchBatchDetails(send))
                                                          }
                                                          e.target.value = ''
                                                        }}
                                                        disabled={isReplacing}
                                                      />
                                                    </label>
                                                  )}
                                                  {doc.status === 'pending' && (
                                                    <button
                                                      onClick={async () => {
                                                        await handleApproveDocument(doc.id, send.job_id)
                                                        fetchBatchDetails(send)
                                                      }}
                                                      disabled={approving === doc.id}
                                                      className="flex items-center gap-1 px-2 py-1 text-xs bg-green-600 hover:bg-green-500 text-white rounded"
                                                    >
                                                      {approving === doc.id ? (
                                                        <Loader2 size={12} className="animate-spin" />
                                                      ) : (
                                                        <Check size={12} />
                                                      )}
                                                      {approving === doc.id ? '...' : 'Approve'}
                                                    </button>
                                                  )}
                                                </div>
                                              </div>
                                            )
                                          })}
                                        </div>
                                      )
                                    })}
                                  </div>
                                )}

                                {/* Job Traveler — live, generated on demand */}
                                <div className="mt-4">
                                  <h4 className="text-gray-400 text-sm font-medium mb-2">Job Traveler</h4>
                                  <button
                                    onClick={() => handleViewTraveler(send.job_id)}
                                    className="w-full flex items-center gap-3 px-3 py-2.5 bg-cyan-900/30 hover:bg-cyan-900/50 border border-cyan-700/50 rounded-lg transition-colors text-left group"
                                  >
                                    <div className="w-8 h-8 rounded bg-cyan-800/50 flex items-center justify-center flex-shrink-0">
                                      <FileText size={16} className="text-cyan-300" />
                                    </div>
                                    <div className="flex-1 min-w-0">
                                      <p className="text-white text-sm truncate group-hover:text-cyan-300 transition-colors">
                                        Job Traveler
                                      </p>
                                      <p className="text-gray-400 text-xs truncate">Live — reflects current routing & job data</p>
                                    </div>
                                    <ExternalLink size={14} className="text-gray-500 group-hover:text-cyan-300 transition-colors flex-shrink-0" />
                                  </button>
                                </div>

                                {/* Additional Documents */}
                                {isComplianceUser && (
                                  <div className="mt-4">
                                    <div className="flex items-center justify-between mb-2">
                                      <h4 className="text-gray-400 text-sm font-medium">Additional Documents</h4>
                                      <label className="flex items-center gap-1 px-2 py-1 text-xs bg-gray-700 hover:bg-gray-600 text-gray-200 rounded cursor-pointer transition-colors">
                                        {uploading === send.job_id + '-additional' ? (
                                          <Loader2 size={12} className="animate-spin" />
                                        ) : (
                                          <Upload size={12} />
                                        )}
                                        {uploading === send.job_id + '-additional' ? 'Uploading...' : 'Upload Document'}
                                        <input
                                          type="file"
                                          className="hidden"
                                          disabled={uploading === send.job_id + '-additional'}
                                          onChange={(e) => {
                                            const file = e.target.files?.[0]
                                            if (file) {
                                              handleAdditionalUpload(send.job_id, file)
                                                .then(() => fetchBatchDetails(send))
                                            }
                                            e.target.value = ''
                                          }}
                                        />
                                      </label>
                                    </div>
                                    {allJobDocs
                                      .filter(d => !d.document_type_id)
                                      .map(doc => (
                                        <div key={doc.id} className="flex items-center justify-between p-3 rounded border border-gray-700 bg-gray-800 mb-2">
                                          <div className="flex items-center gap-3">
                                            <FileText size={16} className="text-gray-400" />
                                            <span className="text-xs text-gray-400">{doc.file_name}</span>
                                          </div>
                                          <div className="flex items-center gap-1.5">
                                            <ViewButton filePath={doc.file_url} />
                                            <DeleteButton doc={doc} contextSend={send} />
                                          </div>
                                        </div>
                                      ))
                                    }
                                  </div>
                                )}

                                {/* Group 2 — Documents from Pre-Manufacturing (read-only) */}
                                {preMfgReqs.length > 0 && (
                                  <>
                                    <h4 className="text-gray-400 text-sm font-medium mt-6 mb-3 flex items-center gap-2">
                                      <FileText size={14} />
                                      Documents from Pre-Manufacturing
                                    </h4>
                                    {preMfgReqs.map(req => {
                                      const docsForType = allJobDocs.filter(d => d.document_type_id === req.document_type_id)
                                      const hasAnyDocs = docsForType.length > 0
                                      return (
                                        <div key={req.id} className="space-y-2 mb-3">
                                          <div className="flex items-center gap-2">
                                            <span className="text-white text-sm font-medium">{req.document_type?.name}</span>
                                            {hasAnyDocs && docsForType.every(d => d.status === 'approved') && (
                                              <CheckCircle size={14} className="text-green-500" />
                                            )}
                                          </div>
                                          {!hasAnyDocs ? (
                                            <div className="flex items-center gap-2 p-3 rounded border border-gray-700 bg-gray-800">
                                              <AlertCircle size={16} className="text-gray-600" />
                                              <span className="text-gray-500 text-sm">No document uploaded</span>
                                            </div>
                                          ) : (
                                            docsForType.map(doc => (
                                              <div key={doc.id} className="flex items-center justify-between p-3 rounded border border-gray-700 bg-gray-800">
                                                <div className="flex items-center gap-3">
                                                  {doc.status === 'approved'
                                                    ? <CheckCircle size={18} className="text-green-500" />
                                                    : <Clock size={18} className="text-yellow-500" />
                                                  }
                                                  <span className="text-xs text-gray-400">{doc.file_name}</span>
                                                </div>
                                                <div className="flex items-center gap-1.5">
                                                  <ViewButton filePath={doc.file_url} />
                                                  <DeleteButton doc={doc} contextSend={send} />
                                                </div>
                                              </div>
                                            ))
                                          )}
                                        </div>
                                      )
                                    })}
                                  </>
                                )}

                                {/* Unclassified uploads (finishing docs, etc.) */}
                                {(() => {
                                  const requiredTypeIds = allReqs.map(r => r.document_type_id)
                                  const unclassified = allJobDocs.filter(
                                    d => !requiredTypeIds.includes(d.document_type_id)
                                  )
                                  if (unclassified.length === 0) return null
                                  return (
                                    <div className="mt-4">
                                      <h4 className="text-gray-500 text-sm font-medium mb-2 flex items-center gap-2">
                                        <FileText size={16} />
                                        Other Documents
                                        <span className="text-gray-600 text-xs font-normal">Uploaded by finishing</span>
                                      </h4>
                                      <div className="space-y-2">
                                        {unclassified.map(doc => {
                                          const bgClass = getDocBgClass(doc.status)
                                          return (
                                            <div key={doc.id} className={"flex items-center justify-between p-3 rounded border " + bgClass}>
                                              <div className="flex items-center gap-3">
                                                {doc.status === 'approved' && <CheckCircle size={18} className="text-green-500" />}
                                                {doc.status === 'pending' && <Clock size={18} className="text-yellow-500" />}
                                                <div className="text-xs text-gray-500">{doc.file_name}</div>
                                              </div>
                                              <div className="flex items-center gap-2">
                                                <select
                                                  className="bg-gray-700 border border-gray-600 rounded px-1 py-0.5
                                                             text-xs text-gray-300 focus:outline-none"
                                                  defaultValue=""
                                                  onChange={async (e) => {
                                                    if (!e.target.value) return
                                                    await supabase.from('job_documents')
                                                      .update({ document_type_id: e.target.value })
                                                      .eq('id', doc.id)
                                                    fetchBatchDetails(send)
                                                  }}
                                                >
                                                  <option value="">Reassign...</option>
                                                  {allReqs.map(r => (
                                                    <option key={r.document_type_id} value={r.document_type_id}>
                                                      {r.document_type?.name}
                                                    </option>
                                                  ))}
                                                </select>
                                                <ViewButton filePath={doc.file_url} />
                                                <DeleteButton doc={doc} contextSend={send} />
                                                {doc.status === 'pending' && (
                                                  <button
                                                    onClick={async () => {
                                                      await handleApproveDocument(doc.id, send.job_id)
                                                      fetchBatchDetails(send)
                                                    }}
                                                    disabled={approving === doc.id}
                                                    className="flex items-center gap-1 px-2 py-1 text-xs bg-green-600 hover:bg-green-500 text-white rounded"
                                                  >
                                                    {approving === doc.id ? <Loader2 size={12} className="animate-spin" /> : <Check size={12} />}
                                                    {approving === doc.id ? '...' : 'Approve'}
                                                  </button>
                                                )}
                                              </div>
                                            </div>
                                          )
                                        })}
                                      </div>
                                    </div>
                                  )
                                })()}
                              </div>
                            )
                          })()}

                          {/* Outcome selector + submit. Hidden for read-only roles. */}
                          {canWrite && (
                          <div className="pt-2">
                            {renderOutcomeSelector({
                              outcome: batchReviewData[send.id]?.outcome,
                              onOutcomeChange: (v) => setBatchReviewData(prev => ({
                                ...prev,
                                [send.id]: { ...prev[send.id], outcome: v }
                              })),
                              noteValue: batchReviewData[send.id]?.notes,
                              onNoteChange: (v) => setBatchReviewData(prev => ({
                                ...prev,
                                [send.id]: { ...prev[send.id], notes: v }
                              })),
                              disabled: isApproving,
                            })}
                          </div>
                          )}
                          {canWrite && (() => {
                            const outcome = batchReviewData[send.id]?.outcome
                            const outcomeNote = (batchReviewData[send.id]?.notes || '').trim()
                            const outcomeValid = outcome === 'accepted'
                              || (outcome === 'rework' && outcomeNote.length > 0)
                              || (outcome === 'rejected' && outcomeNote.length > 0)
                            const submitEnabled = outcomeValid && !isApproving
                            const submitLabel = outcome === 'rejected' ? `Submit Rejection ${batchLabel || ''}`.trim()
                              : outcome === 'rework' ? `Submit Rework ${batchLabel || ''}`.trim()
                              : `Submit Batch ${batchLabel || ''}`.trim()
                            const submitColor = outcome === 'rejected' ? 'bg-red-600 hover:bg-red-500'
                              : outcome === 'rework' ? 'bg-amber-600 hover:bg-amber-500'
                              : 'bg-green-600 hover:bg-green-500 disabled:bg-gray-700'
                            return (
                              <button
                                onClick={() => handleApproveBatch(send, outcome)}
                                disabled={!submitEnabled}
                                className={`w-full py-3 ${submitColor} text-white font-semibold rounded-lg transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed`}
                              >
                                {isApproving ? (
                                  <><Loader2 size={18} className="animate-spin" /> Submitting...</>
                                ) : (
                                  <><CheckCircle size={18} /> {submitLabel}</>
                                )}
                              </button>
                            )
                          })()}
                        </div>
                      )}
                    </div>
                  )
                }

                // Job card — delegate to renderPendingSection's job template
                const job = item.data
                const isExpanded = expandedJob === job.id
                const details = jobDetails[job.id]
                const jobCanApprove = details ? canApproveJob(job.id, 'manufacturing_complete') : false
                const borderClass = getPriorityBorder(job.priority)
                const dotClass = getPriorityColor(job.priority)

                const stageReqs = details?.requirements?.filter(r =>
                  r.required_at === 'manufacturing_complete' || (!r.required_at && false)
                ) || []
                const futureReqs = details?.requirements?.filter(r =>
                  r.required_at !== 'manufacturing_complete'
                ) || []

                const allSteps = details?.routingSteps || []
                const hasRouting = allSteps.length > 0
                const hasPendingRemovals = allSteps.some(s => s.status === 'removal_pending')
                const isRoutingChecked = !!routingReviewed[job.id]
                const canApproveFull = jobCanApprove && (!hasRouting || isRoutingChecked) && !hasPendingRemovals

                return (
                  <div key={`job-${job.id}`} className="bg-gray-800 rounded-lg overflow-hidden">
                    <div
                      className={"flex items-center justify-between p-3 cursor-pointer hover:bg-gray-750 border-l-4 " + borderClass}
                      onClick={() => toggleJob(job.id)}
                    >
                      <div className="flex items-center gap-4">
                        {isExpanded ? (
                          <ChevronDown size={18} className="text-purple-400" />
                        ) : (
                          <ChevronRight size={18} className="text-gray-500" />
                        )}
                        <div className={"w-3 h-3 rounded-full " + dotClass}></div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-white font-mono">{job.component?.part_number || job.job_number}</span>
                            <span className="text-gray-500">&middot;</span>
                            <span className="text-gray-400">{job.work_order?.wo_number}</span>
                            {job.work_order?.order_type === 'make_to_stock' && (
                              <span className="text-xs px-2 py-0.5 bg-green-900/50 text-green-400 rounded">Stock</span>
                            )}
                          </div>
                          <div className="text-sm text-gray-500">
                            <span className="text-skynet-accent font-mono">{job.job_number}</span>
                            <span className="mx-2">&middot;</span>
                            <span>Qty: {job.quantity}</span>
                            {job.work_order?.customer && (
                              <span className="mx-2">&middot; {job.work_order.customer}</span>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>

                    {isExpanded && details && (
                      <div className="border-t border-gray-700 p-4 space-y-4">
                        {/* Traceability grid */}
                        {details.latestSend && (
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <p className="text-gray-500 text-xs">Production Lot #</p>
                              <p className="text-white font-mono">{details.latestSend.production_lot_number || job.production_lot_number || '—'}</p>
                            </div>
                            <div>
                              <p className="text-gray-500 text-xs">Finishing Lot #</p>
                              <p className="text-cyan-400 font-mono">{details.latestSend.finishing_lot_number || '—'}</p>
                            </div>
                            <div>
                              <p className="text-gray-500 text-xs">Material Lot #</p>
                              <p className="text-white">{details.latestSend.material_lot_number || '—'}</p>
                            </div>
                            {batchRequiresChemicals(details.routingSteps) && (
                              <>
                                <div>
                                  <p className="text-gray-500 text-xs">Citric Acid Lot #</p>
                                  <p className="text-white">{details.latestSend.chemical_lot_number || '—'}</p>
                                </div>
                                <div>
                                  <p className="text-gray-500 text-xs">Alkaline Mix Lot #</p>
                                  <p className="text-white">{details.latestSend.chemical_lot_number_2 || '—'}</p>
                                </div>
                              </>
                            )}
                            <div>
                              <p className="text-gray-500 text-xs">Machine Count</p>
                              <p className="text-white">{details.latestSend.quantity ?? '—'}</p>
                            </div>
                            <div>
                              <p className="text-gray-500 text-xs">Verified Count</p>
                              <p className="text-white">{details.latestSend.verified_count ?? '—'}</p>
                            </div>
                            {(() => {
                              if (details.latestSend.verified_count == null || details.latestSend.quantity == null) return null
                              const delta = details.latestSend.verified_count - details.latestSend.quantity
                              if (delta === 0) return null
                              return (
                                <div className="col-span-2">
                                  <p className="text-xs text-yellow-400 flex items-center gap-1">
                                    <AlertCircle size={12} />
                                    Count discrepancy: {delta > 0 ? '+' : ''}{delta} pcs
                                  </p>
                                </div>
                              )
                            })()}
                          </div>
                        )}

                        {/* Quantity Check */}
                        {job.status === 'pending_post_manufacturing' && (
                          <div className="p-3 bg-gray-800/50 rounded-lg border border-indigo-800/30 space-y-3">
                            <h4 className="text-indigo-400 font-medium text-sm flex items-center gap-2">
                              <ClipboardCheck size={16} />
                              Quantity Check
                            </h4>
                            <div className="grid grid-cols-2 gap-3">
                              <div>
                                <label className="block text-gray-400 text-xs mb-1">Good Quantity</label>
                                <input
                                  type="number"
                                  min="0"
                                  value={postMfgData[job.id]?.good_qty ?? ''}
                                  onChange={(e) => setPostMfgData(prev => ({
                                    ...prev,
                                    [job.id]: { ...prev[job.id], good_qty: e.target.value }
                                  }))}
                                  placeholder={String(job.quantity)}
                                  className="w-full bg-gray-800 border border-gray-700 rounded px-3 py-2 text-white
                                             text-sm focus:border-indigo-500 focus:outline-none"
                                />
                              </div>
                              <div>
                                <label className="block text-gray-400 text-xs mb-1">Bad Quantity</label>
                                <input
                                  type="number"
                                  min="0"
                                  value={postMfgData[job.id]?.bad_qty ?? ''}
                                  onChange={(e) => setPostMfgData(prev => ({
                                    ...prev,
                                    [job.id]: { ...prev[job.id], bad_qty: e.target.value }
                                  }))}
                                  placeholder="0"
                                  className="w-full bg-gray-800 border border-gray-700 rounded px-3 py-2 text-white
                                             text-sm focus:border-indigo-500 focus:outline-none"
                                />
                              </div>
                            </div>
                            <div>
                              <label className="block text-gray-400 text-xs mb-1">
                                {postMfgData[job.id]?.outcome === 'rework'
                                  ? 'Rework Instructions *'
                                  : postMfgData[job.id]?.outcome === 'rejected'
                                  ? 'Rejection Reason *'
                                  : 'Review Notes (Optional)'}
                              </label>
                              <textarea
                                value={postMfgData[job.id]?.notes ?? ''}
                                onChange={(e) => setPostMfgData(prev => ({
                                  ...prev,
                                  [job.id]: { ...prev[job.id], notes: e.target.value }
                                }))}
                                placeholder="Any observations, quality issues, or notes for this job..."
                                rows={2}
                                className="w-full bg-gray-800 border border-gray-700 rounded px-3 py-2 text-white
                                           placeholder-gray-500 text-sm focus:border-indigo-500 focus:outline-none"
                              />
                            </div>
                          </div>
                        )}

                        {/* Document requirements — two groups */}
                        {details && !details.noComponent && (() => {
                          const postMfgReqs = details.requirements.filter(r => r.required_at === 'manufacturing_complete')
                          const preMfgReqs = details.requirements.filter(r => r.required_at === 'compliance_review' || !r.required_at)

                          return (
                            <div>
                              {/* Group 1 — Required Documents (post-mfg stage, interactive) */}
                              <h4 className="text-gray-400 text-sm font-medium mb-3">Required Documents</h4>

                              {postMfgReqs.length === 0 ? (
                                <div className="text-green-500 text-sm bg-green-900/20 p-3 rounded">
                                  No documents required at this stage.
                                </div>
                              ) : (
                                <div className="space-y-4">
                                  {postMfgReqs.map(req => {
                                    const docsForType = details.jobDocs.filter(d => d.document_type_id === req.document_type_id)
                                    const hasAnyDocs = docsForType.length > 0
                                    const hasApproved = docsForType.some(d => d.status === 'approved')
                                    const uploadKey = job.id + '-' + req.document_type_id
                                    const isUploading = uploading === uploadKey

                                    return (
                                      <div key={req.id} className="space-y-2">
                                        <div className="flex items-center justify-between">
                                          <div className="flex items-center gap-2">
                                            <span className="text-white text-sm font-medium">{req.document_type?.name}</span>
                                            {req.is_required && <span className="text-xs text-red-400">Required</span>}
                                            {hasApproved && <CheckCircle size={14} className="text-green-500" />}
                                          </div>
                                          <label className="flex items-center gap-1 px-2 py-1 text-xs bg-blue-600 hover:bg-blue-500 text-white rounded cursor-pointer">
                                            {isUploading ? (
                                              <Loader2 size={12} className="animate-spin" />
                                            ) : hasAnyDocs ? (
                                              <Plus size={12} />
                                            ) : (
                                              <Upload size={12} />
                                            )}
                                            {isUploading ? 'Uploading...' : hasAnyDocs ? 'Add More' : 'Upload'}
                                            <input type="file" className="hidden"
                                              onChange={(e) => {
                                                const file = e.target.files?.[0]
                                                if (file) handleFileUpload(job.id, req.document_type_id, req.document_type?.code, file)
                                                e.target.value = ''
                                              }}
                                              disabled={isUploading}
                                            />
                                          </label>
                                        </div>

                                        {!hasAnyDocs && (
                                          <div className="flex items-center gap-2 p-3 rounded border border-gray-600 bg-gray-700">
                                            <AlertCircle size={16} className="text-gray-500" />
                                            <span className="text-gray-400 text-sm">No document uploaded</span>
                                          </div>
                                        )}

                                        {docsForType.map((doc, index) => {
                                          const isDocApproved = doc.status === 'approved'
                                          const bgClass = getDocBgClass(doc.status)
                                          const isReplacing = replacing === doc.id

                                          return (
                                            <div key={doc.id} className={"flex items-center justify-between p-3 rounded border " + bgClass}>
                                              <div className="flex items-center gap-3">
                                                {isDocApproved && <CheckCircle size={18} className="text-green-500" />}
                                                {doc.status === 'pending' && <Clock size={18} className="text-yellow-500" />}
                                                <div>
                                                  <div className="text-xs text-gray-500">{doc.file_name}</div>
                                                  {docsForType.length > 1 && (
                                                    <div className="text-xs text-gray-600">Document {index + 1}</div>
                                                  )}
                                                </div>
                                              </div>
                                              <div className="flex items-center gap-2">
                                                <ViewButton filePath={doc.file_url} />
                                                <DeleteButton doc={doc} contextJobId={job.id} />
                                                {isComplianceUser && (
                                                  <label className="flex items-center gap-1 px-2 py-1 text-xs bg-orange-600 hover:bg-orange-500 text-white rounded cursor-pointer">
                                                    {isReplacing ? (
                                                      <Loader2 size={12} className="animate-spin" />
                                                    ) : (
                                                      <RefreshCw size={12} />
                                                    )}
                                                    {isReplacing ? '...' : 'Replace'}
                                                    <input type="file" className="hidden"
                                                      onChange={(e) => {
                                                        const file = e.target.files?.[0]
                                                        if (file) handleReplaceDocument(doc.id, job.id, req.document_type_id, file)
                                                        e.target.value = ''
                                                      }}
                                                      disabled={isReplacing}
                                                    />
                                                  </label>
                                                )}
                                                {doc.status === 'pending' && (
                                                  <button
                                                    onClick={() => handleApproveDocument(doc.id, job.id)}
                                                    disabled={approving === doc.id}
                                                    className="flex items-center gap-1 px-2 py-1 text-xs bg-green-600 hover:bg-green-500 text-white rounded"
                                                  >
                                                    {approving === doc.id ? (
                                                      <Loader2 size={12} className="animate-spin" />
                                                    ) : (
                                                      <Check size={12} />
                                                    )}
                                                    {approving === doc.id ? '...' : 'Approve'}
                                                  </button>
                                                )}
                                              </div>
                                            </div>
                                          )
                                        })}
                                      </div>
                                    )
                                  })}
                                </div>
                              )}

                              {/* Additional Documents */}
                              {isComplianceUser && (
                                <div className="mt-4">
                                  <div className="flex items-center justify-between mb-2">
                                    <h4 className="text-gray-400 text-sm font-medium">Additional Documents</h4>
                                    <label className="flex items-center gap-1 px-2 py-1 text-xs bg-gray-700 hover:bg-gray-600 text-gray-200 rounded cursor-pointer transition-colors">
                                      {uploading === job.id + '-additional' ? (
                                        <Loader2 size={12} className="animate-spin" />
                                      ) : (
                                        <Upload size={12} />
                                      )}
                                      {uploading === job.id + '-additional' ? 'Uploading...' : 'Upload Document'}
                                      <input
                                        type="file"
                                        className="hidden"
                                        disabled={uploading === job.id + '-additional'}
                                        onChange={(e) => {
                                          const file = e.target.files?.[0]
                                          if (file) handleAdditionalUpload(job.id, file)
                                          e.target.value = ''
                                        }}
                                      />
                                    </label>
                                  </div>
                                  {(details?.jobDocs || [])
                                    .filter(d => !d.document_type_id)
                                    .map(doc => (
                                      <div key={doc.id} className="flex items-center justify-between p-3 rounded border border-gray-700 bg-gray-800 mb-2">
                                        <div className="flex items-center gap-3">
                                          <FileText size={16} className="text-gray-400" />
                                          <span className="text-xs text-gray-400">{doc.file_name}</span>
                                        </div>
                                        <div className="flex items-center gap-1.5">
                                          <ViewButton filePath={doc.file_url} />
                                          <DeleteButton doc={doc} contextJobId={job.id} />
                                        </div>
                                      </div>
                                    ))
                                  }
                                </div>
                              )}

                              {/* Group 2 — Documents from Pre-Manufacturing (read-only) */}
                              {preMfgReqs.length > 0 && (
                                <>
                                  <h4 className="text-gray-400 text-sm font-medium mt-6 mb-3 flex items-center gap-2">
                                    <FileText size={14} />
                                    Documents from Pre-Manufacturing
                                  </h4>
                                  {preMfgReqs.map(req => {
                                    const docsForType = details.jobDocs.filter(d => d.document_type_id === req.document_type_id)
                                    const hasAnyDocs = docsForType.length > 0
                                    return (
                                      <div key={req.id} className="space-y-2 mb-3">
                                        <div className="flex items-center gap-2">
                                          <span className="text-white text-sm font-medium">{req.document_type?.name}</span>
                                          {hasAnyDocs && docsForType.every(d => d.status === 'approved') && (
                                            <CheckCircle size={14} className="text-green-500" />
                                          )}
                                        </div>
                                        {!hasAnyDocs ? (
                                          <div className="flex items-center gap-2 p-3 rounded border border-gray-700 bg-gray-800">
                                            <AlertCircle size={16} className="text-gray-600" />
                                            <span className="text-gray-500 text-sm">No document uploaded</span>
                                          </div>
                                        ) : (
                                          docsForType.map(doc => (
                                            <div key={doc.id} className="flex items-center justify-between p-3 rounded border border-gray-700 bg-gray-800">
                                              <div className="flex items-center gap-3">
                                                {doc.status === 'approved'
                                                  ? <CheckCircle size={18} className="text-green-500" />
                                                  : <Clock size={18} className="text-yellow-500" />
                                                }
                                                <span className="text-xs text-gray-400">{doc.file_name}</span>
                                              </div>
                                              <div className="flex items-center gap-1.5">
                                                <ViewButton filePath={doc.file_url} />
                                                <DeleteButton doc={doc} contextJobId={job.id} />
                                              </div>
                                            </div>
                                          ))
                                        )}
                                      </div>
                                    )
                                  })}
                                </>
                              )}
                            </div>
                          )
                        })()}

                        {/* Outcome selector + submit actions */}
                        <div className="mb-4">
                          {renderOutcomeSelector({
                            outcome: postMfgData[job.id]?.outcome,
                            onOutcomeChange: (v) => setPostMfgData(prev => ({
                              ...prev,
                              [job.id]: { ...prev[job.id], outcome: v }
                            })),
                            noteValue: postMfgData[job.id]?.notes,
                            onNoteChange: (v) => setPostMfgData(prev => ({
                              ...prev,
                              [job.id]: { ...prev[job.id], notes: v }
                            })),
                            disabled: approving === job.id,
                          })}
                        </div>
                        {(() => {
                          const outcome = postMfgData[job.id]?.outcome
                          const outcomeNote = (postMfgData[job.id]?.notes || '').trim()
                          const outcomeValid = outcome === 'accepted'
                            || (outcome === 'rework' && outcomeNote.length > 0)
                            || (outcome === 'rejected' && outcomeNote.length > 0)
                          const submitEnabled = outcomeValid && approving !== job.id
                          const printAllowed = outcome === 'accepted' || outcome === 'rework'
                          const submitLabel = outcome === 'rejected' ? 'Submit Rejection'
                            : outcome === 'rework' ? 'Submit Rework' : 'Submit Acceptance'
                          const submitColor = outcome === 'rejected' ? 'bg-red-600 hover:bg-red-500'
                            : outcome === 'rework' ? 'bg-amber-600 hover:bg-amber-500'
                            : 'bg-green-600 hover:bg-green-500'
                          return (
                            <div className="flex justify-end gap-2">
                              <button
                                onClick={() => handleApproveJob(job.id, job.status, outcome)}
                                disabled={!submitEnabled}
                                className={`flex items-center gap-2 px-4 py-2 ${submitColor} text-white rounded transition-colors disabled:opacity-50 disabled:cursor-not-allowed`}
                              >
                                {approving === job.id ? <Loader2 size={16} className="animate-spin" /> : <CheckCircle size={16} />}
                                {approving === job.id ? 'Submitting...' : submitLabel}
                              </button>
                              {printAllowed && (
                                <button
                                  onClick={() => handleApproveAndPrint(job, outcome)}
                                  disabled={!submitEnabled}
                                  className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                                >
                                  {approving === job.id ? (
                                    <Loader2 size={16} className="animate-spin" />
                                  ) : (
                                    <><CheckCircle size={16} /><Printer size={16} /></>
                                  )}
                                  {approving === job.id ? 'Submitting...' : `${submitLabel} & Print`}
                                </button>
                              )}
                            </div>
                          )
                        })()}
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
          </div>
        )
      })()}

      {/* Approved, Unassigned */}
      {approvedUnassignedJobs.length > 0 && (
        <div className="bg-gray-900 rounded-lg border border-green-800 p-4">
          <h3 className="text-green-400 font-semibold mb-3 flex items-center gap-2">
            <CheckCircle size={18} />
            Approved, Unassigned ({approvedUnassignedJobs.length})
          </h3>
          <div className="space-y-2">
            {approvedUnassignedJobs.map(job => (
              <div 
                key={job.id} 
                className={`flex items-center justify-between bg-gray-800 rounded p-3 border-l-4 ${getPriorityBorder(job.priority)}`}
              >
                <div className="flex items-center gap-4">
                  <div className={`w-3 h-3 rounded-full ${getPriorityColor(job.priority)}`}></div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-white font-mono">{job.component?.part_number || job.job_number}</span>
                      <span className="text-gray-500">·</span>
                      <span className="text-gray-400">{job.work_order?.wo_number}</span>
                      <span className="text-gray-500">·</span>
                      {job.work_order?.order_type === 'make_to_order' && (
                        <span className="px-1.5 py-0.5 text-xs font-bold rounded bg-blue-900 text-blue-300">MTO</span>
                      )}
                      {job.work_order?.order_type === 'make_to_stock' && (
                        <span className="px-1.5 py-0.5 text-xs font-bold rounded bg-green-900 text-green-300">MTS</span>
                      )}
                      {job.work_order?.order_type === 'maintenance' && (
                        <span className="px-1.5 py-0.5 text-xs font-bold rounded bg-orange-900 text-orange-300">MAINT</span>
                      )}
                      <span className="text-gray-500">·</span>
                      <span className="text-skynet-accent font-mono">{job.job_number}</span>
                    </div>
                    <div className="text-sm text-gray-500">
                      <span>Qty: {job.quantity}</span>
                      {job.work_order?.order_type === 'make_to_order' && job.work_order?.customer && (
                        <>
                          <span className="mx-2">·</span>
                          <span className="text-gray-400">{job.work_order.customer}</span>
                        </>
                      )}
                      {job.work_order?.order_type === 'make_to_stock' && (
                        <>
                          <span className="mx-2">·</span>
                          <span className="text-gray-400">STOCK</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setPrintPackageJob(job)}
                    className="flex items-center gap-1 px-3 py-1 text-sm bg-gray-600 hover:bg-gray-500 text-white rounded transition-colors"
                  >
                    <Printer size={14} />
                    Print
                  </button>
                  {isComplianceUser && (
                    <button
                      onClick={() => handleRecallJob(job.id)}
                      disabled={recalling === job.id}
                      className="flex items-center gap-1 px-3 py-1 text-sm bg-orange-600 hover:bg-orange-500 text-white rounded transition-colors disabled:opacity-50"
                    >
                      {recalling === job.id ? (
                        <Loader2 size={14} className="animate-spin" />
                      ) : (
                        <Undo2 size={14} />
                      )}
                      {recalling === job.id ? 'Recalling...' : 'Recall'}
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Recently Approved Batches (Last 5 Days) */}
      {recentlyApprovedBatches.length > 0 && (
        <div className="bg-gray-900 rounded-lg border border-gray-700 p-4">
          <button
            onClick={() => setShowRecentBatches(!showRecentBatches)}
            className="w-full flex items-center justify-between text-left"
          >
            <h3 className="text-gray-400 font-semibold flex items-center gap-2">
              <CheckCircle size={18} className="text-green-500" />
              Recently Approved Batches ({recentlyApprovedBatches.length})
              <span className="text-gray-600 text-xs font-normal">Last 5 days</span>
            </h3>
            <ChevronDown
              size={20}
              className={`text-gray-500 transition-transform ${showRecentBatches ? 'rotate-0' : '-rotate-90'}`}
            />
          </button>

          {showRecentBatches && (
            <div className="mt-4">
              <div className="grid grid-cols-6 gap-2 text-xs text-gray-500 font-medium mb-2 px-3">
                <span>Job #</span>
                <span>Batch</span>
                <span>Part #</span>
                <span>Qty</span>
                <span>Approved</span>
                <span>Customer</span>
              </div>
              <div className="space-y-1">
                {recentlyApprovedBatches.map(send => {
                  const jobSends = recentlyApprovedBatches.filter(s => s.job_id === send.job_id)
                    .sort((a, b) => new Date(a.sent_at) - new Date(b.sent_at))
                  const isPartial = send.is_partial_send === true
                  const showLabel = jobSends.length > 1 || isPartial
                  const idx = jobSends.findIndex(s => s.id === send.id)
                  const label = showLabel ? `Batch ${String.fromCharCode(65 + idx)}` : '—'

                  return (
                    <div key={send.id} className="grid grid-cols-6 gap-2 text-sm bg-gray-800 rounded p-3 items-center">
                      <span className="text-white font-mono">{send.job?.component?.part_number || send.job?.job_number}</span>
                      <span>{showLabel ? (
                        <span className="text-xs px-1.5 py-0.5 bg-cyan-900/50 text-cyan-400 border border-cyan-700 rounded font-mono">{label}</span>
                      ) : (
                        <span className="text-gray-600">—</span>
                      )}</span>
                      <span className="text-skynet-accent font-mono">{send.job?.job_number}</span>
                      <span className="text-gray-300">{send.quantity} pcs</span>
                      <span className="text-gray-400">
                        {new Date(send.compliance_approved_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                      </span>
                      <span className="text-gray-400 truncate">{send.job?.work_order?.customer || send.job?.component?.customer || '—'}</span>
                    </div>
                  )
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Recently Approved (Last 5 Days) */}
      {recentlyApprovedJobs.length > 0 && (
        <div className="bg-gray-900 rounded-lg border border-gray-700 p-4">
          <button
            onClick={() => setShowRecentlyApproved(!showRecentlyApproved)}
            className="w-full flex items-center justify-between text-left"
          >
            <h3 className="text-gray-400 font-semibold flex items-center gap-2">
              <FileText size={18} />
              Recently Approved - Last 5 Days ({recentlyApprovedJobs.length})
            </h3>
            <ChevronDown 
              size={20} 
              className={`text-gray-500 transition-transform ${showRecentlyApproved ? 'rotate-0' : '-rotate-90'}`}
            />
          </button>
          
          {showRecentlyApproved && (
            <div className="mt-4">
              <div className="grid grid-cols-6 gap-2 text-xs text-gray-500 font-medium mb-2 px-3">
                <span>WO #</span>
                <span>Job #</span>
                <span>Part #</span>
                <span>Created</span>
                <span>Approved</span>
                <span>Status</span>
              </div>
              <div className="space-y-1">
                {recentlyApprovedJobs.map(job => (
                  <div 
                    key={job.id} 
                    className="grid grid-cols-6 gap-2 text-sm bg-gray-800 rounded p-3 items-center"
                  >
                    <span className="text-gray-300">{job.work_order?.wo_number}</span>
                    <span className="text-white font-mono">{job.component?.part_number || job.job_number}</span>
                    <span className="text-skynet-accent font-mono">{job.job_number}</span>
                    <span className="text-gray-400">{formatDate(job.created_at)}</span>
                    <span className="text-gray-400">{formatDate(job.updated_at)}</span>
                    <span>{getStatusBadge(job.status)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
      {/* Print Package Modal */}
      <PrintPackageModal
        isOpen={!!printPackageJob}
        job={printPackageJob}
        onClose={() => setPrintPackageJob(null)}
      />

      {/* Additional Documents modal — typed picker + opt-in part promotion */}
      <AddJobDocumentModal
        isOpen={!!additionalDocFor}
        jobId={additionalDocFor?.jobId}
        partId={additionalDocFor?.partId}
        profile={profile}
        onClose={() => setAdditionalDocFor(null)}
        onSuccess={async () => {
          const jobId = additionalDocFor?.jobId
          if (jobId) {
            const fresh = await fetchJobDetails(jobId)
            setJobDetails(prev => ({ ...prev, [jobId]: fresh }))
          }
          onUpdate?.()
        }}
      />
    </div>
  )
}
