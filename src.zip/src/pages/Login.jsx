import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'

const SKYBOLT_DOMAIN = '@skybolt.com'

export default function Login({ onLogin }) {
  const navigate = useNavigate()
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const handleLogin = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    // Allow user to type either "mbowers" or "mbowers@skybolt.com" — handle both gracefully.
    // For no-email users (testop1, etc.), look up the placeholder @skynet.local address by username.
    const trimmed = username.trim().toLowerCase()
    let email
    if (trimmed.includes('@')) {
      email = trimmed
    } else {
      const { data: lookedUp } = await supabase.rpc('get_email_by_username', {
        p_username: trimmed,
      })
      email = lookedUp || `${trimmed}${SKYBOLT_DOMAIN}`
    }

    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (error) {
      // Don't echo the email back in the error — keep the username abstraction clean
      setError(error.message.includes('Invalid') ? 'Invalid username or password' : error.message)
      setLoading(false)
    } else {
      onLogin(data.user)
    }
  }

  return (
    <div className="min-h-screen bg-skynet-dark flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-5xl font-bold text-white skynet-glow mb-2">
            SkyNet
          </h1>
          <p className="text-skynet-accent">Manufacturing Execution System</p>
          <div className="mt-4 flex items-center justify-center gap-2">
            <div className="w-2 h-2 bg-skynet-green rounded-full animate-pulse"></div>
            <span className="text-skynet-green font-mono text-sm">
              SkyNet is online.
            </span>
          </div>
        </div>

        {/* Login Form */}
        <form onSubmit={handleLogin} className="bg-gray-900 rounded-lg p-6 shadow-xl border border-gray-800">
          <h2 className="text-xl font-semibold text-white mb-6">Neural Net Access</h2>

          {error && (
            <div className="mb-4 p-3 bg-red-900/50 border border-red-700 rounded text-red-300 text-sm">
              {error}
            </div>
          )}

          <div className="mb-4">
            <label className="block text-gray-400 text-sm mb-2">Username</label>
            <div className="flex items-stretch">
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="flex-1 px-4 py-3 bg-gray-800 border border-gray-700 rounded-l text-white placeholder-gray-500 focus:outline-none focus:border-skynet-accent"
                placeholder="mbowers"
                autoComplete="username"
                autoCapitalize="none"
                autoCorrect="off"
                spellCheck="false"
                required
              />
              <span className="px-3 py-3 bg-gray-800 border border-l-0 border-gray-700 rounded-r text-gray-500 text-sm font-mono flex items-center">
                @skybolt.com
              </span>
            </div>
          </div>

          <div className="mb-6">
            <label className="block text-gray-400 text-sm mb-2">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded text-white placeholder-gray-500 focus:outline-none focus:border-skynet-accent"
              placeholder="••••••••"
              autoComplete="current-password"
              required
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-skynet-accent hover:bg-blue-600 text-white font-semibold rounded transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? 'Authenticating...' : 'Access System'}
          </button>

          <button
            type="button"
            onClick={() => navigate('/forgot-password')}
            className="w-full mt-3 py-2 text-gray-500 hover:text-skynet-accent text-sm transition-colors"
          >
            Forgot password?
          </button>
        </form>

        <p className="text-center text-gray-600 text-xs mt-6 italic">
          "Don't worry, this one just schedules fasteners."
        </p>
      </div>
    </div>
  )
}
