import { useState, useEffect, useRef, useCallback } from 'react'
import { supabase } from '../lib/supabase'
import { Plus, ChevronDown, AlertTriangle, Edit3, X, Loader2, Trash2, RefreshCw, Wrench, Search, ClipboardList, ChevronRight, Package, Clock, CheckCircle, Calendar, User, Beaker, Printer, FileText, ExternalLink, Truck, Pause, Flag, AlertCircle, Split } from 'lucide-react'
import { getDocumentUrl } from '../lib/s3'
import { buildTravelerHTML, fetchCOAllocationsForTraveler } from '../lib/traveler'
import CustomerOrders from './CustomerOrders'
import MachineCard from '../components/MachineCard'
import CreateWorkOrderModal from '../components/CreateWorkOrderModal'
import CreateMaintenanceModal from '../components/CreateMaintenanceModal'
import ComplianceReview from '../components/ComplianceReview'
import Assembly from '../components/Assembly'
import TCOReview from '../components/TCOReview'
import OutsourcedJobs from '../components/OutsourcedJobs'
import EditWorkOrderModal from '../components/EditWorkOrderModal'
import PrintPackageModal from '../components/PrintPackageModal'
import CreatePinPromptModal from '../components/CreatePinPromptModal'
import ChangePinModal from '../components/ChangePinModal'
import { FEATURES } from '../config'
import { summarizeWOAllocations, formatWODueDate } from '../lib/workOrderDisplay'
import { releaseCOAllocationsIfWODead } from '../lib/customerOrders'
import { getWOFulfillmentSummary } from '../lib/woFulfillment'
import AddJobDocumentModal from '../components/AddJobDocumentModal'
import SplitJobModal from '../components/SplitJobModal'
import { isSplittable, canSplitJobs } from '../lib/jobs'
import DocsDeferredBadge from '../components/DocsDeferredBadge'
import CustomerDisplay from '../components/CustomerDisplay'
import WOLookupShortfalls from '../components/WOLookupShortfalls'
import { isReadOnlyRole } from '../lib/roles'
import { getEffectiveQty } from '../lib/effectiveQty'

export default function Mainframe({ user, profile, canCreateWorkOrders = false }) {
  const canWrite = !isReadOnlyRole(profile?.role)
  const [machines, setMachines] = useState([])
  const [jobs, setJobs] = useState([])
  const [loading, setLoading] = useState(true)
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [showPinPrompt, setShowPinPrompt] = useState(false)
  const [showPinModal, setShowPinModal] = useState(false)
  const [pinPromptDismissed, setPinPromptDismissed] = useState(false)
  const [showMaintenanceModal, setShowMaintenanceModal] = useState(false)
  const [expandedLocations, setExpandedLocations] = useState({})
  const [selectedView, setSelectedView] = useState('lineup')
  const [assemblyWOs, setAssemblyWOs] = useState([])
  const [assemblyCount, setAssemblyCount] = useState(0)
  const [tcoWOs, setTcoWOs] = useState([])
  
  // NEW: Track ongoing downtimes and active unplanned maintenance for DOWN status
  const [ongoingDowntimes, setOngoingDowntimes] = useState([])
  const [activeMaintenanceJobs, setActiveMaintenanceJobs] = useState([])

  // Finishing queue count
  const [finishingSends, setFinishingSends] = useState([])
  const [pendingBatchComplianceCount, setPendingBatchComplianceCount] = useState(0)
  const [outsourcedCount, setOutsourcedCount] = useState(0)
  
  // Auto-refresh state
  const [autoRefresh, setAutoRefresh] = useState(true) // Enabled by default
  const [lastUpdated, setLastUpdated] = useState(null)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const refreshIntervalRef = useRef(null)
  
  // Edit job modal state
  const [editingJob, setEditingJob] = useState(null)
  const [editForm, setEditForm] = useState({ quantity: '', priority: '' })
  const [editSaving, setEditSaving] = useState(false)
  const [showEditWarning, setShowEditWarning] = useState(true)
  const [showCancelConfirm, setShowCancelConfirm] = useState(false)
  const [cancelling, setCancelling] = useState(false)
  
  // Work Order Lookup state
  const [showWOLookup, setShowWOLookup] = useState(false)
  const [missedEntryJob, setMissedEntryJob] = useState(null)
  const [missedEntryForm, setMissedEntryForm] = useState({ quantity: '', reason: '', production_lot: '', passivation_lot: '' })
  const [missedEntrySaving, setMissedEntrySaving] = useState(false)
  const [orderLookupTab, setOrderLookupTab] = useState('work_orders') // 'work_orders' | 'shortfalls' | 'customer_orders'
  const [woLookupData, setWOLookupData] = useState([])
  const [woFulfillmentCache, setWOFulfillmentCache] = useState({}) // woId -> rows or 'loading'
  const [standaloneJobs, setStandaloneJobs] = useState([])
  const [showStandaloneSection, setShowStandaloneSection] = useState(false)
  const [woLookupLoading, setWOLookupLoading] = useState(false)
  const [woLookupSearch, setWOLookupSearch] = useState('')
  const [expandedWOs, setExpandedWOs] = useState({})
  
  // WO Edit modal state
  const [editingWO, setEditingWO] = useState(null)
  
  // Split job state (S9 Batch B — opens SplitJobModal from WO Lookup job rows)
  const [splitJobTarget, setSplitJobTarget] = useState(null)
  // Cancel job state (two-step confirmation in WO Lookup)
  const [cancellingJobId, setCancellingJobId] = useState(null)
  const [cancelStep, setCancelStep] = useState(0) // 0=none, 1=first warning, 2=final confirmation
  const [cancelSaving, setCancelSaving] = useState(false)
  const [printPackageJob, setPrintPackageJob] = useState(null)

  // WO Lookup — per-job document expansion
  const [expandedJobDocs, setExpandedJobDocs] = useState({})
  const [jobDocCache, setJobDocCache] = useState({})
  const [loadingJobDocs, setLoadingJobDocs] = useState({})
  const [viewingWODoc, setViewingWODoc] = useState(null)
  // Add-document modal: { jobId, partId } or null
  const [addDocFor, setAddDocFor] = useState(null)
  const canManageJobDocs = ['admin', 'compliance'].includes(profile?.role)

  // Memoized fetch function
  const fetchData = useCallback(async (isAutoRefresh = false) => {
    try {
      if (isAutoRefresh) {
        setIsRefreshing(true)
      }
      console.log('🔄 Starting fetchData...')
      
      const { data: machinesData, error: machinesError } = await supabase
        .from('machines')
        .select(`
          *,
          location:locations(name, code)
        `)
        .eq('is_active', true)
        .order('display_order')

      if (machinesError) {
        console.error('❌ Error fetching machines:', machinesError)
      } else {
        console.log('✅ Machines fetched:', machinesData?.length || 0, 'machines')
        setMachines(machinesData || [])
      }

      const { data: jobsData, error: jobsError } = await supabase
        .from('jobs')
        .select(`
          *,
          work_order:work_orders(wo_number, customer, priority, due_date, order_type, maintenance_type, notes, order_quantity, stock_quantity),
          component:parts!component_id(id, part_number, description, part_type, requires_passivation),
          assigned_machine:machines(id, name, code)
        `)
        .not('status', 'eq', 'complete')
        .not('status', 'eq', 'cancelled')
        .order('created_at', { ascending: true })

      if (jobsError) {
        console.error('❌ Error fetching jobs:', jobsError)
        setJobs([])
      } else {
        console.log('✅ Jobs fetched:', jobsData?.length || 0, 'jobs')
        // Sum compliance_good_qty from accepted finishing_sends per job
        // so MachineCard can show Finished: X/Y on running tiles.
        const finishedByJob = {}
        if (jobsData.length > 0) {
          const { data: finishedData, error: finishedErr } = await supabase
            .from('finishing_sends')
            .select('job_id, compliance_good_qty')
            .eq('compliance_outcome', 'accepted')
            .in('job_id', jobsData.map(j => j.id))
          if (finishedErr) console.error('❌ Error fetching finished rollup:', finishedErr)
          ;(finishedData || []).forEach(row => {
            finishedByJob[row.job_id] = (finishedByJob[row.job_id] || 0) + (row.compliance_good_qty || 0)
          })
        }
        setJobs(jobsData.map(j => ({ ...j, finished_qty: finishedByJob[j.id] || 0 })))
      }

      // NEW: Fetch ongoing downtimes (end_time IS NULL)
      const { data: ongoingDowntimesData, error: downtimeError } = await supabase
        .from('machine_downtime_logs')
        .select('*')
        .is('end_time', null)
        .order('start_time', { ascending: false })

      if (downtimeError) {
        console.error('❌ Error fetching ongoing downtimes:', downtimeError)
      } else {
        console.log('✅ Ongoing downtimes fetched:', ongoingDowntimesData?.length || 0)
        setOngoingDowntimes(ongoingDowntimesData || [])
      }

      // Fetch finishing sends with job info
      const { data: finishingSendsData, error: finishingError } = await supabase
        .from('finishing_sends')
        .select(`
          id, quantity, status, is_partial_send, sent_at, finishing_stage,
          finishing_lot_number,
          job:jobs(
            id, job_number, quantity,
            work_order:work_orders(wo_number, customer, priority),
            component:parts!component_id(part_number, description)
          )
        `)
        .in('status', ['pending_finishing', 'in_finishing'])
        .order('sent_at', { ascending: true })

      if (!finishingError) {
        setFinishingSends(finishingSendsData || [])
      }

      // Fetch pending batch compliance count
      const { count: batchComplianceCount } = await supabase
        .from('finishing_sends')
        .select('id', { count: 'exact', head: true })
        .eq('compliance_status', 'pending_compliance')
      setPendingBatchComplianceCount(batchComplianceCount || 0)

      // Fetch for assembly-ready work orders
      // An assembly is ready when ALL its linked jobs have status ready_for_assembly
      const { data: woWithJobs } = await supabase
        .from('work_orders')
        .select(`
          id,
          wo_number,
          order_type,
          work_order_assemblies (id, assembly_id, status),
          jobs (id, status, work_order_assembly_id)
        `)
        .not('order_type', 'eq', 'maintenance')

      // Count per-assembly readiness (each WOA is independent)
      let assemblyReadyCount = 0
      const assemblyReadyWOSet = new Set()
      for (const wo of (woWithJobs || [])) {
        if (wo.work_order_assemblies && wo.work_order_assemblies.length > 0) {
          for (const woa of wo.work_order_assemblies) {
            const woaJobs = wo.jobs?.filter(j => j.work_order_assembly_id === woa.id) || []
            const allReady = woaJobs.length > 0 && woaJobs.every(j =>
              ['ready_for_assembly', 'in_assembly', 'complete'].includes(j.status)
            )
            const hasWork = woaJobs.some(j =>
              ['ready_for_assembly', 'in_assembly'].includes(j.status)
            )
            if (allReady && hasWork && woa.status !== 'complete') {
              assemblyReadyCount++
              assemblyReadyWOSet.add(wo.id)
            }
          }
        } else {
          // Fallback: WO-level check for WOs without work_order_assemblies
          if (wo.jobs?.length > 0 && 
              wo.jobs.every(j => ['ready_for_assembly', 'in_assembly', 'complete'].includes(j.status)) &&
              wo.jobs.some(j => ['ready_for_assembly', 'in_assembly'].includes(j.status))) {
            assemblyReadyCount++
            assemblyReadyWOSet.add(wo.id)
          }
        }
      }

      // Store WOs for navigation (any WO that has at least one ready assembly)
      const assemblyReadyWOs = (woWithJobs || []).filter(wo => assemblyReadyWOSet.has(wo.id))
      setAssemblyWOs(assemblyReadyWOs)
      setAssemblyCount(assemblyReadyCount)

      // Count WOs pending TCO (at least one job in pending_tco)
      const tcoReadyWOs = (woWithJobs || []).filter(wo => {
        if (!wo.jobs || wo.jobs.length === 0) return false
        return wo.jobs.some(job => job.status === 'pending_tco')
      })
      setTcoWOs(tcoReadyWOs)

      // NEW: Fetch active unplanned maintenance jobs (status = in_progress or assigned, maintenance_type = unplanned)
      // that are currently scheduled (scheduled_start <= now <= scheduled_end)
      const now = new Date().toISOString()
      const { data: activeMaintenanceData, error: maintenanceError } = await supabase
        .from('jobs')
        .select(`
          *,
          work_order:work_orders!inner(wo_number, order_type, maintenance_type, notes)
        `)
        .eq('is_maintenance', true)
        .eq('work_order.maintenance_type', 'unplanned')
        .in('status', ['assigned', 'in_setup', 'in_progress'])
        .lte('scheduled_start', now)
        .or(`scheduled_end.gte.${now},scheduled_end.is.null`)

      if (maintenanceError) {
        console.error('❌ Error fetching active maintenance jobs:', maintenanceError)
      } else {
        console.log('✅ Active unplanned maintenance jobs fetched:', activeMaintenanceData?.length || 0)
        setActiveMaintenanceJobs(activeMaintenanceData || [])
      }

      // Outsourced count — sum of:
      //  (a) outbound_sends still at vendor (sent but not returned) — both source types
      //  (b) approved finishing batches with a pending external step (ready to send)
      //  (c) assembly-source outbound_sends not yet sent (Jody created the row at Complete/Send Batch,
      //      Ashley hasn't logged send-out yet)
      const [
        { count: atVendorCount },
        { data: readyBatches },
        { data: existingSends },
        { count: asmReadyCount }
      ] = await Promise.all([
        supabase
          .from('outbound_sends')
          .select('*', { count: 'exact', head: true })
          .not('sent_at', 'is', null)
          .is('returned_at', null),
        supabase
          .from('finishing_sends')
          .select(`
            id,
            job:jobs!inner(
              id, status,
              job_routing_steps(id, step_type, status)
            )
          `)
          .eq('compliance_status', 'approved')
          .not('job.status', 'in', '(ready_for_assembly,in_assembly,pending_tco,complete,cancelled)'),
        supabase
          .from('outbound_sends')
          .select('finishing_send_id, job_routing_step_id')
          .not('finishing_send_id', 'is', null),
        supabase
          .from('outbound_sends')
          .select('*', { count: 'exact', head: true })
          .eq('source_type', 'work_order_assembly')
          .is('sent_at', null)
      ])

      // Build a set of (batch, step) combos that already have an outbound_send
      const sentSet = new Set(
        (existingSends || []).map(s => `${s.finishing_send_id}|${s.job_routing_step_id}`)
      )

      // Count: batches with at least one pending external step that DOESN'T already have a send
      const readyToSendCount = (() => {
        if (!readyBatches) return 0
        let total = 0
        for (const batch of readyBatches) {
          const externalSteps = (batch.job?.job_routing_steps || [])
            .filter(s => s.step_type === 'external' && ['pending', 'in_progress'].includes(s.status))
          const unsent = externalSteps.filter(step => !sentSet.has(`${batch.id}|${step.id}`))
          if (unsent.length > 0) total += 1
        }
        return total
      })()

      setOutsourcedCount((atVendorCount || 0) + readyToSendCount + (asmReadyCount || 0))

      setLastUpdated(new Date())
      console.log('✅ fetchData complete!')
    } catch (error) {
      console.error('💥 Unexpected error in fetchData:', error)
    } finally {
      setLoading(false)
      setIsRefreshing(false)
    }
  }, [])

  // Soft-prompt the user to create their kiosk PIN if their role needs one and pin_code is null.
  // Reappears each new session until they create a PIN.
  useEffect(() => {
    if (!profile) return
    const PIN_REQUIRED_ROLES = ['machinist', 'admin', 'finishing']
    const needsPinNow = PIN_REQUIRED_ROLES.includes(profile.role) && !profile.pin_code
    if (needsPinNow && !pinPromptDismissed) {
      setShowPinPrompt(true)
    }
  }, [profile, pinPromptDismissed])

  // Initial fetch and real-time subscription
  useEffect(() => {
    fetchData()
    
    const jobsSubscription = supabase
      .channel('jobs-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'jobs' }, 
        () => fetchData()
      )
      .subscribe()

    // Subscribe to machine status changes
    const machinesSubscription = supabase
      .channel('machines-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'machines' }, 
        () => fetchData()
      )
      .subscribe()

    // NEW: Subscribe to downtime log changes
    const downtimeSubscription = supabase
      .channel('downtime-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'machine_downtime_logs' }, 
        () => fetchData()
      )
      .subscribe()

    return () => {
      supabase.removeChannel(jobsSubscription)
      supabase.removeChannel(machinesSubscription)
      supabase.removeChannel(downtimeSubscription)
    }
  }, [fetchData])

  // Auto-refresh interval (30 seconds)
  useEffect(() => {
    if (autoRefresh) {
      refreshIntervalRef.current = setInterval(() => {
        fetchData(true) // Pass true to indicate auto-refresh
      }, 30000) // 30 seconds
    }
    
    return () => {
      if (refreshIntervalRef.current) {
        clearInterval(refreshIntervalRef.current)
      }
    }
  }, [autoRefresh, fetchData])

  // Get secondary config for a machine
  const getSecondaryConfig = (machine) => {
    if (!machine) return null
    const code = machine.code?.toLowerCase() || ''
    const name = machine.name?.toLowerCase() || ''
    
    if (code.startsWith('pass') || name.includes('passivation') || code.startsWith('fin') || name.includes('finishing')) {
      return {
        type: 'finishing',
        statuses: ['pending_passivation', 'in_passivation']
      }
    }
    if (code.startsWith('paint') || name.includes('paint')) {
      return {
        type: 'paint',
        statuses: ['pending_paint', 'in_paint']
      }
    }
    return null
  }

  const getJobsForMachine = (machineId) => {
    // Find the machine to check if it's a secondary operation station
    const machine = machines.find(m => m.id === machineId)
    const secondaryConfig = getSecondaryConfig(machine)
    
    if (secondaryConfig) {
      // For secondary operations (Finishing, Paint), show ALL jobs with matching status
      // These jobs are not assigned to a specific machine
      return jobs.filter(job => secondaryConfig.statuses.includes(job.status))
    }
    
    // Normal machines: show jobs assigned to this machine with active statuses
    const activeStatuses = ['pending_compliance', 'assigned', 'in_setup', 'in_progress']
    return jobs.filter(job => 
      job.assigned_machine_id === machineId && 
      activeStatuses.includes(job.status)
    )
  }

  // NEW: Get ongoing downtime for a specific machine
  const getOngoingDowntimeForMachine = (machineId) => {
    return ongoingDowntimes.find(d => d.machine_id === machineId)
  }

  // NEW: Get active unplanned maintenance job for a specific machine
  const getActiveMaintenanceForMachine = (machineId) => {
    return activeMaintenanceJobs.find(j => j.assigned_machine_id === machineId)
  }

  // Fetch all active work orders with their jobs for lookup
  const fetchWOLookup = async () => {
    setWOLookupLoading(true)
    try {
      // Get all work orders with their assemblies and jobs
      const { data: workOrders, error: woError } = await supabase
        .from('work_orders')
        .select(`
          id,
          wo_number,
          customer,
          priority,
          due_date,
          order_type,
          maintenance_type,
          status,
          order_quantity,
          stock_quantity,
          has_cancelled_allocation,
          has_open_shortfall,
          created_at,
          work_order_assemblies (
            id,
            quantity,
            order_quantity,
            stock_quantity,
            status,
            good_quantity,
            bad_quantity,
            assembly_lot_number,
            assembly:parts!assembly_id(id, part_number, description),
            work_order_assembly_routing_steps (
              id, step_order, step_name, step_type, status,
              lot_number, completed_at, is_added_step
            )
          ),
          jobs (
            id,
            job_number,
            status,
            quantity,
            production_lot_number,
            good_pieces,
            bad_pieces,
            assigned_machine_id,
            scheduled_start,
            work_order_assembly_id,
            component_id,
            compliance_outcome,
            compliance_notes,
            missed_production_entries (id, quantity, production_lot, passivation_lot, reason, created_at),
            documents_deferred,
            documents_deferred_reason,
            documents_deferred_at,
            has_open_shortfall,
            component:parts!component_id(part_number, description),
            machine:assigned_machine_id(name),
            finishing_sends (
              id, quantity, status, compliance_status, compliance_outcome, compliance_notes,
              compliance_good_qty, compliance_bad_qty, incoming_count, verified_count,
              is_partial_send, finishing_lot_number, sent_at, finishing_completed_at,
              compliance_approved_at
            ),
            job_routing_steps (
              id, step_order, step_name, step_type, status,
              lot_number, completed_at
            ),
            outbound_sends (
              id, operation_type, vendor_name, quantity, sent_at,
              expected_return_at, returned_at, vendor_lot_number,
              quantity_returned, cert_document_path, finishing_send_id
            ),
            job_materials (
              lot_number,
              created_at
            )
          )
        `)
        .order('created_at', { ascending: false })

      if (woError) throw woError

      // Filter to only WOs that have jobs not in 'complete' or 'cancelled' status
      // OR include WOs where all jobs are complete (to show finished WOs)
      const activeWOs = workOrders?.filter(wo => {
        if (!wo.jobs || wo.jobs.length === 0) return false
        // Show WO if any job is not complete/cancelled
        return wo.jobs.some(j => !['complete', 'cancelled'].includes(j.status))
      }) || []

      // Also get recently completed WOs (last 7 days)
      const sevenDaysAgo = new Date()
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7)
      
      const completedWOs = workOrders?.filter(wo => {
        if (!wo.jobs || wo.jobs.length === 0) return false
        const allComplete = wo.jobs.every(j => ['complete', 'cancelled'].includes(j.status))
        if (!allComplete) return false
        // Check if completed recently
        const latestJob = wo.jobs.reduce((latest, j) => {
          return !latest || new Date(j.updated_at) > new Date(latest.updated_at) ? j : latest
        }, null)
        return latestJob && new Date(wo.created_at) > sevenDaysAgo
      }) || []

      // Hydrate WOA-level outbound_sends (polymorphic — no FK, fetched separately)
      const allWoaIds = []
      const finalWOs = [...activeWOs, ...completedWOs]
      for (const wo of finalWOs) {
        for (const woa of (wo.work_order_assemblies || [])) {
          if (woa.id) allWoaIds.push(woa.id)
        }
      }

      let asmSendsByWoa = {}
      if (allWoaIds.length > 0) {
        const { data: asmSends, error: asmErr } = await supabase
          .from('outbound_sends')
          .select(`
            id, source_id, routing_step_id, operation_type, quantity, sent_at,
            expected_return_at, returned_at, vendor_name, vendor_lot_number,
            quantity_returned, created_at
          `)
          .eq('source_type', 'work_order_assembly')
          .in('source_id', allWoaIds)
          .order('created_at', { ascending: true })

        if (asmErr) {
          console.error('Error fetching WOA outbound_sends:', asmErr)
        } else {
          for (const send of asmSends || []) {
            if (!asmSendsByWoa[send.source_id]) asmSendsByWoa[send.source_id] = []
            asmSendsByWoa[send.source_id].push(send)
          }
        }
      }

      // Attach the sends list (and a batch-letter map) to each WOA so render code can use them
      for (const wo of finalWOs) {
        for (const woa of (wo.work_order_assemblies || [])) {
          const sends = asmSendsByWoa[woa.id] || []
          woa.assembly_outbound_sends = sends
          // Per-WOA per-step batch lettering: A, B, C... ordered by created_at within each routing_step_id
          const byStep = {}
          for (const s of sends) {
            const k = s.routing_step_id || '_'
            if (!byStep[k]) byStep[k] = []
            byStep[k].push(s)
          }
          const letterMap = {}
          for (const stepId in byStep) {
            byStep[stepId].forEach((s, i) => { letterMap[s.id] = String.fromCharCode(65 + i) })
          }
          woa.assembly_send_letter_map = letterMap
        }
      }

      // Hydrate active CO allocations per WO. Used for the customer/due display rule.
      // Polymorphic shape mirrors what EditWorkOrderModal loads on open.
      const allWoIds = finalWOs.map(w => w.id).filter(Boolean)
      let allocsByWo = {}
      if (allWoIds.length > 0) {
        const { data: allocsData, error: allocsErr } = await supabase
          .from('customer_order_allocations')
          .select(`
            id, work_order_id, quantity_allocated, customer_order_line_id,
            customer_order_lines (
              id, line_number, due_date, part_id,
              customer_orders ( co_number, customers ( id, name ) )
            )
          `)
          .in('work_order_id', allWoIds)
          .eq('is_active', true)
        if (allocsErr) {
          console.error('Failed to fetch WO allocations:', allocsErr)
        } else {
          for (const a of allocsData || []) {
            if (!allocsByWo[a.work_order_id]) allocsByWo[a.work_order_id] = []
            allocsByWo[a.work_order_id].push(a)
          }
        }
      }
      for (const wo of finalWOs) {
        wo.active_allocations = allocsByWo[wo.id] || []
      }

      setWOLookupData(finalWOs)

      // Standalone J-FIN jobs have no work order; fetch separately
      const { data: standaloneJobsData, error: standaloneError } = await supabase
        .from('jobs')
        .select(`
          id,
          job_number,
          status,
          quantity,
          production_lot_number,
          good_pieces,
          bad_pieces,
          assigned_machine_id,
          is_standalone_finishing,
          source_description,
          notes,
          created_at,
          component:parts!component_id(part_number, description, customer),
          machine:assigned_machine_id(name),
          finishing_sends (
            id, quantity, status, compliance_status, compliance_outcome, compliance_notes,
            compliance_good_qty, compliance_bad_qty, incoming_count, verified_count,
            is_partial_send, finishing_lot_number, sent_at, finishing_completed_at,
            compliance_approved_at
          )
        `)
        .eq('is_standalone_finishing', true)
        .is('work_order_id', null)
        .order('created_at', { ascending: false })

      if (standaloneError) {
        console.error('Failed to load standalone jobs:', standaloneError)
      }

      setStandaloneJobs(standaloneJobsData || [])
    } catch (err) {
      console.error('Error fetching WO lookup data:', err)
    } finally {
      setWOLookupLoading(false)
    }
  }

  // Open WO Lookup modal
  const handleOpenWOLookup = () => {
    setShowWOLookup(true)
    setWOLookupSearch('')
    setExpandedWOs({})
    fetchWOLookup()
  }

  // Get status badge for a job
  const getStatusBadge = (status) => {
    const statusConfig = {
      pending_compliance: { label: 'Pending Compliance', color: 'bg-purple-900/50 text-purple-300 border-purple-700' },
      ready: { label: 'Ready', color: 'bg-blue-900/50 text-blue-300 border-blue-700' },
      assigned: { label: 'Assigned', color: 'bg-indigo-900/50 text-indigo-300 border-indigo-700' },
      in_setup: { label: 'In Setup', color: 'bg-cyan-900/50 text-cyan-300 border-cyan-700' },
      in_progress: { label: 'In Progress', color: 'bg-green-900/50 text-green-300 border-green-700' },
      manufacturing_complete: { label: 'Mfg Complete', color: 'bg-teal-900/50 text-teal-300 border-teal-700' },
      pending_passivation: { label: 'Pending Finishing (Legacy)', color: 'bg-cyan-900/50 text-cyan-300 border-cyan-700' },
      in_passivation: { label: 'In Finishing (Legacy)', color: 'bg-cyan-900/50 text-cyan-300 border-cyan-700' },
      pending_post_manufacturing: { label: 'Post-Mfg Review', color: 'bg-orange-900/50 text-orange-300 border-orange-700' },
      ready_for_outsourcing: { label: 'Ready for Outsourcing', color: 'bg-orange-900/30 text-orange-400 border-orange-700' },
      at_external_vendor: { label: 'At External Vendor', color: 'bg-blue-900/30 text-blue-400 border-blue-700' },
      ready_for_assembly: { label: 'Ready for Assembly', color: 'bg-emerald-900/50 text-emerald-300 border-emerald-700' },
      in_assembly: { label: 'In Assembly', color: 'bg-emerald-900/50 text-emerald-300 border-emerald-700' },
      pending_tco: { label: 'Pending TCO', color: 'bg-amber-900/50 text-amber-300 border-amber-700' },
      complete: { label: 'Complete', color: 'bg-gray-800 text-gray-400 border-gray-700' },
      cancelled: { label: 'Cancelled', color: 'bg-gray-800 text-gray-500 border-gray-700' }
    }
    return statusConfig[status] || { label: status, color: 'bg-gray-800 text-gray-400 border-gray-700' }
  }

  // Small icon-name lookup for badge rendering
  const renderBadgeIcon = (iconName) => {
    switch (iconName) {
      case 'pause':       return <Pause size={10} />
      case 'flag':        return <Flag size={10} />
      case 'alertcircle': return <AlertCircle size={10} />
      case 'x':           return <X size={10} />
      case 'truck':       return <Truck size={10} />
      case 'clock':       return <Clock size={10} className="animate-pulse" />
      case 'checkcircle': return <CheckCircle size={10} />
      case 'beaker':      return <Beaker size={10} />
      default:            return null
    }
  }

  // Return an array of badges for a job: primary status (or state override),
  // followed by any supplemental compliance-outcome badge (Flag/Rework/Rejected).
  const getJobBadges = (job) => {
    const badges = []

    // Primary badge: Hold overrides pending_compliance; Out-for-[Vendor] overrides at_external_vendor.
    if (job.compliance_outcome === 'hold' && job.status === 'pending_compliance') {
      badges.push({
        label: 'On Hold',
        color: 'bg-slate-800 text-slate-300 border-slate-600',
        icon: 'pause',
      })
    } else if (job.status === 'at_external_vendor') {
      const activeOutbound = job.outbound_sends?.find(s => s.sent_at && !s.returned_at)
      if (activeOutbound?.vendor_name) {
        badges.push({
          label: `Out for ${activeOutbound.vendor_name}`,
          color: 'bg-blue-900/30 text-blue-300 border-blue-700',
          icon: 'truck',
        })
      } else {
        badges.push({ ...getStatusBadge(job.status), icon: 'truck' })
      }
    } else {
      const iconByStatus = {
        in_progress: 'clock',
        complete: 'checkcircle',
        pending_passivation: 'beaker',
        in_passivation: 'beaker',
      }
      badges.push({ ...getStatusBadge(job.status), icon: iconByStatus[job.status] })
    }

    // Supplemental compliance-outcome badge
    if (job.compliance_outcome === 'flag') {
      badges.push({
        label: 'Flagged',
        color: 'bg-amber-900/40 text-amber-300 border-amber-700',
        icon: 'flag',
      })
    } else if (job.compliance_outcome === 'rework') {
      badges.push({
        label: 'Rework',
        color: 'bg-amber-900/40 text-amber-300 border-amber-700',
        icon: 'alertcircle',
      })
    } else if (job.compliance_outcome === 'rejected') {
      badges.push({
        label: 'Rejected',
        color: 'bg-red-900/40 text-red-300 border-red-700',
        icon: 'x',
      })
    }

    return badges
  }

  // Derive effective quantity for a job. Precedence:
  //   1. Sum of compliance_good_qty across APPROVED batches (verified at post-mfg compliance;
  //      includes rework outcomes because those parts still advance; excludes rejected batches).
  //   2. job.good_pieces (machinist's count — pre-verification but trustworthy).
  //   3. job.quantity (original order — fallback).
  // Returns { qty, verified } where verified=true means qty comes from a post-production source.
  // Derive effective quantity for a job. Precedence (most authoritative → least):
  //   1. Sum of returned qty from completed outsourcing sends, IF outsourcing
  //      happened after compliance (vendor may lose/scrap pieces).
  //   2. Sum of compliance_good_qty across approved batches (with bad_qty fallback).
  //   3. job.good_pieces (machinist's count).
  //   4. job.quantity (original order).
  // Returns { qty, verified } where verified=true means qty comes from a post-production source.

  // Format a 'date' column (no time component) as a local-tz calendar date.
  // Reading 'YYYY-MM-DD' as a JS Date directly causes UTC interpretation,
  // which shifts the display by one day in negative-offset timezones.
  // Split the string and construct a local-tz Date instead.
  const formatDateOnly = (dateStr) => {
    if (!dateStr) return ''
    const [y, m, d] = dateStr.split('-').map(Number)
    const localDate = new Date(y, m - 1, d)
    return localDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
  }

  // Compare a 'date' column value to today, in local tz, without UTC drift.
  const isPastToday = (dateStr) => {
    if (!dateStr) return false
    const [y, m, d] = dateStr.split('-').map(Number)
    const target = new Date(y, m - 1, d)
    const today = new Date()
    today.setHours(0, 0, 0, 0)
    return target < today
  }

  // How many units have completed ALL routing steps and are ready to ship?
  // - No external steps  → woa.good_quantity (0 until Jody clicks Complete)
  // - With external(s)   → sum of quantity_returned for the LAST external step
  //   (each external consumes the prior step's output, so only the latest matters)
  const computeAvailableQty = (woa) => {
    const steps = (woa?.work_order_assembly_routing_steps || [])
      .slice()
      .sort((a, b) => b.step_order - a.step_order)  // descending — last step first
    const lastExternal = steps.find(s => s.step_type === 'external')

    if (!lastExternal) {
      // No external steps — available is whatever Jody marked good at Complete
      return woa?.good_quantity || 0
    }

    const returnedSends = (woa?.assembly_outbound_sends || [])
      .filter(s => s.routing_step_id === lastExternal.id && s.returned_at)
    return returnedSends.reduce((sum, s) => sum + (s.quantity_returned || 0), 0)
  }

  // Return the best available count for a single finishing_send batch.
  // Precedence (most authoritative → least):
  //   compliance_good_qty (Roger approved, explicit) →
  //   (verified_count or quantity) - compliance_bad_qty (derived when only bad was entered) →
  //   verified_count      (James's post-finishing verify) →
  //   incoming_count      (James's on-receipt count) →
  //   quantity            (machinist's original send count)
  const getBatchQty = (send) => {
    if (send.compliance_good_qty != null) {
      return { qty: send.compliance_good_qty, annotate: send.quantity !== send.compliance_good_qty ? send.quantity : null }
    }
    if (send.compliance_status === 'approved' && send.compliance_bad_qty != null) {
      const base = send.verified_count ?? send.quantity
      const derived = Math.max(0, base - send.compliance_bad_qty)
      return { qty: derived, annotate: send.quantity !== derived ? send.quantity : null }
    }
    if (send.verified_count != null) {
      return { qty: send.verified_count, annotate: send.quantity !== send.verified_count ? send.quantity : null }
    }
    if (send.incoming_count != null) {
      return { qty: send.incoming_count, annotate: send.quantity !== send.incoming_count ? send.quantity : null }
    }
    return { qty: send.quantity, annotate: null }
  }

  // Filter WOs based on search
  const filteredWOLookup = woLookupData.filter(wo => {
    if (!woLookupSearch.trim()) return true
    const search = woLookupSearch.toLowerCase()

    // Search WO number, customer (free text), and any allocation-derived customer names
    if (wo.wo_number?.toLowerCase().includes(search)) return true
    if (wo.customer?.toLowerCase().includes(search)) return true
    const allocSummary = summarizeWOAllocations(wo.active_allocations)
    if (allocSummary.customerList.some(n => n?.toLowerCase().includes(search))) return true

    // Search assembly part numbers
    if (wo.work_order_assemblies?.some(woa =>
      woa.assembly?.part_number?.toLowerCase().includes(search)
    )) return true

    // Search job numbers and component part numbers
    return wo.jobs?.some(job =>
      job.job_number?.toLowerCase().includes(search) ||
      job.component?.part_number?.toLowerCase().includes(search)
    )
  })

  const filteredStandaloneJobs = standaloneJobs.filter(job => {
    if (!woLookupSearch.trim()) return true
    const search = woLookupSearch.toLowerCase()
    return (
      job.job_number?.toLowerCase().includes(search) ||
      job.component?.part_number?.toLowerCase().includes(search) ||
      job.component?.customer?.toLowerCase().includes(search)
    )
  })

  // Group machines by location
  const machinesByLocation = machines.reduce((acc, machine) => {
    const locationName = machine.location?.name || 'Unknown Location'
    if (!acc[locationName]) {
      acc[locationName] = []
    }
    acc[locationName].push(machine)
    return acc
  }, {})

  useEffect(() => {
    const initialExpanded = {}
    Object.keys(machinesByLocation).forEach(locationName => {
      initialExpanded[locationName] = true
    })
    setExpandedLocations(initialExpanded)
  }, [machines.length])

  const toggleLocation = (locationName) => {
    setExpandedLocations(prev => ({
      ...prev,
      [locationName]: !prev[locationName]
    }))
  }

  // Finishing sends split
  const finishingActive  = finishingSends.filter(s => s.status === 'in_finishing')
  const finishingPending = finishingSends.filter(s => s.status === 'pending_finishing')

  // Job categorization — pending_compliance pre-mfg is gated on machine
  // assignment (S9 workflow flip), so the KPI must exclude unscheduled jobs
  // to match ComplianceReview's filtered queue. pending_post_manufacturing
  // has no machine dependency and counts unconditionally.
  const pendingComplianceJobs = jobs.filter(job =>
    (job.status === 'pending_compliance' && job.assigned_machine_id) ||
    job.status === 'pending_post_manufacturing'
  )
  const readyJobs = jobs.filter(job => !job.assigned_machine_id && job.status === 'ready')
  // SKY21: scheduler needs to see pending_compliance jobs alongside ready ones
  // so she can plan the queue before compliance approves them.
  const unassignedPendingCompliance = jobs.filter(job => !job.assigned_machine_id && job.status === 'pending_compliance')
  const unassignedJobs = [...readyJobs, ...unassignedPendingCompliance]
  const activeJobs = jobs.filter(job =>

    job.assigned_machine_id && 
    (job.status === 'assigned' || job.status === 'in_setup' || job.status === 'in_progress')
  )

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'critical': return 'bg-red-500'
      case 'high': return 'bg-yellow-500'
      case 'normal': return 'bg-green-500'
      case 'low': return 'bg-gray-500'
      default: return 'bg-gray-500'
    }
  }

  const getPriorityBorder = (priority) => {
    switch (priority) {
      case 'critical': return 'border-red-700'
      case 'high': return 'border-yellow-700'
      case 'normal': return 'border-green-700'
      case 'low': return 'border-gray-700'
      default: return 'border-gray-700'
    }
  }

  // Get priority dot color (for WO Lookup)
  const getPriorityDot = (priority) => {
    switch (priority) {
      case 'critical': return 'bg-red-500'
      case 'high': return 'bg-yellow-500'
      case 'normal': return 'bg-green-500'
      case 'low': return 'bg-gray-500'
      default: return 'bg-gray-500'
    }
  }

  const getStatusDisplay = (status) => {
    switch (status) {
      case 'in_setup': return { text: 'Setup', color: 'text-yellow-400' }
      case 'in_progress': return { text: 'Running', color: 'text-green-400' }
      case 'assigned': return { text: 'Queued', color: 'text-blue-400' }
      default: return { text: status.replace('_', ' '), color: 'text-gray-400' }
    }
  }

  // Edit job handlers
  const handleEditClick = (job) => {
    setEditingJob(job)
    setEditForm({
      quantity: job.quantity.toString(),
      priority: job.priority
    })
    setShowEditWarning(true)
    setShowCancelConfirm(false)
  }

  const handleEditSave = async () => {
    if (!editingJob) return
    
    setEditSaving(true)
    try {
      // Update job and reset to pending_compliance
      const { error } = await supabase
        .from('jobs')
        .update({
          quantity: parseInt(editForm.quantity),
          priority: editForm.priority,
          status: 'pending_compliance', // Must go back through compliance
          updated_at: new Date().toISOString()
        })
        .eq('id', editingJob.id)
      
      if (error) {
        console.error('Error updating job:', error)
        alert('Failed to update job')
      } else {
        setEditingJob(null)
        fetchData()
      }
    } catch (err) {
      console.error('Unexpected error:', err)
    } finally {
      setEditSaving(false)
    }
  }

  // Lazy-load WO fulfillment summary on expand; cached for the session.
  const ensureWOFulfillment = async (woId) => {
    if (!woId) return
    if (woFulfillmentCache[woId] !== undefined) return
    setWOFulfillmentCache(prev => ({ ...prev, [woId]: 'loading' }))
    const rows = await getWOFulfillmentSummary(woId)
    setWOFulfillmentCache(prev => ({ ...prev, [woId]: rows }))
  }

  const handleToggleWOExpand = (woId) => {
    setExpandedWOs(prev => ({ ...prev, [woId]: !prev[woId] }))
    if (!expandedWOs[woId]) {
      // Was collapsed; now expanding — load fulfillment
      ensureWOFulfillment(woId)
    }
  }

  // WO Lookup — toggle job documents dropdown (load on demand)
  const handleToggleJobDocs = async (jobId) => {
    if (expandedJobDocs[jobId]) {
      setExpandedJobDocs(prev => ({ ...prev, [jobId]: false }))
      return
    }
    setExpandedJobDocs(prev => ({ ...prev, [jobId]: true }))
    if (jobDocCache[jobId]) return

    setLoadingJobDocs(prev => ({ ...prev, [jobId]: true }))
    try {
      const { data, error } = await supabase
        .from('job_documents')
        .select('*, document_type:document_types(*)')
        .eq('job_id', jobId)
        .order('created_at', { ascending: true })
      if (!error) {
        setJobDocCache(prev => ({ ...prev, [jobId]: data || [] }))
      }
    } catch (err) {
      console.error('Error loading job docs:', err)
    } finally {
      setLoadingJobDocs(prev => ({ ...prev, [jobId]: false }))
    }
  }

  const handleViewWODoc = async (fileUrl) => {
    if (!fileUrl || viewingWODoc) return
    setViewingWODoc(fileUrl)
    try {
      const signedUrl = await getDocumentUrl(fileUrl)
      window.open(signedUrl, '_blank')
    } catch (err) {
      console.error('Error opening document:', err)
      alert('Could not open document.')
    } finally {
      setViewingWODoc(null)
    }
  }

  const handleViewTraveler = async (jobId) => {
    if (!jobId) return
    try {
      const { data: fullJob, error: jobError } = await supabase
        .from('jobs')
        .select(`
          id, job_number, quantity, status,
          production_lot_number, good_pieces, actual_end,
          work_order:work_orders ( id, wo_number, customer, po_number, due_date, order_type, order_quantity, stock_quantity ),
          component:parts!component_id ( id, part_number, description, drawing_revision, requires_passivation, material_type:material_types ( name ) ),
          assigned_machine:machines!assigned_machine_id ( name ),
          assigned_user:profiles!assigned_user_id ( full_name )
        `)
        .eq('id', jobId)
        .single()
      if (jobError) throw jobError

      const { data: steps, error: stepsError } = await supabase
        .from('job_routing_steps')
        .select(`*, completed_by_profile:profiles!completed_by(full_name)`)
        .eq('job_id', jobId)
        .neq('status', 'removed')
        .order('step_order')
      if (stepsError) throw stepsError

      const { data: finishingBatches, error: fsError } = await supabase
        .from('finishing_sends')
        .select(`
          id, finishing_lot_number, chemical_lot_number, chemical_lot_number_2,
          material_lot_number, quantity, verified_count, compliance_good_qty, compliance_bad_qty,
          finishing_completed_at, compliance_approved_at,
          finishing_operator:profiles!finishing_operator_id(full_name)
        `)
        .eq('job_id', jobId)
        .not('finishing_completed_at', 'is', null)
        .neq('compliance_status', 'rejected')
        .order('finishing_completed_at', { ascending: false })
      if (fsError) throw fsError

      const { data: outboundSends, error: osError } = await supabase
        .from('outbound_sends')
        .select(`
          id, operation_type, vendor_name, vendor_lot_number,
          quantity, quantity_returned, sent_at, returned_at,
          job_routing_step_id, finishing_send_id,
          finishing_send:finishing_sends!finishing_send_id(id, compliance_approved_at)
        `)
        .eq('job_id', jobId)
        .order('sent_at', { ascending: true })
      if (osError) throw osError

      const woIdForAllocs = fullJob.work_order?.id || fullJob.work_order_id
      if (!woIdForAllocs) {
        console.warn('Traveler: no work_order id available for CO allocation lookup', { jobId: fullJob.id })
      }
      const coAllocations = woIdForAllocs ? await fetchCOAllocationsForTraveler(supabase, woIdForAllocs) : []

      const html = buildTravelerHTML({
        job: fullJob,
        steps: steps || [],
        finishingBatches: finishingBatches || [],
        outboundSends: outboundSends || [],
        coAllocations,
      })
      const win = window.open('', '_blank')
      if (!win) {
        alert('Pop-up blocked. Allow pop-ups for this site to view the traveler.')
        return
      }
      win.document.open()
      win.document.write(html)
      win.document.close()
    } catch (err) {
      console.error('Failed to open traveler:', err)
      alert('Failed to open traveler: ' + err.message)
    }
  }

  const handleCancelJob = async () => {
    if (!editingJob) return
    
    setCancelling(true)
    try {
      // Soft delete - set status to cancelled
      const { error } = await supabase
        .from('jobs')
        .update({
          status: 'cancelled',
          updated_at: new Date().toISOString()
        })
        .eq('id', editingJob.id)
      
      if (error) {
        console.error('Error cancelling job:', error)
        alert('Failed to cancel job')
      } else {
        const { error: releaseErr } = await releaseCOAllocationsIfWODead(supabase, {
          workOrderId: editingJob.work_order_id,
          profileId: profile?.id,
        })
        if (releaseErr) console.error('Failed to release CO allocations after job cancel:', releaseErr)
        // Cancelled jobs never create shortfalls; nothing to evaluate.
        setEditingJob(null)
        setShowCancelConfirm(false)
        fetchData()
      }
    } catch (err) {
      console.error('Unexpected error:', err)
    } finally {
      setCancelling(false)
    }
  }

  const handleMissedEntryStart = (job) => {
    setMissedEntryJob(job)
    setMissedEntryForm({ quantity: '', reason: '', production_lot: '', passivation_lot: '' })
  }
  const handleMissedEntryCancel = () => {
    setMissedEntryJob(null)
    setMissedEntryForm({ quantity: '', reason: '', production_lot: '', passivation_lot: '' })
    setMissedEntrySaving(false)
  }
  const handleMissedEntrySubmit = async () => {
    if (!missedEntryJob) return
    const qty = parseInt(missedEntryForm.quantity, 10)
    const reason = missedEntryForm.reason.trim()
    if (Number.isNaN(qty) || qty <= 0) { alert('Quantity must be a positive number.'); return }
    if (!reason) { alert('A reason is required.'); return }
    setMissedEntrySaving(true)
    try {
      const { error } = await supabase.from('missed_production_entries').insert({
        job_id: missedEntryJob.id, quantity: qty, reason,
        production_lot: missedEntryForm.production_lot.trim() || null,
        passivation_lot: missedEntryForm.passivation_lot.trim() || null,
        created_by: profile.id,
      })
      if (error) throw error
      handleMissedEntryCancel()
      fetchWOLookup()
    } catch (err) {
      console.error('Missed production entry failed:', err)
      alert('Failed to save entry: ' + err.message)
      setMissedEntrySaving(false)
    }
  }

  // WO Lookup cancel job - two-step confirmation
  const handleWOLookupCancelStart = (jobId) => {
    setCancellingJobId(jobId)
    setCancelStep(1)
  }

  const handleWOLookupCancelConfirm = async () => {
    if (!cancellingJobId) return

    setCancelSaving(true)
    try {
      const { data: jobRow, error: jobReadErr } = await supabase
        .from('jobs')
        .select('work_order_id')
        .eq('id', cancellingJobId)
        .single()
      if (jobReadErr) console.error('Failed to read job for WO lookup:', jobReadErr)

      const { error } = await supabase
        .from('jobs')
        .update({
          status: 'cancelled',
          updated_at: new Date().toISOString()
        })
        .eq('id', cancellingJobId)

      if (error) {
        console.error('Error cancelling job:', error)
        alert('Failed to cancel job')
      } else {
        const { error: releaseErr } = await releaseCOAllocationsIfWODead(supabase, {
          workOrderId: jobRow?.work_order_id,
          profileId: profile?.id,
        })
        if (releaseErr) console.error('Failed to release CO allocations after job cancel:', releaseErr)
        // Cancelled jobs never create shortfalls; nothing to evaluate.
        setCancellingJobId(null)
        setCancelStep(0)
        fetchWOLookup()
        fetchData()
      }
    } catch (err) {
      console.error('Unexpected error:', err)
    } finally {
      setCancelSaving(false)
    }
  }

  const handleWOLookupCancelDismiss = () => {
    setCancellingJobId(null)
    setCancelStep(0)
  }

  const StatCard = ({ id, label, value, colorClass = 'text-white', borderClass = 'border-gray-800', onClick, alert = false }) => {
    const isSelected = selectedView === id
    return (
      <button
        onClick={() => onClick(id)}
        className={`bg-gray-900 rounded-lg border p-4 text-left transition-all relative ${
          isSelected 
            ? 'border-skynet-accent ring-2 ring-skynet-accent/50' 
            : borderClass + ' hover:border-gray-600'
        }`}
      >
        {alert && value > 0 && (
          <span className="absolute -top-1 -right-1 flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
          </span>
        )}
        <p className={`text-sm ${isSelected ? 'text-skynet-accent' : 'text-gray-500'}`}>{label}</p>
        <p className={`text-2xl font-bold ${colorClass}`}>{value}</p>
      </button>
    )
  }

  // NEW: Count machines that are effectively DOWN
  const machinesDownCount = machines.filter(m => 
    m.status === 'down' || 
    getOngoingDowntimeForMachine(m.id) || 
    getActiveMaintenanceForMachine(m.id)
  ).length

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-skynet-accent border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-500 font-mono">Loading machine status...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6 pb-12">
      {/* Action Bar */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <h2 className="text-xl font-semibold text-white">Machine Status</h2>
          
          {/* DOWN machines indicator */}
          {machinesDownCount > 0 && (
            <span className="flex items-center gap-1.5 px-2 py-1 bg-red-900/30 text-red-400 border border-red-800 rounded text-xs font-medium animate-pulse">
              <AlertTriangle size={12} />
              {machinesDownCount} DOWN
            </span>
          )}
          
          {/* Auto-refresh indicator */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setAutoRefresh(!autoRefresh)}
              className={`flex items-center gap-1.5 px-2 py-1 rounded text-xs transition-colors ${
                autoRefresh 
                  ? 'bg-green-900/30 text-green-400 border border-green-800 hover:bg-green-900/50' 
                  : 'bg-gray-800 text-gray-500 border border-gray-700 hover:bg-gray-700'
              }`}
              title={autoRefresh ? 'Auto-refresh enabled (30s)' : 'Auto-refresh disabled'}
            >
              <RefreshCw size={12} className={isRefreshing ? 'animate-spin' : ''} />
              <span>{autoRefresh ? 'Auto' : 'Manual'}</span>
            </button>
            {lastUpdated && (
              <span className="text-xs text-gray-500">
                Updated {lastUpdated.toLocaleTimeString()}
              </span>
            )}
            {!autoRefresh && (
              <button
                onClick={() => fetchData(true)}
                disabled={isRefreshing}
                className="flex items-center gap-1 px-2 py-1 bg-gray-800 hover:bg-gray-700 text-gray-400 rounded text-xs transition-colors disabled:opacity-50"
              >
                <RefreshCw size={12} className={isRefreshing ? 'animate-spin' : ''} />
                Refresh
              </button>
            )}
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleOpenWOLookup}
            className="flex items-center gap-2 px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white font-medium rounded transition-colors"
          >
            <ClipboardList size={20} />
            <span className="hidden sm:inline">Work Orders</span>
          </button>
          {canCreateWorkOrders && (
            <>
              <button
                onClick={() => setShowMaintenanceModal(true)}
                className="flex items-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white font-medium rounded transition-colors"
              >
                <Wrench size={20} />
                <span className="hidden sm:inline">Maintenance Order</span>
              </button>
              <button
                onClick={() => setShowCreateModal(true)}
                className="flex items-center gap-2 px-4 py-2 bg-skynet-accent hover:bg-blue-600 text-white font-medium rounded transition-colors"
              >
                <Plus size={20} />
                New Work Order
              </button>
            </>
          )}
        </div>
      </div>

      {/* Stats Bar - ordered to follow process flow. Column count adapts to the
          Assembly tile's visibility — 7 cols when shown, 6 when hidden, so tiles
          always span the full row width. */}
      <div className={`grid grid-cols-2 md:grid-cols-4 gap-4 ${
        FEATURES.ASSEMBLY_MODULE ? 'lg:grid-cols-7' : 'lg:grid-cols-6'
      }`}>
        <StatCard
          id="lineup"
          label="Machine Lineup"
          value={machines.length}
          onClick={setSelectedView}
        />
        <StatCard
          id="compliance"
          label="Pending Compliance"
          value={pendingComplianceJobs.length + pendingBatchComplianceCount}
          colorClass="text-purple-400"
          borderClass={(pendingComplianceJobs.length + pendingBatchComplianceCount) > 0 ? 'border-purple-800' : 'border-gray-800'}
          onClick={setSelectedView}
        />
        <StatCard
          id="unassigned"
          label="Unassigned"
          value={unassignedJobs.length}
          colorClass="text-yellow-500"
          borderClass={unassignedJobs.length > 0 ? 'border-yellow-800' : 'border-gray-800'}
          onClick={setSelectedView}
        />
        <StatCard
          id="outsourced"
          label="Outsourced"
          value={outsourcedCount}
          colorClass="text-orange-400"
          borderClass={outsourcedCount > 0 ? 'border-orange-800' : 'border-gray-800'}
          onClick={setSelectedView}
        />
        <StatCard
          id="active"
          label="Active Jobs"
          value={activeJobs.length}
          colorClass="text-skynet-accent"
          onClick={setSelectedView}
        />
        {FEATURES.ASSEMBLY_MODULE && (
          <StatCard
            id="assembly"
            label="Assembly"
            value={assemblyCount}
            colorClass="text-green-400"
            borderClass={assemblyCount > 0 ? 'border-green-800' : 'border-gray-800'}
            onClick={setSelectedView}
          />
        )}
        <StatCard
          id="tco"
          label="TCO Review"
          value={tcoWOs.length}
          colorClass="text-amber-400"
          borderClass={tcoWOs.length > 0 ? 'border-amber-800' : 'border-gray-800'}
          onClick={setSelectedView}
        />
      </div>

      {/* Priority Legend */}
      <div className="flex items-center gap-6 text-sm flex-wrap">
        <span className="text-gray-500">Priority:</span>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-red-500"></div>
          <span className="text-gray-400">Critical</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
          <span className="text-gray-400">High</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-green-500"></div>
          <span className="text-gray-400">Normal</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-gray-500"></div>
          <span className="text-gray-400">Low</span>
        </div>
        <span className="text-gray-600">|</span>
        <span className="text-gray-500">Maintenance:</span>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-purple-500"></div>
          <span className="text-gray-400">Unplanned</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-blue-500"></div>
          <span className="text-gray-400">Planned</span>
        </div>
      </div>

      {/* Machine Lineup View */}
      {selectedView === 'lineup' && (
        <>
          {Object.keys(machinesByLocation).length === 0 ? (
            <div className="bg-gray-900 rounded-lg border border-gray-800 p-8 text-center">
              <p className="text-gray-500">No machines configured</p>
            </div>
          ) : (
            <div className="space-y-6">
              {Object.entries(machinesByLocation).map(([locationName, locationMachines]) => (
                <div key={locationName} className="space-y-3">
                  <button
                    onClick={() => toggleLocation(locationName)}
                    className="w-full flex items-center gap-3 pb-2 border-b border-gray-800 hover:border-gray-700 transition-colors cursor-pointer group"
                  >
                    <div className="w-2 h-2 bg-skynet-accent rounded-full"></div>
                    <h3 className="text-lg font-semibold text-white group-hover:text-skynet-accent transition-colors">
                      {locationName}
                    </h3>
                    <span className="text-gray-500 text-sm">
                      ({locationMachines.length} {locationMachines.length === 1 ? 'machine' : 'machines'})
                    </span>
                    <ChevronDown 
                      size={20} 
                      className={`ml-auto text-gray-500 group-hover:text-skynet-accent transition-all ${
                        expandedLocations[locationName] ? 'rotate-0' : '-rotate-90'
                      }`}
                    />
                  </button>

                  {expandedLocations[locationName] && (
                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-3">
                      {locationMachines.filter(m => m.machine_type !== 'finishing').map(machine => (
                        <MachineCard
                          key={machine.id}
                          machine={machine}
                          jobs={getJobsForMachine(machine.id)}
                          getPriorityColor={getPriorityColor}
                          ongoingDowntime={getOngoingDowntimeForMachine(machine.id)}
                          activeMaintenanceJob={getActiveMaintenanceForMachine(machine.id)}
                        />
                      ))}
                      {/* Finishing Station card — shown once per location that has finishing machines */}
                      {locationMachines.some(m => m.machine_type === 'finishing') && (() => {
                        const isAnyTankDown = locationMachines
                          .filter(m => m.machine_type === 'finishing')
                          .some(m => ['down', 'offline', 'maintenance'].includes(m.status))

                        return (
                          <div className={`bg-gray-900 rounded-lg border overflow-hidden ${
                            isAnyTankDown ? 'border-red-800/60' : 'border-cyan-800/50'
                          }`}>
                            {/* Header */}
                            <div className="px-4 py-3 border-b border-gray-800 flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <Beaker size={16} className="text-cyan-400" />
                                <span className="text-white font-semibold text-sm">Finishing Station</span>
                              </div>
                              <div className="flex items-center gap-2">
                                {/* Tank status dots */}
                                {locationMachines.filter(m => m.machine_type === 'finishing').map(m => {
                                  const isDown = ['down', 'offline', 'maintenance'].includes(m.status)
                                  return (
                                    <div key={m.id} className="flex items-center gap-1" title={m.name}>
                                      <div className={`w-2 h-2 rounded-full ${isDown ? 'bg-red-500' : 'bg-green-500'}`} />
                                      <span className={`text-xs ${isDown ? 'text-red-400' : 'text-gray-500'}`}>
                                        {m.name.replace('Finishing ', '')}
                                      </span>
                                    </div>
                                  )
                                })}
                              </div>
                            </div>

                            <div className="p-3 space-y-2">

                              {/* Active batches */}
                              {finishingActive.length > 0 ? (
                                <div className="space-y-1.5">
                                  {finishingActive.map(send => (
                                    <div key={send.id} className="bg-cyan-950/40 border border-cyan-800/40 rounded px-2.5 py-1.5">
                                      <div className="flex items-center justify-between gap-1">
                                        <span className="text-cyan-300 font-mono text-xs font-semibold truncate">
                                          {send.job?.job_number}
                                        </span>
                                        <span className="text-cyan-500 text-xs shrink-0 capitalize">
                                          {send.finishing_stage || 'wash'}
                                        </span>
                                      </div>
                                      <div className="text-gray-400 text-xs truncate mt-0.5">
                                        {send.job?.component?.part_number} · {send.quantity} pcs
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              ) : (
                                <div className="text-center py-2">
                                  <p className="text-gray-600 text-xs">No active batches</p>
                                </div>
                              )}

                              {/* Pending queue count */}
                              {finishingPending.length > 0 && (
                                <div className="flex items-center justify-between px-2 py-1 bg-gray-800/60 rounded text-xs">
                                  <span className="text-gray-400">Pending queue</span>
                                  <span className="text-white font-semibold">{finishingPending.length}</span>
                                </div>
                              )}

                              {/* Launch button */}
                              <a
                                href="/finishing"
                                target="_blank"
                                rel="noopener noreferrer"
                                className="w-full mt-1 py-2 px-3 bg-gray-800 hover:bg-gray-700 border border-gray-700 hover:border-cyan-500 text-gray-400 hover:text-white rounded transition-colors flex items-center justify-center gap-2 text-sm"
                              >
                                <Beaker size={16} />
                                Launch Finishing Station
                              </a>
                            </div>
                          </div>
                        )
                      })()}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </>
      )}

      {/* Active Jobs View - Updated to show status */}
      {selectedView === 'active' && (
        <div className="bg-gray-900 rounded-lg border border-gray-800 p-4">
          <h3 className="text-skynet-accent font-semibold mb-3 flex items-center gap-2">
            <span className="w-2 h-2 bg-skynet-accent rounded-full"></span>
            Active Jobs ({activeJobs.length})
          </h3>
          {activeJobs.length === 0 ? (
            <p className="text-gray-500 text-center py-8">No jobs currently in the lineup</p>
          ) : (
            <div className="space-y-2">
              {activeJobs.map(job => {
                const statusDisplay = getStatusDisplay(job.status)
                const isMaintenance = job.is_maintenance || job.work_order?.order_type === 'maintenance'
                const maintenanceType = job.work_order?.maintenance_type
                return (
                  <div 
                    key={job.id} 
                    className={`flex items-center justify-between rounded p-3 border-l-4 ${
                      isMaintenance 
                        ? maintenanceType === 'unplanned' 
                          ? 'bg-purple-900/20 border-purple-600' 
                          : 'bg-blue-900/20 border-blue-600'
                        : `bg-gray-800 ${getPriorityBorder(job.priority)}`
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      {isMaintenance ? (
                        <Wrench size={16} className={maintenanceType === 'unplanned' ? 'text-purple-400' : 'text-blue-400'} />
                      ) : (
                        <div className={`w-3 h-3 rounded-full ${getPriorityColor(job.priority)}`}></div>
                      )}
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-white font-mono">
                            {isMaintenance ? job.job_number : (job.component?.part_number || job.job_number)}
                          </span>
                          <span className="text-gray-500">•</span>
                          <span className="text-gray-400">{job.work_order?.wo_number}</span>
                          {isMaintenance && (
                            <span className={`text-xs px-1.5 py-0.5 rounded ${
                              maintenanceType === 'unplanned'
                                ? 'bg-purple-600 text-white'
                                : 'bg-blue-600 text-white'
                            }`}>
                              {maintenanceType === 'unplanned' ? 'UNPLANNED' : 'PLANNED'}
                            </span>
                          )}
                        </div>
                        <div className="text-sm text-gray-500">
                          {isMaintenance ? (
                            <span className={maintenanceType === 'unplanned' ? 'text-purple-400' : 'text-blue-400'}>
                              {job.maintenance_description || job.work_order?.notes || 'Maintenance'}
                            </span>
                          ) : (
                            <>
                              <span className="text-skynet-accent font-mono">{job.job_number}</span>
                              <span className="mx-2">•</span>
                              {(() => {
                                const eq = getEffectiveQty(job)
                                return eq.verified && eq.qty !== job.quantity
                                  ? <span>Qty: <span className="text-white">{eq.qty}</span><span className="text-gray-500">/{job.quantity}</span></span>
                                  : <span>Qty: {job.quantity}</span>
                              })()}
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="text-right flex flex-col items-end gap-1">
                      <span className="text-skynet-accent text-sm">{job.assigned_machine?.name}</span>
                      <p className={`text-xs ${statusDisplay.color}`}>{statusDisplay.text}</p>
                      {job.compliance_outcome === 'flag' && (
                        <span className="inline-flex items-center gap-1 text-xs text-amber-400">
                          <Flag size={10} /> Flagged
                        </span>
                      )}
                      {job.compliance_outcome === 'rework' && (
                        <span className="inline-flex items-center gap-1 text-xs text-amber-400">
                          <AlertCircle size={10} /> Rework
                        </span>
                      )}
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </div>
      )}

      {/* Pending Compliance View */}
      {selectedView === 'compliance' && (
        <>
          {jobs.length === 0 ? (
            <div className="bg-gray-900 rounded-lg border border-gray-800 p-8 text-center">
              <p className="text-gray-500">No jobs in the system</p>
            </div>
          ) : (
            <ComplianceReview
              jobs={jobs}
              onUpdate={fetchData}
              profile={profile}
              onNavigateToWO={(woNumber) => {
                setShowWOLookup(true)
                setOrderLookupTab('work_orders')
                setWOLookupSearch(woNumber)
              }}
            />
          )}
        </>
      )}

      {/* Unassigned Jobs View */}
      {selectedView === 'unassigned' && (
        <div className="bg-gray-900 rounded-lg border p-4 border-yellow-800">
          <h3 className="font-semibold mb-3 flex items-center gap-2 text-yellow-500">
            <span className="w-2 h-2 rounded-full animate-pulse bg-yellow-500"></span>
            Ready for Assignment ({unassignedJobs.length})
          </h3>
          {unassignedJobs.length === 0 ? (
            <p className="text-gray-500 text-center py-8">No jobs awaiting assignment</p>
          ) : (
            <div className="space-y-2">
              {unassignedJobs.map(job => (
                <div
                  key={job.id}
                  className={`rounded p-3 border-l-4 bg-gray-800 ${getPriorityBorder(job.priority)}`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-4">
                      <div className={`w-3 h-3 rounded-full mt-1 ${getPriorityColor(job.priority)}`}></div>
                      <div>
                        <div className="flex items-center gap-2 mb-1 flex-wrap">
                          <span className="font-mono text-white">{job.component?.part_number || job.job_number}</span>
                          <span className="text-gray-500">•</span>
                          <span className="text-gray-400">{job.work_order?.wo_number}</span>
                          {job.has_open_shortfall && (
                            <span
                              className="inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded bg-red-950/60 text-red-300 border border-red-700"
                              title="This job has an unresolved shortfall — Scheduler review needed"
                            >
                              <AlertTriangle size={10} /> Shortfall
                            </span>
                          )}
                          {job.status === 'pending_compliance' && (
                            <span
                              className="inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded bg-amber-900/50 text-amber-400 border border-amber-700"
                              title="Awaiting compliance approval — not yet ready for the floor"
                            >
                              <Clock size={10} /> Pending Compliance
                            </span>
                          )}
                        </div>
                        <div className="text-sm text-gray-500">
                          <span className="text-skynet-accent font-mono">{job.job_number}</span>
                          <span className="mx-2">•</span>
                          {(() => {
                            const eq = getEffectiveQty(job)
                            return eq.verified && eq.qty !== job.quantity
                              ? <span>Qty: <span className="text-white">{eq.qty}</span><span className="text-gray-500">/{job.quantity}</span></span>
                              : <span>Qty: {job.quantity}</span>
                          })()}
                        </div>
                      </div>
                    </div>
                    <div className="text-right flex flex-col items-end gap-2">
                      <span className="text-yellow-500 text-sm">Needs Assignment</span>
                      {job.compliance_outcome === 'flag' && (
                        <span className="inline-flex items-center gap-1 text-xs text-amber-400">
                          <Flag size={10} /> Flagged
                        </span>
                      )}
                      {job.compliance_outcome === 'rework' && (
                        <span className="inline-flex items-center gap-1 text-xs text-amber-400">
                          <AlertCircle size={10} /> Rework
                        </span>
                      )}
                      {canWrite && (
                        <button
                          onClick={() => handleEditClick(job)}
                          className="flex items-center gap-1 text-xs text-gray-400 hover:text-skynet-accent transition-colors px-2 py-1 rounded hover:bg-gray-700"
                        >
                          <Edit3 size={12} />
                          Edit
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Edit Job Modal */}
      {editingJob && (
        <div 
          className="fixed inset-0 bg-black/50 flex items-center justify-center z-50"
          onClick={() => setEditingJob(null)}
        >
          <div 
            className="bg-gray-900 rounded-lg border border-gray-700 p-6 max-w-md w-full mx-4 shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-xl font-bold text-white flex items-center gap-2">
                  <Edit3 size={20} className="text-skynet-accent" />
                  Edit Job
                </h3>
                <p className="text-gray-400">{editingJob.job_number}</p>
              </div>
              <button
                onClick={() => setEditingJob(null)}
                className="text-gray-500 hover:text-white transition-colors"
              >
                <X size={24} />
              </button>
            </div>

            {/* Warning Banner - only show when not in cancel mode */}
            {showEditWarning && !showCancelConfirm && (
              <div className="bg-yellow-900/30 border border-yellow-700 rounded-lg p-4 mb-4">
                <div className="flex items-start gap-3">
                  <AlertTriangle size={20} className="text-yellow-500 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-yellow-400 font-medium">Compliance Review Required</p>
                    <p className="text-yellow-300/70 text-sm mt-1">
                      Edited jobs must go back through the compliance review stage before they can be scheduled.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Job Info */}
            <div className="bg-gray-800 rounded-lg p-3 mb-4">
              <p className="text-skynet-accent font-mono">{editingJob.component?.part_number}</p>
              <p className="text-gray-400 text-sm">{editingJob.work_order?.wo_number}</p>
            </div>

            {/* Cancel Confirmation View */}
            {showCancelConfirm ? (
              <div className="space-y-4">
                <div className="bg-red-900/30 border border-red-700 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <Trash2 size={20} className="text-red-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-red-400 font-medium">Cancel this job?</p>
                      <p className="text-red-300/70 text-sm mt-1">
                        This will permanently cancel <span className="font-mono text-white">{editingJob.job_number}</span>. 
                        The job will be removed from all queues and cannot be recovered.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-end gap-3 pt-4 border-t border-gray-700">
                  <button
                    onClick={() => setShowCancelConfirm(false)}
                    className="px-4 py-2 text-gray-400 hover:text-white transition-colors"
                  >
                    Go Back
                  </button>
                  <button
                    onClick={handleCancelJob}
                    disabled={cancelling}
                    className="flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-500 text-white font-medium rounded transition-colors disabled:opacity-50"
                  >
                    {cancelling ? (
                      <>
                        <Loader2 size={16} className="animate-spin" />
                        Cancelling...
                      </>
                    ) : (
                      <>
                        <Trash2 size={16} />
                        Yes, Cancel Job
                      </>
                    )}
                  </button>
                </div>
              </div>
            ) : (
              <>
                {/* Edit Form */}
                <div className="space-y-4">
                  <div>
                    <label className="block text-gray-400 text-sm mb-1">Quantity</label>
                    <input
                      type="number"
                      min="1"
                      value={editForm.quantity}
                      onChange={(e) => setEditForm(prev => ({ ...prev, quantity: e.target.value }))}
                      className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded text-white focus:outline-none focus:border-skynet-accent"
                    />
                  </div>

                  <div>
                    <label className="block text-gray-400 text-sm mb-1">Priority</label>
                    <select
                      value={editForm.priority}
                      onChange={(e) => setEditForm(prev => ({ ...prev, priority: e.target.value }))}
                      className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded text-white focus:outline-none focus:border-skynet-accent"
                    >
                      <option value="critical">Critical</option>
                      <option value="high">High</option>
                      <option value="normal">Normal</option>
                      <option value="low">Low</option>
                    </select>
                  </div>
                </div>

                {/* Cancel Job Button */}
                <button
                  onClick={() => setShowCancelConfirm(true)}
                  className="w-full mt-4 py-2 px-3 text-red-400 hover:text-red-300 hover:bg-red-900/20 border border-red-800/50 hover:border-red-700 rounded transition-colors flex items-center justify-center gap-2 text-sm"
                >
                  <Trash2 size={14} />
                  Cancel Job
                </button>

                {/* Actions */}
                <div className="flex items-center justify-end gap-3 mt-4 pt-4 border-t border-gray-700">
                  <button
                    onClick={() => setEditingJob(null)}
                    className="px-4 py-2 text-gray-400 hover:text-white transition-colors"
                  >
                    Close
                  </button>
                  <button
                    onClick={handleEditSave}
                    disabled={editSaving || !editForm.quantity}
                    className="flex items-center gap-2 px-4 py-2 bg-skynet-accent hover:bg-blue-600 text-white font-medium rounded transition-colors disabled:opacity-50"
                  >
                    {editSaving ? (
                      <>
                        <Loader2 size={16} className="animate-spin" />
                        Saving...
                      </>
                    ) : (
                      <>
                        <Edit3 size={16} />
                        Save & Send to Compliance
                      </>
                    )}
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* Create Work Order Modal */}
      <CreateWorkOrderModal
        isOpen={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        onSuccess={fetchData}
        profile={profile}
      />

      {/* Create Maintenance Modal */}
      <CreateMaintenanceModal
        isOpen={showMaintenanceModal}
        onClose={() => setShowMaintenanceModal(false)}
        onSuccess={fetchData}
        machines={machines}
      />

      {/* Assembly View */}
      {selectedView === 'assembly' && FEATURES.ASSEMBLY_MODULE && (
        <div className="bg-gray-900 rounded-lg border border-gray-800 p-4">
          <Assembly profile={profile} onUpdate={fetchData} />
        </div>
      )}
      {selectedView === 'assembly' && !FEATURES.ASSEMBLY_MODULE && (
        <div className="bg-gray-900 border border-gray-800 rounded-lg p-8 text-center text-gray-400">
          The Assembly module is currently disabled. Contact your administrator if you need access.
        </div>
      )}

      {/* TCO Review View */}
      {selectedView === 'tco' && (
        <TCOReview profile={profile} onUpdate={fetchData} />
      )}

      {/* Outsourced Operations View */}
      {selectedView === 'outsourced' && (
        <OutsourcedJobs profile={profile} />
      )}

      {/* Work Order Lookup Modal */}
      {showWOLookup && (
        <div className="fixed inset-0 bg-black/70 flex items-start justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-gray-900 border border-gray-700 rounded-lg w-full max-w-4xl my-8 max-h-[85vh] flex flex-col">
            {/* Header */}
            <div className="px-6 py-4 border-b border-gray-800 flex items-center justify-between flex-shrink-0">
              <div className="flex items-center gap-3">
                <ClipboardList className="text-skynet-accent" size={24} />
                <div>
                  <h2 className="text-xl font-semibold text-white">Order Lookup</h2>
                  <p className="text-gray-500 text-sm">Work orders and customer orders</p>
                </div>
              </div>
              <button 
                onClick={() => {
                  setShowWOLookup(false)
                  setExpandedJobDocs({})
                  setJobDocCache({})
                }}
                className="text-gray-400 hover:text-white p-2"
              >
                <X size={24} />
              </button>
            </div>

            {/* Tab strip — Work Orders / Customer Orders */}
            <div className="px-6 border-b border-gray-800 flex-shrink-0 flex items-center gap-1">
              <button
                onClick={() => setOrderLookupTab('work_orders')}
                className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors ${
                  orderLookupTab === 'work_orders'
                    ? 'border-skynet-accent text-skynet-accent'
                    : 'border-transparent text-gray-400 hover:text-white'
                }`}
              >
                Work Orders
              </button>
              {(profile?.role === 'admin' || profile?.role === 'scheduler') && (
                <button
                  onClick={() => setOrderLookupTab('shortfalls')}
                  className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors flex items-center gap-2 ${
                    orderLookupTab === 'shortfalls'
                      ? 'border-red-500 text-red-300'
                      : 'border-transparent text-gray-400 hover:text-white'
                  }`}
                >
                  Shortfalls
                  {(() => {
                    const count = woLookupData.reduce(
                      (acc, wo) => acc + (wo.jobs || []).filter(j => j.has_open_shortfall).length,
                      0,
                    )
                    return count > 0 ? (
                      <span className="px-1.5 py-0.5 text-[10px] bg-red-900/60 text-red-200 border border-red-700 rounded">
                        {count}
                      </span>
                    ) : null
                  })()}
                </button>
              )}
              <button
                onClick={() => setOrderLookupTab('customer_orders')}
                className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors ${
                  orderLookupTab === 'customer_orders'
                    ? 'border-purple-400 text-purple-300'
                    : 'border-transparent text-gray-400 hover:text-white'
                }`}
              >
                Customer Orders
              </button>
            </div>

            {/* Search Bar (Work Orders tab only — CustomerOrders has its own search) */}
            {orderLookupTab === 'work_orders' && (
              <div className="px-6 py-4 border-b border-gray-800 flex-shrink-0">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={20} />
                  <input
                    type="text"
                    placeholder="Search by WO#, Job#, Customer, or Part#..."
                    value={woLookupSearch}
                    onChange={(e) => setWOLookupSearch(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:border-skynet-accent focus:outline-none"
                    autoFocus
                  />
                  {woLookupSearch && (
                    <button
                      onClick={() => setWOLookupSearch('')}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white"
                    >
                      <X size={16} />
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* Content */}
            {orderLookupTab === 'customer_orders' ? (
              <div className="flex-1 overflow-y-auto">
                <CustomerOrders
                  profile={profile}
                  embedded={true}
                  onNavigateToWO={(woNumber) => {
                    setOrderLookupTab('work_orders')
                    setWOLookupSearch(woNumber)
                  }}
                />
              </div>
            ) : orderLookupTab === 'shortfalls' ? (
              <div className="flex-1 overflow-y-auto">
                <WOLookupShortfalls
                  profile={profile}
                  onNavigateToWO={(woNumber) => {
                    setOrderLookupTab('work_orders')
                    setWOLookupSearch(woNumber || '')
                  }}
                  onResolved={() => {
                    fetchData()
                    fetchWOLookup()
                  }}
                />
              </div>
            ) : (
            <div className="flex-1 overflow-y-auto p-6">
              {woLookupLoading ? (
                <div className="flex items-center justify-center py-12">
                  <Loader2 size={32} className="animate-spin text-skynet-accent" />
                </div>
              ) : filteredWOLookup.length === 0 && filteredStandaloneJobs.length === 0 ? (
                <div className="text-center py-12">
                  <ClipboardList size={48} className="mx-auto text-gray-600 mb-4" />
                  <p className="text-gray-500">
                    {woLookupSearch ? 'No matching work orders found' : 'No active work orders'}
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {filteredStandaloneJobs.length > 0 && (
                    <div className="border border-cyan-700/40 rounded-lg overflow-hidden bg-cyan-900/10">
                      <button
                        onClick={() => setShowStandaloneSection(prev => !prev)}
                        className="w-full px-4 py-3 flex items-center justify-between hover:bg-cyan-900/20 transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          <ChevronRight
                            size={20}
                            className={`text-cyan-400 transition-transform ${showStandaloneSection ? 'rotate-90' : ''}`}
                          />
                          <Package size={18} className="text-cyan-400" />
                          <span className="text-cyan-200 font-medium">Standalone Finishing Jobs</span>
                          <span className="text-xs px-2 py-0.5 rounded-full bg-cyan-900/40 text-cyan-300 border border-cyan-700">
                            {filteredStandaloneJobs.length}
                          </span>
                        </div>
                        <span className="text-xs text-cyan-400">
                          {showStandaloneSection ? 'Hide' : 'Show'}
                        </span>
                      </button>
                      {showStandaloneSection && (
                        <div className="border-t border-cyan-700/40 bg-gray-800/30">
                          <div className="grid grid-cols-12 px-4 py-2 text-xs text-gray-500 border-b border-gray-700/50">
                            <div className="col-span-2">Job #</div>
                            <div className="col-span-3">Part</div>
                            <div className="col-span-2">Customer</div>
                            <div className="col-span-1 text-center">Qty</div>
                            <div className="col-span-2">Source</div>
                            <div className="col-span-2">Status</div>
                          </div>
                          {filteredStandaloneJobs.map(job => {
                            const eq = getEffectiveQty(job)
                            const badges = getJobBadges(job)
                            return (
                              <div key={job.id} className="grid grid-cols-12 px-4 py-3 border-b border-gray-800/50 last:border-0 hover:bg-gray-800/30">
                                <div className="col-span-2 text-white font-mono text-sm">{job.job_number}</div>
                                <div className="col-span-3 text-sm">
                                  <div className="text-cyan-400">{job.component?.part_number || '—'}</div>
                                  <div className="text-gray-500 text-xs truncate">{job.component?.description}</div>
                                </div>
                                <div className="col-span-2 text-sm text-gray-300">{job.component?.customer || '—'}</div>
                                <div className="col-span-1 text-center">
                                  {eq.verified && eq.qty !== job.quantity ? (
                                    <span className="text-sm">
                                      <span className="text-white font-medium">{eq.qty}</span>
                                      <span className="text-gray-500">/{job.quantity}</span>
                                    </span>
                                  ) : (
                                    <span className="text-white text-sm">{job.quantity}</span>
                                  )}
                                </div>
                                <div className="col-span-2 text-sm text-gray-400 truncate" title={job.source_description || job.machine?.name || ''}>
                                  {job.machine?.name || (job.source_description ? `Received (${job.source_description})` : 'Received')}
                                </div>
                                <div className="col-span-2 flex flex-wrap gap-1">
                                  {badges.map((badge, idx) => (
                                    <span key={idx}
                                      className={`inline-flex items-center gap-1 px-2 py-1 rounded text-xs border ${badge.color}`}>
                                      {renderBadgeIcon(badge.icon)}
                                      {badge.label}
                                    </span>
                                  ))}
                                </div>
                              </div>
                            )
                          })}
                        </div>
                      )}
                    </div>
                  )}
                  {filteredWOLookup.map(wo => {
                    const isExpanded = expandedWOs[wo.id]
                    const allJobsComplete = wo.jobs?.every(j => ['complete', 'cancelled'].includes(j.status))
                    const readyForAssemblyCount = wo.jobs?.filter(j => j.status === 'ready_for_assembly').length || 0
                    const totalJobs = wo.jobs?.length || 0
                    const allocSummary = summarizeWOAllocations(wo.active_allocations)
                    const effectiveDue = formatWODueDate(allocSummary, wo.due_date)

                    return (
                      <div key={wo.id} className={`border rounded-lg overflow-hidden ${
                        allJobsComplete
                          ? 'border-gray-700 bg-gray-800/30'
                          : readyForAssemblyCount === totalJobs
                            ? 'border-emerald-700 bg-emerald-900/20'
                            : 'border-gray-700 bg-gray-800/50'
                      }`}>
                        {/* Customer-order cancellation banner */}
                        {wo.has_cancelled_allocation && (
                          <div className="bg-amber-900/30 border-l-4 border-amber-500 px-3 py-1.5 text-amber-200 text-xs flex items-center justify-between">
                            <span className="flex items-center gap-2">
                              <AlertTriangle size={14} />
                              Customer order cancelled — review allocation
                            </span>
                            <button
                              onClick={async (e) => {
                                e.stopPropagation()
                                if (!confirm('Acknowledge cancellation? This dismisses the banner. The WO is unaffected.')) return
                                const { error: ackErr } = await supabase
                                  .from('work_orders')
                                  .update({ has_cancelled_allocation: false })
                                  .eq('id', wo.id)
                                if (ackErr) {
                                  alert('Failed to acknowledge: ' + ackErr.message)
                                  return
                                }
                                await supabase.from('audit_logs').insert({
                                  event_type: 'co_cancellation_acknowledged',
                                  details: { work_order_id: wo.id, acknowledged_by: profile?.id || null },
                                })
                                fetchWOLookup()
                              }}
                              className="text-amber-300 hover:text-amber-100 underline text-xs"
                            >
                              Acknowledge
                            </button>
                          </div>
                        )}
                        {/* WO Header Row */}
                        <div
                          onClick={() => handleToggleWOExpand(wo.id)}
                          className="w-full px-4 py-3 flex items-center justify-between hover:bg-gray-800/50 transition-colors cursor-pointer"
                        >
                          <div className="flex items-center gap-4">
                            <ChevronRight 
                              size={20} 
                              className={`text-gray-500 transition-transform ${isExpanded ? 'rotate-90' : ''}`} 
                            />
                            <div className={`w-2.5 h-2.5 rounded-full ${getPriorityDot(wo.priority)}`} />
                            <div className="text-left">
                              <div className="flex items-center gap-2">
                                <span className="text-white font-mono font-medium">{wo.wo_number}</span>
                                {wo.order_type === 'make_to_order' && (
                                  <span className="text-xs px-1.5 py-0.5 rounded bg-blue-900/50 text-blue-300 border border-blue-700/50">MTO</span>
                                )}
                                {wo.order_type === 'make_to_stock' && (
                                  <span className="text-xs px-1.5 py-0.5 rounded bg-green-900/50 text-green-300 border border-green-700/50">MTS</span>
                                )}
                                {wo.order_type === 'maintenance' && (
                                  <span className="text-xs px-1.5 py-0.5 rounded bg-orange-900/50 text-orange-300 border border-orange-700/50">MAINT</span>
                                )}
                                {wo.order_type === 'maintenance' && (
                                  <span className={`text-xs px-1.5 py-0.5 rounded ${
                                    wo.maintenance_type === 'unplanned'
                                      ? 'bg-purple-900/50 text-purple-300'
                                      : 'bg-blue-900/50 text-blue-300'
                                  }`}>
                                    {wo.maintenance_type === 'unplanned' ? 'UNPLANNED' : 'PLANNED'}
                                  </span>
                                )}
                                {allJobsComplete && (
                                  <span className="text-xs px-1.5 py-0.5 rounded bg-gray-700 text-gray-400">
                                    COMPLETE
                                  </span>
                                )}
                                {(wo.jobs || []).some(j => j.has_open_shortfall) && (
                                  <span
                                    className="inline-flex items-center gap-1 text-xs px-1.5 py-0.5 rounded bg-red-950/60 text-red-300 border border-red-700"
                                    title="A job on this WO has an unresolved shortfall — Scheduler review needed"
                                  >
                                    <AlertTriangle size={10} /> Shortfall
                                  </span>
                                )}
                                {readyForAssemblyCount === totalJobs && !allJobsComplete && (
                                  <span className="text-xs px-1.5 py-0.5 rounded bg-emerald-900/50 text-emerald-300">
                                    READY FOR ASSEMBLY
                                  </span>
                                )}
                              </div>
                              <div className="flex items-center gap-3 text-sm text-gray-400">
                                <span className="flex items-center gap-1">
                                  <User size={12} />
                                  <CustomerDisplay summary={allocSummary} fallback={wo.customer} />
                                </span>
                                <span className="flex items-center gap-1">
                                  <Calendar size={12} />
                                  Due: {effectiveDue ? new Date(effectiveDue).toLocaleDateString() : 'N/A'}
                                  {allocSummary.hasMultipleDueDates && (
                                    <span className="text-xs text-gray-500 ml-1">(earliest)</span>
                                  )}
                                </span>
                                {wo.order_type !== 'maintenance' && ((wo.order_quantity || 0) + (wo.stock_quantity || 0) > 0) && (
                                  <span className="flex items-center gap-1">
                                    <Package size={12} />
                                    Qty: {(wo.order_quantity || 0) + (wo.stock_quantity || 0)}
                                    {wo.order_quantity > 0 && wo.stock_quantity > 0 && (
                                      <span className="text-gray-500">({wo.order_quantity} order + {wo.stock_quantity} stock)</span>
                                    )}
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            {/* Edit WO button - only for non-maintenance orders */}
                            {wo.order_type !== 'maintenance' && !allJobsComplete && (
                              <button
                                onClick={(e) => {
                                  e.stopPropagation()
                                  setEditingWO(wo)
                                }}
                                className="inline-flex items-center gap-1 px-2 py-1 rounded text-xs border border-skynet-accent/50 text-skynet-accent hover:bg-skynet-accent/10 transition-colors"
                                title="Edit work order"
                              >
                                <Edit3 size={12} />
                                Edit
                              </button>
                            )}
                            <div className="text-right">
                              <span className="text-sm text-gray-400">
                                {wo.jobs?.filter(j => j.status === 'complete').length || 0}/{totalJobs} complete
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* Expanded Assembly & Jobs Hierarchy */}
                        {isExpanded && (
                          <div className="border-t border-gray-700 bg-gray-900/50">
                            {/* CO Fulfillment summary */}
                            {(() => {
                              const cached = woFulfillmentCache[wo.id]
                              if (cached === undefined || cached === 'loading') {
                                return (
                                  <div className="px-4 py-2 bg-gray-900/40 border-b border-gray-800 text-xs text-gray-500 flex items-center gap-2">
                                    <Loader2 size={12} className="animate-spin" />
                                    Loading CO fulfillment…
                                  </div>
                                )
                              }
                              if (!Array.isArray(cached) || cached.length === 0) {
                                return (
                                  <div className="px-4 py-2 bg-gray-900/40 border-b border-gray-800 text-xs text-gray-500">
                                    <span className="uppercase tracking-wide text-gray-600 font-medium mr-2">CO Fulfillment</span>
                                    Stock build — no customer allocations
                                  </div>
                                )
                              }
                              // Compute produced per part_number across jobs on this WO.
                              const producedByPart = {}
                              for (const j of (wo.jobs || [])) {
                                const part = j.component?.part_number
                                if (!part) continue
                                const eq = getEffectiveQty(j)
                                producedByPart[part] = (producedByPart[part] || 0) + (eq?.qty || 0)
                              }
                              return (
                                <div className="px-4 py-3 bg-gray-900/40 border-b border-gray-800">
                                  <div className="text-[10px] uppercase tracking-wide text-gray-500 font-medium mb-2">CO Fulfillment</div>
                                  <div className="overflow-x-auto">
                                    <table className="w-full text-xs">
                                      <thead className="text-gray-500">
                                        <tr className="border-b border-gray-800">
                                          <th className="text-left font-medium py-1 pr-3">Customer</th>
                                          <th className="text-left font-medium py-1 pr-3">PO #</th>
                                          <th className="text-left font-medium py-1 pr-3">Line</th>
                                          <th className="text-right font-medium py-1 pr-3">Ordered</th>
                                          <th className="text-right font-medium py-1 pr-3">Allocated</th>
                                          <th className="text-right font-medium py-1 pr-3">Fulfilled</th>
                                          <th className="text-right font-medium py-1 pr-3">Remaining</th>
                                          <th className="text-left font-medium py-1">Status</th>
                                        </tr>
                                      </thead>
                                      <tbody>
                                        {cached.map(row => {
                                          const produced = producedByPart[row.part_number] || 0
                                          let pill
                                          if (row.satisfied) {
                                            pill = <span className="px-2 py-0.5 rounded text-[10px] bg-green-900/40 text-green-300 border border-green-800">Satisfied</span>
                                          } else if (row.remaining > 0 && produced < row.remaining) {
                                            pill = <span className="px-2 py-0.5 rounded text-[10px] bg-amber-900/40 text-amber-300 border border-amber-800">At risk</span>
                                          } else {
                                            pill = <span className="px-2 py-0.5 rounded text-[10px] bg-gray-800 text-gray-400 border border-gray-700">Open</span>
                                          }
                                          return (
                                            <tr key={row.allocation_id} className="border-b border-gray-800/60 last:border-b-0">
                                              <td className="py-1 pr-3 text-gray-300">{row.customer_name || '—'}</td>
                                              <td className="py-1 pr-3 text-gray-400">{row.po_number || '—'}</td>
                                              <td className="py-1 pr-3 text-gray-400">#{row.line_number}</td>
                                              <td className="py-1 pr-3 text-right text-gray-300">{row.ordered}</td>
                                              <td className="py-1 pr-3 text-right text-gray-300">{row.allocated}</td>
                                              <td className="py-1 pr-3 text-right text-gray-300">{row.fulfilled}</td>
                                              <td className={`py-1 pr-3 text-right ${row.remaining > 0 ? 'text-amber-300' : 'text-gray-500'}`}>{row.remaining}</td>
                                              <td className="py-1">{pill}</td>
                                            </tr>
                                          )
                                        })}
                                      </tbody>
                                    </table>
                                  </div>
                                </div>
                              )
                            })()}

                            {/* Show assemblies with their jobs */}
                            {wo.work_order_assemblies && wo.work_order_assemblies.length > 0 ? (
                              wo.work_order_assemblies.map(woa => {
                                // Only show jobs actually linked to THIS assembly
                                const assemblyJobs = wo.jobs?.filter(j => j.work_order_assembly_id === woa.id) || []
                                
                                return (
                                  <div key={woa.id}>
                                    {/* Assembly Header */}
                                    <div className="px-4 py-3 bg-gray-800/50 border-b border-gray-700">
                                      <div className="flex items-center justify-between">
                                        <div className="flex items-center gap-3">
                                          <Package size={18} className="text-skynet-accent" />
                                          <div>
                                            <span className="text-skynet-accent font-mono font-medium">
                                              {woa.assembly?.part_number || 'Unknown Product'}
                                            </span>
                                            <p className="text-xs text-gray-400">{woa.assembly?.description}</p>
                                          </div>
                                        </div>
                                        <div className="flex flex-col items-end gap-0.5 text-sm">
                                          <span className="text-gray-500">Qty: {woa.quantity}
                                            {woa.order_quantity != null && (
                                              <span className="text-gray-600"> ({woa.order_quantity} order + {woa.stock_quantity || 0} stock)</span>
                                            )}
                                          </span>
                                          {(() => {
                                            const available = computeAvailableQty(woa)
                                            if (available <= 0) return null
                                            const fullyDelivered = available >= woa.quantity
                                            return (
                                              <span className={`text-xs ${fullyDelivered ? 'text-green-400' : 'text-emerald-400/80'}`}>
                                                Available: <span className="font-medium">{available}</span>
                                                {!fullyDelivered && (
                                                  <span className="text-gray-600"> / {woa.quantity}</span>
                                                )}
                                              </span>
                                            )
                                          })()}
                                          {woa.status === 'complete' && (
                                            <span className="text-xs px-2 py-0.5 bg-gray-700 text-gray-400 rounded">
                                              {woa.good_quantity}/{woa.quantity} good
                                            </span>
                                          )}
                                        </div>
                                      </div>
                                    </div>

                                    {/* Assembly Routing — only render if WOA has any routing steps with non-trivial route */}
                                    {woa.work_order_assembly_routing_steps?.length > 0 && (() => {
                                      const sortedAsmSteps = [...woa.work_order_assembly_routing_steps]
                                        .sort((a, b) => a.step_order - b.step_order)
                                      const hasOnlyAssembleStep =
                                        sortedAsmSteps.length === 1 &&
                                        sortedAsmSteps[0].step_name?.toLowerCase() === 'assemble'
                                      // Skip render for trivial single-Assemble routes — no value over the existing UI
                                      if (hasOnlyAssembleStep && !woa.assembly_lot_number) return null
                                      return (
                                        <div className="px-4 py-2 pl-10 bg-cyan-950/10 border-b border-gray-700">
                                          <div className="flex items-center gap-2 mb-1">
                                            <span className="text-[10px] uppercase tracking-wide text-cyan-300 font-medium">Assembly Routing</span>
                                            {woa.assembly_lot_number && (
                                              <span className="flex items-center gap-1 text-xs text-cyan-400 font-mono">
                                                ALN: {woa.assembly_lot_number}
                                              </span>
                                            )}
                                            {woa.status === 'ready_for_outsource' && (
                                              <span className="px-1.5 py-0.5 rounded text-[10px] bg-amber-900/30 text-amber-300 border border-amber-800">Ready for Outsource</span>
                                            )}
                                            {woa.status === 'at_external_vendor' && (
                                              <span className="px-1.5 py-0.5 rounded text-[10px] bg-blue-900/30 text-blue-300 border border-blue-800">At Vendor</span>
                                            )}
                                            {woa.status === 'pending_tco' && (
                                              <span className="px-1.5 py-0.5 rounded text-[10px] bg-emerald-900/30 text-emerald-300 border border-emerald-800">Returned · Pending TCO</span>
                                            )}
                                          </div>
                                          <div className="space-y-0.5">
                                            {sortedAsmSteps.map(step => {
                                              const stepSends = step.step_type === 'external'
                                                ? (woa.assembly_outbound_sends || []).filter(s => s.routing_step_id === step.id)
                                                : []
                                              const totalSent = stepSends.reduce((sum, s) => sum + (s.quantity || 0), 0)
                                              const totalReturned = stepSends.reduce((sum, s) => sum + (s.quantity_returned || 0), 0)
                                              const allReturned = stepSends.length > 0 && stepSends.every(s => s.returned_at != null)

                                              return (
                                                <div key={step.id}>
                                                  {/* Step header row */}
                                                  <div className="flex items-center gap-2 text-xs pl-2 border-l border-cyan-900/40">
                                                    <span className="text-gray-500 font-mono">{step.step_order}.</span>
                                                    <span className={`text-gray-300 ${(step.status === 'removed' || step.status === 'skipped') ? 'line-through' : ''}`}>
                                                      {step.step_name}
                                                    </span>
                                                    {step.step_type === 'external' && (
                                                      <span className="px-1.5 py-0.5 rounded text-[10px] bg-orange-900/30 text-orange-400 border border-orange-800">External</span>
                                                    )}
                                                    {step.is_added_step && (
                                                      <span className="px-1.5 py-0.5 rounded text-[10px] bg-purple-900/30 text-purple-300 border border-purple-800">Ad-hoc</span>
                                                    )}
                                                    {step.status === 'in_progress' && (
                                                      <span className="px-1.5 py-0.5 rounded text-[10px] bg-blue-900/30 text-blue-400 border border-blue-800">In Progress</span>
                                                    )}
                                                    {step.status === 'complete' && step.step_type !== 'external' && (
                                                      <span className="flex items-center gap-1 text-green-400">
                                                        <CheckCircle size={10} />
                                                        {step.lot_number || ''}
                                                      </span>
                                                    )}
                                                    {step.step_type === 'external' && stepSends.length > 0 && (
                                                      <span className="text-gray-500 text-[10px]">
                                                        {totalSent} sent
                                                        {totalReturned > 0 && (
                                                          <span className={allReturned ? 'text-green-400' : 'text-amber-400'}>
                                                            {' '}· {totalReturned} returned
                                                          </span>
                                                        )}
                                                      </span>
                                                    )}
                                                    {step.status === 'pending' && step.step_order === 1 && woa.status === 'in_progress' && (
                                                      <span className="px-1.5 py-0.5 rounded text-[10px] bg-blue-900/30 text-blue-400 border border-blue-800">In Progress</span>
                                                    )}
                                                    {step.status === 'removed' && (
                                                      <span className="px-1.5 py-0.5 rounded text-[10px] bg-gray-800 text-gray-500 border border-gray-700">Removed</span>
                                                    )}
                                                  </div>

                                                  {/* Per-batch outbound_send detail under each external step */}
                                                  {step.step_type === 'external' && stepSends.length > 0 && (
                                                    <div className="ml-6 mt-0.5 space-y-0.5">
                                                      {stepSends.map(send => {
                                                        const letter = woa.assembly_send_letter_map?.[send.id] || ''
                                                        return (
                                                          <div key={send.id} className="flex items-center gap-2 text-[11px] text-gray-400 pl-2 border-l border-purple-900/30 flex-wrap">
                                                            {letter && (
                                                              <span className="px-1 py-0.5 bg-purple-900/30 text-purple-300 rounded font-mono text-[9px]">Batch {letter}</span>
                                                            )}
                                                            {!send.sent_at ? (
                                                              <span className="text-amber-400">Pending send · {send.quantity} pcs queued</span>
                                                            ) : !send.returned_at ? (
                                                              <span className="text-blue-400">
                                                                {send.quantity} sent
                                                                {send.vendor_name && <span className="text-gray-500"> to {send.vendor_name}</span>}
                                                                <span className="text-gray-500"> · awaiting return</span>
                                                              </span>
                                                            ) : (
                                                              <span className="text-green-400">
                                                                {send.quantity} sent → {send.quantity_returned} returned
                                                                {send.vendor_name && <span className="text-gray-500"> · {send.vendor_name}</span>}
                                                                {send.vendor_lot_number && <span className="text-cyan-400"> · {send.vendor_lot_number}</span>}
                                                              </span>
                                                            )}
                                                          </div>
                                                        )
                                                      })}
                                                    </div>
                                                  )}
                                                </div>
                                              )
                                            })}
                                          </div>
                                        </div>
                                      )
                                    })()}

                                    {/* Jobs under this assembly */}
                                    {assemblyJobs.length > 0 ? (
                                      <>
                                        <div className="px-4 py-2 pl-10 bg-gray-800/20 border-b border-gray-700">
                                          <div className="grid grid-cols-12 gap-2 text-xs text-gray-500 font-medium">
                                            <div className="col-span-2">Job #</div>
                                            <div className="col-span-2">Part</div>
                                            <div className="col-span-1 text-center">Qty</div>
                                            <div className="col-span-2">Machine</div>
                                            <div className="col-span-2">Status</div>
                                            <div className="col-span-3 text-right">Actions</div>
                                          </div>
                                        </div>
                                        {assemblyJobs.map(job => {
                                          const canCancel = !['complete', 'cancelled'].includes(job.status) && canWrite
                                          const canSplit = canSplitJobs(profile?.role) && isSplittable(job)
                                          return (
                                            <div 
                                              key={job.id} 
                                              className="px-4 py-3 pl-10 border-b border-gray-800 last:border-b-0 hover:bg-gray-800/30"
                                            >
                                              <div className="grid grid-cols-12 gap-2 items-center">
                                                <div className="col-span-2 flex items-center gap-1.5 flex-wrap">
                                                  <span className="text-white font-mono text-sm">{job.job_number}</span>
                                                  <DocsDeferredBadge job={job} />
                                                  {job.has_open_shortfall && (
                                                    <span
                                                      className="inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded bg-red-950/60 text-red-300 border border-red-700"
                                                      title="This job has an unresolved shortfall — Scheduler review needed"
                                                    >
                                                      <AlertTriangle size={10} /> Shortfall
                                                    </span>
                                                  )}
                                                </div>
                                                <div className="col-span-2">
                                                  <div className="flex items-center gap-2">
                                                    <Wrench size={12} className="text-gray-500 flex-shrink-0" />
                                                    <div className="min-w-0">
                                                      <span className="text-gray-300 text-sm font-mono">{job.component?.part_number}</span>
                                                      <p className="text-xs text-gray-500 truncate">{job.component?.description}</p>
                                                    </div>
                                                  </div>
                                                </div>
                                                <div className="col-span-1 text-center">
                                                  {(() => {
                                                    const eq = getEffectiveQty(job)
                                                    return (
                                                      <div className="flex flex-col items-center gap-0.5">
                                                        {eq.verified && eq.qty !== job.quantity ? (
                                                          <span className="text-sm">
                                                            <span className="text-white font-medium">{eq.qty}</span>
                                                            <span className="text-gray-500">/{job.quantity}</span>
                                                            {eq.hasMissed && <span className="text-sky-400 ml-1" title="Includes a manual batch">+</span>}
                                                          </span>
                                                        ) : (
                                                          <span className="text-white text-sm">{job.quantity}</span>
                                                        )}
                                                      </div>
                                                    )
                                                  })()}
                                                </div>
                                                <div className="col-span-2">
                                                  <span className="text-gray-400 text-sm truncate block">{job.machine?.name || 'Unassigned'}</span>
                                                </div>
                                                <div className="col-span-2 flex flex-wrap gap-1">
                                                  {getJobBadges(job).map((badge, idx) => (
                                                    <span key={idx}
                                                      className={`inline-flex items-center gap-1 px-2 py-1 rounded text-xs border ${badge.color}`}>
                                                      {renderBadgeIcon(badge.icon)}
                                                      {badge.label}
                                                    </span>
                                                  ))}
                                                </div>
                                                <div className="col-span-3 text-right flex items-center justify-end gap-1">
                                                  {!['pending_compliance', 'cancelled'].includes(job.status) && (
                                                    <button
                                                      onClick={() => setPrintPackageJob(job)}
                                                      className="inline-flex items-center gap-1 px-2 py-1 text-xs text-gray-400 hover:text-white hover:bg-gray-700 border border-gray-700 hover:border-gray-600 rounded transition-colors"
                                                    >
                                                      <Printer size={12} />
                                                      Print
                                                    </button>
                                                  )}
                                                  {canSplit && (
                                                    <button
                                                      onClick={() => setSplitJobTarget(job)}
                                                      className="inline-flex items-center gap-1 px-2 py-1 text-xs text-skynet-accent hover:text-blue-300 hover:bg-blue-900/30 border border-blue-800/50 hover:border-blue-700 rounded transition-colors"
                                                    >
                                                      <Split size={12} />
                                                      Split
                                                    </button>
                                                  )}
                                                  {canCancel && (
                                                    <button
                                                      onClick={() => handleWOLookupCancelStart(job.id)}
                                                      className="inline-flex items-center gap-1 px-2 py-1 text-xs text-red-400 hover:text-red-300 hover:bg-red-900/30 border border-red-800/50 hover:border-red-700 rounded transition-colors"
                                                    >
                                                      <X size={12} />
                                                      Cancel
                                                    </button>
                                                  )}
                                                </div>
                                              </div>
                                              {['hold', 'flag', 'rework', 'rejected'].includes(job.compliance_outcome) && job.compliance_notes && (
                                                <div className="mt-2 pl-6 flex items-start gap-1.5 text-xs italic text-gray-400">
                                                  {renderBadgeIcon(
                                                    job.compliance_outcome === 'hold' ? 'pause'
                                                    : job.compliance_outcome === 'rejected' ? 'x'
                                                    : job.compliance_outcome === 'rework' ? 'alertcircle'
                                                    : 'flag'
                                                  )}
                                                  <span className="whitespace-pre-wrap">{job.compliance_notes}</span>
                                                </div>
                                              )}
                                              {(job.finishing_sends?.some(s => s.is_partial_send) || job.finishing_sends?.length > 1) && (
                                                <div className="mt-2 space-y-1">
                                                  {[...job.finishing_sends]
                                                    .sort((a, b) => new Date(a.sent_at) - new Date(b.sent_at))
                                                    .map((send, idx) => {
                                                      const label = `Batch ${String.fromCharCode(65 + idx)}`
                                                      return (
                                                        <div key={send.id}
                                                             className="flex items-center gap-2 text-xs pl-2 border-l border-gray-700">
                                                          <span className="text-gray-500 font-mono">{label}</span>
                                                          <span className="text-gray-600">&middot;</span>
                                                          {(() => {
                                                            const bq = getBatchQty(send)
                                                            return (
                                                              <span className="text-gray-400">
                                                                {bq.qty} pcs
                                                                {bq.annotate != null && (
                                                                  <span className="text-gray-600 ml-1">(sent: {bq.annotate})</span>
                                                                )}
                                                              </span>
                                                            )
                                                          })()}
                                                          <span className="text-gray-600">&middot;</span>
                                                          {(() => {
                                                            if (send.status === 'pending_finishing') return <span className="text-gray-400">Pending Finishing</span>
                                                            if (send.status === 'in_finishing') return <span className="text-cyan-400">In Finishing</span>
                                                            const cs = send.compliance_status
                                                            if (cs === 'rejected') return <span className="text-red-400">Compliance Rejected</span>
                                                            if (cs === 'pending_compliance') return <span className="text-yellow-400">Awaiting Compliance</span>
                                                            if (cs !== 'approved') return <span className="text-gray-400">{send.status}</span>

                                                            const linkedOutbound = job.outbound_sends?.find(os => os.finishing_send_id === send.id)
                                                            if (linkedOutbound) {
                                                              if (linkedOutbound.returned_at) return <span className="text-emerald-400">Returned · {linkedOutbound.vendor_name}</span>
                                                              return <span className="text-blue-400">At Vendor · {linkedOutbound.vendor_name}</span>
                                                            }
                                                            const hasPendingExternal = job.job_routing_steps?.some(
                                                              s => s.step_type === 'external' && ['pending', 'in_progress'].includes(s.status)
                                                            )
                                                            if (hasPendingExternal) return <span className="text-amber-400">Ready for Outsource</span>
                                                            return <span className="text-emerald-400">Compliance Approved</span>
                                                          })()}
                                                        </div>
                                                      )
                                                    })
                                                  }
                                                </div>
                                              )}
                                              {job.missed_production_entries?.length > 0 && (
                                                <div className="mt-2 space-y-1">
                                                  {job.missed_production_entries.map((m) => (
                                                    <div key={m.id} className="flex items-center gap-2 text-xs pl-2 border-l border-sky-800">
                                                      <span className="text-sky-400 font-mono">Manual Batch</span>
                                                      <span className="text-gray-600">&middot;</span>
                                                      <span className="text-gray-400">{m.quantity} pcs</span>
                                                      {m.production_lot && (<><span className="text-gray-600">&middot;</span><span className="text-gray-500">lot {m.production_lot}</span></>)}
                                                      {m.reason && <span className="text-gray-600 italic truncate">&mdash; {m.reason}</span>}
                                                    </div>
                                                  ))}
                                                </div>
                                              )}
                                              {['admin', 'compliance'].includes(profile?.role) && (
                                                <button
                                                  onClick={() => handleMissedEntryStart(job)}
                                                  className="mt-2 inline-flex items-center gap-1 text-[11px] text-sky-400 hover:text-sky-300"
                                                >
                                                  <Plus size={12} /> Manual Batch
                                                </button>
                                              )}

                                              {/* Routing steps */}
                                              {job.job_routing_steps?.length > 0 && (() => {
                                                const pln = job.production_lot_number
                                                || [...(job.job_materials || [])]
                                                    .filter(m => m.lot_number)
                                                    .sort((a, b) => new Date(a.created_at) - new Date(b.created_at))[0]
                                                    ?.lot_number
                                                const fln = [...(job.finishing_sends || [])]
                                                  .filter(s => s.finishing_lot_number)
                                                  .sort((a, b) => new Date(b.finishing_completed_at || b.sent_at) - new Date(a.finishing_completed_at || a.sent_at))[0]
                                                  ?.finishing_lot_number
                                                const sortedSteps = [...job.job_routing_steps].sort((a, b) => a.step_order - b.step_order)
                                                const finishingSteps = sortedSteps.filter(s => s.step_type !== 'external' && !s.step_name.toLowerCase().includes('machine'))
                                                const middleFinishingIdx = finishingSteps.length > 0 ? Math.floor(finishingSteps.length / 2) : -1
                                                const middleFinishingStepId = finishingSteps[middleFinishingIdx]?.id
                                                return (
                                                <div className="mt-2 space-y-1">
                                                  <span className="text-[10px] uppercase tracking-wide text-gray-600 font-medium">Routing</span>
                                                  {sortedSteps.map(step => (
                                                      <div key={step.id} className="flex items-center gap-2 text-xs pl-2 border-l border-gray-700">
                                                        <span className="text-gray-500 font-mono">{step.step_order}.</span>
                                                        <span className={`text-gray-300 ${(step.status === 'removed' || step.status === 'skipped') ? 'line-through' : ''}`}>{step.step_name}</span>
                                                        {step.step_type === 'external' && (
                                                          <span className="px-1.5 py-0.5 rounded text-[10px] bg-orange-900/30 text-orange-400 border border-orange-800">External</span>
                                                        )}
                                                        {step.status === 'in_progress' && (
                                                          <span className="px-1.5 py-0.5 rounded text-[10px] bg-blue-900/30 text-blue-400 border border-blue-800">At Vendor</span>
                                                        )}
                                                        {step.status === 'complete' && (
                                                          <span className="flex items-center gap-1 text-green-400">
                                                            <CheckCircle size={10} />
                                                            {step.step_type !== 'external' && (step.lot_number || '')}
                                                          </span>
                                                        )}
                                                        {step.status === 'removed' && (
                                                          <span className="px-1.5 py-0.5 rounded text-[10px] bg-gray-800 text-gray-500 border border-gray-700">Removed</span>
                                                        )}
                                                        {step.status === 'skipped' && (
                                                          <span className="px-1.5 py-0.5 rounded text-[10px] bg-gray-800 text-gray-500 border border-gray-700">Skipped</span>
                                                        )}
                                                        {step.step_name.toLowerCase().includes('machine') && pln && (
                                                          <span className="flex items-center gap-1 text-cyan-400">
                                                            <CheckCircle size={10} className="text-green-400" />
                                                            {pln}
                                                          </span>
                                                        )}
                                                        {step.id === middleFinishingStepId && fln && (
                                                          <span className="flex items-center gap-1 text-cyan-400">
                                                            <CheckCircle size={10} className="text-green-400" />
                                                            {fln}
                                                          </span>
                                                        )}
                                                      </div>
                                                    ))
                                                  }
                                                </div>
                                                )
                                              })()}

                                              {/* Outsourcing sends */}
                                              {job.outbound_sends?.length > 0 && (
                                                <div className="mt-2 space-y-1">
                                                  <span className="text-[10px] uppercase tracking-wide text-gray-600 font-medium">Outsourcing</span>
                                                  {job.outbound_sends.map(send => {
                                                    const opLabel = { heat_treat: 'Heat Treatment', cad_plating: 'Cad Plating', black_oxide: 'Black Oxide', painting: 'Painting', priming: 'Priming' }[send.operation_type] || send.operation_type
                                                    const overdue = send.expected_return_at && !send.returned_at && isPastToday(send.expected_return_at)
                                                    return (
                                                      <div key={send.id} className="flex items-center gap-2 text-xs pl-2 border-l border-gray-700 flex-wrap">
                                                        <Truck size={10} className="text-gray-500 flex-shrink-0" />
                                                        <span className="text-gray-300">{send.vendor_name}</span>
                                                        <span className="text-gray-600">&middot;</span>
                                                        <span className="text-gray-400">{opLabel}</span>
                                                        <span className="text-gray-600">&middot;</span>
                                                        <span className="text-gray-400">{send.quantity} pcs</span>
                                                        <span className="text-gray-600">&middot;</span>
                                                        {send.returned_at ? (
                                                          <span className="text-green-400">
                                                            Returned {new Date(send.returned_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                                                            {send.vendor_lot_number ? ` | Lot: ${send.vendor_lot_number}` : ''}
                                                            {send.quantity_returned ? ` | Qty: ${send.quantity_returned}` : ''}
                                                          </span>
                                                        ) : (
                                                          <span className={overdue ? 'text-red-400 font-medium' : 'text-gray-400'}>
                                                            {overdue && '⚠ '}
                                                            Sent {send.sent_at ? new Date(send.sent_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) : '—'}
                                                            {send.expected_return_at ? ` · Due ${formatDateOnly(send.expected_return_at)}` : ''}
                                                          </span>
                                                        )}
                                                      </div>
                                                    )
                                                  })}
                                                </div>
                                              )}

                                              {/* Documents toggle */}
                                              <div className="mt-2 flex items-center gap-2 cursor-pointer select-none group" onClick={() => handleToggleJobDocs(job.id)}>
                                                <ChevronRight size={13} className={`text-gray-600 transition-transform flex-shrink-0 ${expandedJobDocs[job.id] ? 'rotate-90' : ''}`} />
                                                <FileText size={13} className="text-gray-600 group-hover:text-gray-400 transition-colors" />
                                                <span className="text-xs text-gray-600 group-hover:text-gray-400 transition-colors">
                                                  {expandedJobDocs[job.id] ? 'Hide documents' : jobDocCache[job.id] ? `Documents (${jobDocCache[job.id].length + 1})` : 'View documents'}
                                                </span>
                                                {loadingJobDocs[job.id] && <Loader2 size={11} className="animate-spin text-gray-600 ml-1" />}
                                              </div>
                                              {expandedJobDocs[job.id] && (
                                                <div className="mt-2 pl-4 border-l-2 border-gray-800 space-y-1">
                                                  <button
                                                    onClick={() => handleViewTraveler(job.id)}
                                                    className="w-full flex items-center gap-2 px-2 py-1.5 rounded hover:bg-cyan-900/20 transition-colors text-left group"
                                                  >
                                                    <div className="w-6 h-6 rounded bg-cyan-800/40 flex items-center justify-center flex-shrink-0">
                                                      <FileText size={12} className="text-cyan-300" />
                                                    </div>
                                                    <div className="flex-1 min-w-0">
                                                      <p className="text-white text-xs truncate group-hover:text-cyan-300 transition-colors">Job Traveler</p>
                                                      <p className="text-gray-500 text-[10px] truncate">Live — reflects current routing & job data</p>
                                                    </div>
                                                    <ExternalLink size={11} className="text-gray-600 group-hover:text-cyan-300 transition-colors flex-shrink-0" />
                                                  </button>
                                                  {loadingJobDocs[job.id] ? (
                                                    <div className="py-2 flex items-center gap-2">
                                                      <Loader2 size={13} className="animate-spin text-gray-600" />
                                                      <span className="text-xs text-gray-600">Loading...</span>
                                                    </div>
                                                  ) : !jobDocCache[job.id] || jobDocCache[job.id].length === 0 ? null : (
                                                    jobDocCache[job.id].map(doc => (
                                                      <button key={doc.id} onClick={() => handleViewWODoc(doc.file_url)} disabled={!doc.file_url || viewingWODoc === doc.file_url} className="w-full flex items-center gap-2 px-2 py-1.5 rounded hover:bg-gray-800 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-left group">
                                                        <div className="w-6 h-6 rounded bg-gray-700 flex items-center justify-center flex-shrink-0">
                                                          {viewingWODoc === doc.file_url ? <Loader2 size={12} className="animate-spin text-gray-400" /> : <FileText size={12} className="text-gray-400" />}
                                                        </div>
                                                        <div className="flex-1 min-w-0">
                                                          <p className="text-white text-xs truncate group-hover:text-skynet-accent transition-colors">{doc.file_name || 'Unnamed document'}</p>
                                                          {doc.document_type?.name && <p className="text-gray-600 text-[10px] truncate">{doc.document_type.name}</p>}
                                                        </div>
                                                        {doc.status === 'approved' ? <CheckCircle size={11} className="text-green-500 flex-shrink-0" /> : <Clock size={11} className="text-yellow-500 flex-shrink-0" />}
                                                        <ExternalLink size={11} className="text-gray-600 group-hover:text-skynet-accent transition-colors flex-shrink-0" />
                                                      </button>
                                                    ))
                                                  )}
                                                  {canManageJobDocs && (
                                                    <button
                                                      onClick={() => setAddDocFor({ jobId: job.id, partId: job.component_id || job.component?.id || null })}
                                                      className="w-full flex items-center gap-2 px-2 py-1.5 rounded hover:bg-gray-800 transition-colors text-left text-xs text-skynet-accent hover:text-blue-300"
                                                    >
                                                      <Plus size={12} />
                                                      Add Document
                                                    </button>
                                                  )}
                                                </div>
                                              )}
                                            </div>
                                          )
                                        })}
                                      </>
                                    ) : (
                                      <div className="px-4 py-3 pl-10 text-sm text-gray-500 italic border-b border-gray-700">
                                        No jobs linked to this assembly
                                      </div>
                                    )}
                                  </div>
                                )
                              })
                            ) : wo.jobs && wo.jobs.length > 0 ? (
                              // Fallback: No assemblies, just show jobs directly (maintenance orders, etc.)
                              <>
                                <div className="px-4 py-2 bg-gray-800/30 border-b border-gray-700">
                                  <div className="grid grid-cols-12 gap-2 text-xs text-gray-500 font-medium">
                                    <div className="col-span-2">Job #</div>
                                    <div className="col-span-2">Part</div>
                                    <div className="col-span-1 text-center">Qty</div>
                                    <div className="col-span-2">Machine</div>
                                    <div className="col-span-2">Status</div>
                                    <div className="col-span-3 text-right">Actions</div>
                                  </div>
                                </div>
                                {wo.jobs.map(job => {
                                  const statusBadge = getStatusBadge(job.status)
                                  const canCancel = !['complete', 'cancelled'].includes(job.status)
                                  const canSplit = canSplitJobs(profile?.role) && isSplittable(job)
                                  return (
                                    <div 
                                      key={job.id} 
                                      className="px-4 py-3 border-b border-gray-800 last:border-b-0 hover:bg-gray-800/30"
                                    >
                                      <div className="grid grid-cols-12 gap-2 items-center">
                                        <div className="col-span-2">
                                          <span className="text-white font-mono text-sm">{job.job_number}</span>
                                        </div>
                                        <div className="col-span-2">
                                          <div className="flex items-center gap-2">
                                            <Package size={14} className="text-gray-500 flex-shrink-0" />
                                            <div className="min-w-0">
                                              <span className="text-skynet-accent text-sm font-mono">{job.component?.part_number}</span>
                                              <p className="text-xs text-gray-500 truncate">{job.component?.description}</p>
                                            </div>
                                          </div>
                                        </div>
                                        <div className="col-span-1 text-center">
                                          {(() => {
                                            const eq = getEffectiveQty(job)
                                            return (
                                              <div className="flex flex-col items-center gap-0.5">
                                                {eq.verified && eq.qty !== job.quantity ? (
                                                  <span className="text-sm">
                                                    <span className="text-white font-medium">{eq.qty}</span>
                                                    <span className="text-gray-500">/{job.quantity}</span>
                                                    {eq.hasMissed && <span className="text-sky-400 ml-1" title="Includes a manual batch">+</span>}
                                                  </span>
                                                ) : (
                                                  <span className="text-white text-sm">{job.quantity}</span>
                                                )}
                                              </div>
                                            )
                                          })()}
                                        </div>
                                        <div className="col-span-2">
                                          <span className="text-gray-400 text-sm truncate block">{job.machine?.name || 'Unassigned'}</span>
                                        </div>
                                        <div className="col-span-2">
                                          <span className={`inline-flex items-center gap-1 px-2 py-1 rounded text-xs border ${statusBadge.color}`}>
                                            {job.status === 'in_progress' && <Clock size={10} className="animate-pulse" />}
                                            {job.status === 'complete' && <CheckCircle size={10} />}
                                            {(job.status === 'pending_passivation' || job.status === 'in_passivation') && <Beaker size={10} />}
                                            {statusBadge.label}
                                          </span>
                                        </div>
                                        <div className="col-span-3 text-right flex items-center justify-end gap-1">
                                          {!['pending_compliance', 'cancelled'].includes(job.status) && (
                                            <button
                                              onClick={() => setPrintPackageJob(job)}
                                              className="inline-flex items-center gap-1 px-2 py-1 text-xs text-gray-400 hover:text-white hover:bg-gray-700 border border-gray-700 hover:border-gray-600 rounded transition-colors"
                                            >
                                              <Printer size={12} />
                                              Print
                                            </button>
                                          )}
                                          {canSplit && (
                                            <button
                                              onClick={() => setSplitJobTarget(job)}
                                              className="inline-flex items-center gap-1 px-2 py-1 text-xs text-skynet-accent hover:text-blue-300 hover:bg-blue-900/30 border border-blue-800/50 hover:border-blue-700 rounded transition-colors"
                                            >
                                              <Split size={12} />
                                              Split
                                            </button>
                                          )}
                                          {canCancel && (
                                            <button
                                              onClick={() => handleWOLookupCancelStart(job.id)}
                                              className="inline-flex items-center gap-1 px-2 py-1 text-xs text-red-400 hover:text-red-300 hover:bg-red-900/30 border border-red-800/50 hover:border-red-700 rounded transition-colors"
                                            >
                                              <X size={12} />
                                              Cancel
                                            </button>
                                          )}
                                        </div>
                                      </div>
                                      {(job.finishing_sends?.some(s => s.is_partial_send) || job.finishing_sends?.length > 1) && (
                                        <div className="mt-2 space-y-1">
                                          {[...job.finishing_sends]
                                            .sort((a, b) => new Date(a.sent_at) - new Date(b.sent_at))
                                            .map((send, idx) => {
                                              const label = `Batch ${String.fromCharCode(65 + idx)}`
                                              return (
                                                <div key={send.id}
                                                     className="flex items-center gap-2 text-xs pl-2 border-l border-gray-700">
                                                  <span className="text-gray-500 font-mono">{label}</span>
                                                  <span className="text-gray-600">&middot;</span>
                                                  {(() => {
                                                    const bq = getBatchQty(send)
                                                    return (
                                                      <span className="text-gray-400">
                                                        {bq.qty} pcs
                                                        {bq.annotate != null && (
                                                          <span className="text-gray-600 ml-1">(sent: {bq.annotate})</span>
                                                        )}
                                                      </span>
                                                    )
                                                  })()}
                                                  <span className="text-gray-600">&middot;</span>
                                                  {(() => {
                                                    if (send.status === 'pending_finishing') return <span className="text-gray-400">Pending Finishing</span>
                                                    if (send.status === 'in_finishing') return <span className="text-cyan-400">In Finishing</span>
                                                    const cs = send.compliance_status
                                                    if (cs === 'rejected') return <span className="text-red-400">Compliance Rejected</span>
                                                    if (cs === 'pending_compliance') return <span className="text-yellow-400">Awaiting Compliance</span>
                                                    if (cs !== 'approved') return <span className="text-gray-400">{send.status}</span>

                                                    const linkedOutbound = job.outbound_sends?.find(os => os.finishing_send_id === send.id)
                                                    if (linkedOutbound) {
                                                      if (linkedOutbound.returned_at) return <span className="text-emerald-400">Returned · {linkedOutbound.vendor_name}</span>
                                                      return <span className="text-blue-400">At Vendor · {linkedOutbound.vendor_name}</span>
                                                    }
                                                    const hasPendingExternal = job.job_routing_steps?.some(
                                                      s => s.step_type === 'external' && ['pending', 'in_progress'].includes(s.status)
                                                    )
                                                    if (hasPendingExternal) return <span className="text-amber-400">Ready for Outsource</span>
                                                    return <span className="text-emerald-400">Compliance Approved</span>
                                                  })()}
                                                </div>
                                              )
                                            })
                                          }
                                        </div>
                                      )}
                                      {job.missed_production_entries?.length > 0 && (
                                        <div className="mt-2 space-y-1">
                                          {job.missed_production_entries.map((m) => (
                                            <div key={m.id} className="flex items-center gap-2 text-xs pl-2 border-l border-sky-800">
                                              <span className="text-sky-400 font-mono">Manual Batch</span>
                                              <span className="text-gray-600">&middot;</span>
                                              <span className="text-gray-400">{m.quantity} pcs</span>
                                              {m.production_lot && (<><span className="text-gray-600">&middot;</span><span className="text-gray-500">lot {m.production_lot}</span></>)}
                                              {m.reason && <span className="text-gray-600 italic truncate">&mdash; {m.reason}</span>}
                                            </div>
                                          ))}
                                        </div>
                                      )}
                                      {['admin', 'compliance'].includes(profile?.role) && (
                                        <button
                                          onClick={() => handleMissedEntryStart(job)}
                                          className="mt-2 inline-flex items-center gap-1 text-[11px] text-sky-400 hover:text-sky-300"
                                        >
                                          <Plus size={12} /> Manual Batch
                                        </button>
                                      )}

                                      {/* Routing steps */}
                                      {job.job_routing_steps?.length > 0 && (() => {
                                        const pln = job.production_lot_number
                                                || [...(job.job_materials || [])]
                                                    .filter(m => m.lot_number)
                                                    .sort((a, b) => new Date(a.created_at) - new Date(b.created_at))[0]
                                                    ?.lot_number
                                        const fln = [...(job.finishing_sends || [])]
                                          .filter(s => s.finishing_lot_number)
                                          .sort((a, b) => new Date(b.finishing_completed_at || b.sent_at) - new Date(a.finishing_completed_at || a.sent_at))[0]
                                          ?.finishing_lot_number
                                        const sortedSteps = [...job.job_routing_steps].sort((a, b) => a.step_order - b.step_order)
                                        const finishingSteps = sortedSteps.filter(s => s.step_type !== 'external' && !s.step_name.toLowerCase().includes('machine'))
                                        const middleFinishingIdx = finishingSteps.length > 0 ? Math.floor(finishingSteps.length / 2) : -1
                                        const middleFinishingStepId = finishingSteps[middleFinishingIdx]?.id
                                        return (
                                        <div className="mt-2 space-y-1">
                                          <span className="text-[10px] uppercase tracking-wide text-gray-600 font-medium">Routing</span>
                                          {sortedSteps.map(step => (
                                              <div key={step.id} className="flex items-center gap-2 text-xs pl-2 border-l border-gray-700">
                                                <span className="text-gray-500 font-mono">{step.step_order}.</span>
                                                <span className={`text-gray-300 ${(step.status === 'removed' || step.status === 'skipped') ? 'line-through' : ''}`}>{step.step_name}</span>
                                                {step.step_type === 'external' && (
                                                  <span className="px-1.5 py-0.5 rounded text-[10px] bg-orange-900/30 text-orange-400 border border-orange-800">External</span>
                                                )}
                                                {step.status === 'in_progress' && (
                                                  <span className="px-1.5 py-0.5 rounded text-[10px] bg-blue-900/30 text-blue-400 border border-blue-800">At Vendor</span>
                                                )}
                                                {step.status === 'complete' && (
                                                  <span className="flex items-center gap-1 text-green-400">
                                                            <CheckCircle size={10} />
                                                            {step.step_type !== 'external' && (step.lot_number || '')}
                                                          </span>
                                                )}
                                                {step.status === 'removed' && (
                                                  <span className="px-1.5 py-0.5 rounded text-[10px] bg-gray-800 text-gray-500 border border-gray-700">Removed</span>
                                                )}
                                                {step.status === 'skipped' && (
                                                  <span className="px-1.5 py-0.5 rounded text-[10px] bg-gray-800 text-gray-500 border border-gray-700">Skipped</span>
                                                )}
                                                {step.step_name.toLowerCase().includes('machine') && pln && (
                                                  <span className="flex items-center gap-1 text-cyan-400">
                                                    <CheckCircle size={10} className="text-green-400" />
                                                    {pln}
                                                  </span>
                                                )}
                                                {step.id === middleFinishingStepId && fln && (
                                                  <span className="flex items-center gap-1 text-cyan-400">
                                                    <CheckCircle size={10} className="text-green-400" />
                                                    {fln}
                                                  </span>
                                                )}
                                              </div>
                                            ))
                                          }
                                        </div>
                                        )
                                      })()}

                                      {/* Outsourcing sends */}
                                      {job.outbound_sends?.length > 0 && (
                                        <div className="mt-2 space-y-1">
                                          <span className="text-[10px] uppercase tracking-wide text-gray-600 font-medium">Outsourcing</span>
                                          {job.outbound_sends.map(send => {
                                            const opLabel = { heat_treat: 'Heat Treatment', cad_plating: 'Cad Plating', black_oxide: 'Black Oxide', painting: 'Painting', priming: 'Priming' }[send.operation_type] || send.operation_type
                                            const overdue = send.expected_return_at && !send.returned_at && isPastToday(send.expected_return_at)
                                            return (
                                              <div key={send.id} className="flex items-center gap-2 text-xs pl-2 border-l border-gray-700 flex-wrap">
                                                <Truck size={10} className="text-gray-500 flex-shrink-0" />
                                                <span className="text-gray-300">{send.vendor_name}</span>
                                                <span className="text-gray-600">&middot;</span>
                                                <span className="text-gray-400">{opLabel}</span>
                                                <span className="text-gray-600">&middot;</span>
                                                <span className="text-gray-400">{send.quantity} pcs</span>
                                                <span className="text-gray-600">&middot;</span>
                                                {send.returned_at ? (
                                                  <span className="text-green-400">
                                                    Returned {new Date(send.returned_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                                                    {send.vendor_lot_number ? ` | Lot: ${send.vendor_lot_number}` : ''}
                                                    {send.quantity_returned ? ` | Qty: ${send.quantity_returned}` : ''}
                                                  </span>
                                                ) : (
                                                  <span className={overdue ? 'text-red-400 font-medium' : 'text-gray-400'}>
                                                    {overdue && '⚠ '}
                                                    Sent {send.sent_at ? new Date(send.sent_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) : '—'}
                                                    {send.expected_return_at ? ` · Due ${formatDateOnly(send.expected_return_at)}` : ''}
                                                  </span>
                                                )}
                                              </div>
                                            )
                                          })}
                                        </div>
                                      )}

                                      {/* Documents toggle */}
                                      <div className="mt-2 flex items-center gap-2 cursor-pointer select-none group" onClick={() => handleToggleJobDocs(job.id)}>
                                        <ChevronRight size={13} className={`text-gray-600 transition-transform flex-shrink-0 ${expandedJobDocs[job.id] ? 'rotate-90' : ''}`} />
                                        <FileText size={13} className="text-gray-600 group-hover:text-gray-400 transition-colors" />
                                        <span className="text-xs text-gray-600 group-hover:text-gray-400 transition-colors">
                                          {expandedJobDocs[job.id] ? 'Hide documents' : jobDocCache[job.id] ? `Documents (${jobDocCache[job.id].length + 1})` : 'View documents'}
                                        </span>
                                        {loadingJobDocs[job.id] && <Loader2 size={11} className="animate-spin text-gray-600 ml-1" />}
                                      </div>
                                      {expandedJobDocs[job.id] && (
                                        <div className="mt-2 pl-4 border-l-2 border-gray-800 space-y-1">
                                          <button
                                            onClick={() => handleViewTraveler(job.id)}
                                            className="w-full flex items-center gap-2 px-2 py-1.5 rounded hover:bg-cyan-900/20 transition-colors text-left group"
                                          >
                                            <div className="w-6 h-6 rounded bg-cyan-800/40 flex items-center justify-center flex-shrink-0">
                                              <FileText size={12} className="text-cyan-300" />
                                            </div>
                                            <div className="flex-1 min-w-0">
                                              <p className="text-white text-xs truncate group-hover:text-cyan-300 transition-colors">Job Traveler</p>
                                              <p className="text-gray-500 text-[10px] truncate">Live — reflects current routing & job data</p>
                                            </div>
                                            <ExternalLink size={11} className="text-gray-600 group-hover:text-cyan-300 transition-colors flex-shrink-0" />
                                          </button>
                                          {loadingJobDocs[job.id] ? (
                                            <div className="py-2 flex items-center gap-2">
                                              <Loader2 size={13} className="animate-spin text-gray-600" />
                                              <span className="text-xs text-gray-600">Loading...</span>
                                            </div>
                                          ) : !jobDocCache[job.id] || jobDocCache[job.id].length === 0 ? null : (
                                            jobDocCache[job.id].map(doc => (
                                              <button key={doc.id} onClick={() => handleViewWODoc(doc.file_url)} disabled={!doc.file_url || viewingWODoc === doc.file_url} className="w-full flex items-center gap-2 px-2 py-1.5 rounded hover:bg-gray-800 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-left group">
                                                <div className="w-6 h-6 rounded bg-gray-700 flex items-center justify-center flex-shrink-0">
                                                  {viewingWODoc === doc.file_url ? <Loader2 size={12} className="animate-spin text-gray-400" /> : <FileText size={12} className="text-gray-400" />}
                                                </div>
                                                <div className="flex-1 min-w-0">
                                                  <p className="text-white text-xs truncate group-hover:text-skynet-accent transition-colors">{doc.file_name || 'Unnamed document'}</p>
                                                  {doc.document_type?.name && <p className="text-gray-600 text-[10px] truncate">{doc.document_type.name}</p>}
                                                </div>
                                                {doc.status === 'approved' ? <CheckCircle size={11} className="text-green-500 flex-shrink-0" /> : <Clock size={11} className="text-yellow-500 flex-shrink-0" />}
                                                <ExternalLink size={11} className="text-gray-600 group-hover:text-skynet-accent transition-colors flex-shrink-0" />
                                              </button>
                                            ))
                                          )}
                                          {canManageJobDocs && (
                                            <button
                                              onClick={() => setAddDocFor({ jobId: job.id, partId: job.component_id || job.component?.id || null })}
                                              className="w-full flex items-center gap-2 px-2 py-1.5 rounded hover:bg-gray-800 transition-colors text-left text-xs text-skynet-accent hover:text-blue-300"
                                            >
                                              <Plus size={12} />
                                              Add Document
                                            </button>
                                          )}
                                        </div>
                                      )}
                                    </div>
                                  )
                                })}
                              </>
                            ) : (
                              <div className="px-4 py-6 text-center text-gray-500">
                                No jobs found for this work order
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    )
                  })}
                </div>
              )}
            </div>
            )}

            {/* Footer */}
            {orderLookupTab === 'work_orders' && (
              <div className="px-6 py-4 border-t border-gray-800 flex items-center justify-between flex-shrink-0 bg-gray-900">
                <span className="text-sm text-gray-500">
                  {filteredWOLookup.length} work order{filteredWOLookup.length !== 1 ? 's' : ''} found
                </span>
                <button
                  onClick={fetchWOLookup}
                  disabled={woLookupLoading}
                  className="flex items-center gap-2 px-3 py-2 bg-gray-800 hover:bg-gray-700 text-gray-300 rounded text-sm transition-colors disabled:opacity-50"
                >
                  <RefreshCw size={16} className={woLookupLoading ? 'animate-spin' : ''} />
                  Refresh
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Add Pre-System / Missed Production Modal */}
      {missedEntryJob && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-[60]"
             onClick={() => !missedEntrySaving && handleMissedEntryCancel()}>
          <div className="bg-gray-900 rounded-lg border border-gray-700 p-6 max-w-md w-full mx-4 shadow-xl"
               onClick={(e) => e.stopPropagation()}>
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-xl font-bold text-white">Add Manual Batch</h3>
                <p className="text-sm text-gray-400 mt-1">{missedEntryJob.job_number} &middot; {missedEntryJob.component?.part_number}</p>
              </div>
              <button onClick={handleMissedEntryCancel} disabled={missedEntrySaving} className="text-gray-500 hover:text-white disabled:opacity-50"><X size={20} /></button>
            </div>
            <div className="mb-4 p-3 bg-gray-800 rounded border border-gray-700 text-sm text-gray-400">
              Records a batch SkyNet didn't otherwise track &mdash; e.g. parts made before go-live
              or carried over from a prior WO &mdash; so they count toward this job. Added to the
              live produced total, which keeps climbing as real parts flow through finishing. Only
              use for parts SkyNet will never otherwise log, so the count can't double.
            </div>
            <div className="space-y-3 mb-4">
              <div>
                <label className="block text-gray-400 text-sm mb-1">Quantity <span className="text-red-400">*</span></label>
                <input type="number" min="1" value={missedEntryForm.quantity}
                  onChange={(e) => setMissedEntryForm(f => ({ ...f, quantity: e.target.value }))}
                  disabled={missedEntrySaving}
                  className="w-full bg-gray-800 border border-gray-700 rounded px-3 py-2 text-white focus:border-sky-500 focus:outline-none" />
              </div>
              <div>
                <label className="block text-gray-400 text-sm mb-1">Reason <span className="text-red-400">*</span></label>
                <textarea value={missedEntryForm.reason}
                  onChange={(e) => setMissedEntryForm(f => ({ ...f, reason: e.target.value }))}
                  disabled={missedEntrySaving} rows={2}
                  placeholder="e.g. Carry-over from WO 12033 — produced before go-live"
                  className="w-full bg-gray-800 border border-gray-700 rounded px-3 py-2 text-white placeholder-gray-500 text-sm focus:border-sky-500 focus:outline-none" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-gray-400 text-sm mb-1">Production lot</label>
                  <input type="text" value={missedEntryForm.production_lot}
                    onChange={(e) => setMissedEntryForm(f => ({ ...f, production_lot: e.target.value }))}
                    disabled={missedEntrySaving}
                    className="w-full bg-gray-800 border border-gray-700 rounded px-3 py-2 text-white text-sm focus:border-sky-500 focus:outline-none" />
                </div>
                <div>
                  <label className="block text-gray-400 text-sm mb-1">Passivation lot</label>
                  <input type="text" value={missedEntryForm.passivation_lot}
                    onChange={(e) => setMissedEntryForm(f => ({ ...f, passivation_lot: e.target.value }))}
                    disabled={missedEntrySaving}
                    className="w-full bg-gray-800 border border-gray-700 rounded px-3 py-2 text-white text-sm focus:border-sky-500 focus:outline-none" />
                </div>
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <button onClick={handleMissedEntryCancel} disabled={missedEntrySaving} className="px-4 py-2 text-gray-400 hover:text-white disabled:opacity-50">Cancel</button>
              <button onClick={handleMissedEntrySubmit}
                disabled={missedEntrySaving || !missedEntryForm.quantity || !missedEntryForm.reason.trim()}
                className="flex items-center gap-2 px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white rounded disabled:opacity-50 disabled:cursor-not-allowed">
                {missedEntrySaving ? <Loader2 size={16} className="animate-spin" /> : null}
                {missedEntrySaving ? 'Saving...' : 'Add Entry'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Work Order Modal */}
      {editingWO && (
        <EditWorkOrderModal
          isOpen={!!editingWO}
          onClose={() => setEditingWO(null)}
          workOrder={editingWO}
          profile={profile}
          onSuccess={() => {
            fetchWOLookup()
            fetchData()
          }}
        />
      )}

      {/* Cancel Job Confirmation Modal (Two-Step) */}
      {cancellingJobId && cancelStep > 0 && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-[60]" onClick={handleWOLookupCancelDismiss}>
          <div className="bg-gray-900 rounded-lg border border-gray-700 p-6 max-w-md w-full mx-4 shadow-xl" onClick={e => e.stopPropagation()}>
            {cancelStep === 1 ? (
              <>
                {/* Step 1: First Warning */}
                <div className="flex items-start gap-3 mb-4">
                  <div className="p-2 bg-yellow-900/30 rounded-lg">
                    <AlertTriangle size={24} className="text-yellow-500" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white">Cancel This Job?</h3>
                    <p className="text-gray-400 text-sm mt-1">
                      This action will remove the job from all queues. Are you sure you want to proceed?
                    </p>
                  </div>
                </div>
                <div className="bg-yellow-900/20 border border-yellow-800 rounded-lg p-3 mb-6">
                  <p className="text-yellow-300 text-sm">
                    ⚠ Cancelled jobs cannot be restarted. You would need to create a new work order to replace this job.
                  </p>
                </div>
                <div className="flex items-center justify-end gap-3">
                  <button
                    onClick={handleWOLookupCancelDismiss}
                    className="px-4 py-2 text-gray-400 hover:text-white transition-colors"
                  >
                    Never Mind
                  </button>
                  <button
                    onClick={() => setCancelStep(2)}
                    className="flex items-center gap-2 px-4 py-2 bg-red-700 hover:bg-red-600 text-white font-medium rounded transition-colors"
                  >
                    <AlertTriangle size={16} />
                    Yes, I Want to Cancel
                  </button>
                </div>
              </>
            ) : (
              <>
                {/* Step 2: Final Confirmation */}
                <div className="flex items-start gap-3 mb-4">
                  <div className="p-2 bg-red-900/30 rounded-lg">
                    <Trash2 size={24} className="text-red-500" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-red-400">Final Confirmation</h3>
                    <p className="text-gray-400 text-sm mt-1">
                      This is permanent. The job will be marked as cancelled and removed from all workflows.
                    </p>
                  </div>
                </div>
                <div className="bg-red-900/20 border border-red-800 rounded-lg p-3 mb-6">
                  <p className="text-red-300 text-sm font-medium">
                    🚫 This cannot be undone. The job will be permanently cancelled.
                  </p>
                </div>
                <div className="flex items-center justify-end gap-3">
                  <button
                    onClick={handleWOLookupCancelDismiss}
                    className="px-4 py-2 text-gray-400 hover:text-white transition-colors"
                  >
                    Go Back
                  </button>
                  <button
                    onClick={handleWOLookupCancelConfirm}
                    disabled={cancelSaving}
                    className="flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-500 text-white font-medium rounded transition-colors disabled:opacity-50"
                  >
                    {cancelSaving ? (
                      <>
                        <Loader2 size={16} className="animate-spin" />
                        Cancelling...
                      </>
                    ) : (
                      <>
                        <Trash2 size={16} />
                        Permanently Cancel Job
                      </>
                    )}
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* Print Package Modal (WO Lookup) */}
      <PrintPackageModal
        isOpen={!!printPackageJob}
        job={printPackageJob}
        onClose={() => setPrintPackageJob(null)}
      />

      {/* Add Job Document Modal (WO Lookup, admin/compliance only) */}
      <AddJobDocumentModal
        isOpen={!!addDocFor}
        jobId={addDocFor?.jobId}
        partId={addDocFor?.partId}
        profile={profile}
        onClose={() => setAddDocFor(null)}
        onSuccess={async () => {
          const jobId = addDocFor?.jobId
          if (jobId) {
            const { data } = await supabase
              .from('job_documents')
              .select('*, document_type:document_types(*)')
              .eq('job_id', jobId)
              .order('created_at', { ascending: true })
            setJobDocCache(prev => ({ ...prev, [jobId]: data || [] }))
            setExpandedJobDocs(prev => ({ ...prev, [jobId]: true }))
          }
          fetchWOLookup()
        }}
      />

      {/* Split Job Modal (WO Lookup, scheduler+admin only) — S9 Batch B */}
      <SplitJobModal
        isOpen={!!splitJobTarget}
        job={splitJobTarget}
        onClose={() => setSplitJobTarget(null)}
        onSuccess={async () => {
          setSplitJobTarget(null)
          await fetchWOLookup()
          await fetchData()
        }}
      />

      {showPinPrompt && (
        <CreatePinPromptModal
          onCreatePin={() => { setShowPinPrompt(false); setShowPinModal(true) }}
          onDismiss={() => { setShowPinPrompt(false); setPinPromptDismissed(true) }}
        />
      )}

      {showPinModal && profile && (
        <ChangePinModal
          profile={profile}
          onClose={() => setShowPinModal(false)}
          onSuccess={() => {
            // Force a profile refresh so the dropdown reflects the new state
            window.location.reload()
          }}
        />
      )}
    </div>
  )
}